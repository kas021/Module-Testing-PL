(() => {
  'use strict';
  const BASE = 'https://thedaddy.li';
  const UA = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
  const MAX_BYTES = 2000000;
  const TTL = 60000;
  let cached = null, cachedAt = 0, loading = null;

  function text(value) {
    return String(value || '').replace(/<[^>]*>/g, ' ')
      .replace(/&amp;/g, '&').replace(/&quot;/g, '"')
      .replace(/&#0?39;|&apos;/g, "'").replace(/&nbsp;/g, ' ')
      .replace(/&#(\d{1,6});/g, (_, n) => Number(n) <= 0x10ffff ? String.fromCodePoint(Number(n)) : '')
      .replace(/\s+/g, ' ').trim();
  }

  function attr(tag, key) {
    const found = tag.match(new RegExp('\\b' + key + '\\s*=\\s*(["\x27])([\\s\\S]*?)\\1', 'i'));
    return found ? found[2].replace(/&amp;/g, '&') : '';
  }

  function publicHttps(value) {
    const s = String(value || '').trim();
    const match = s.match(/^https:\/\/([a-z0-9.-]+)(\/[^\s<>"\x27]*)?$/i);
    if (!match || s.length > 2048) return '';
    const host = match[1].toLowerCase();
    if (!host.includes('.') || /^\d+(?:\.\d+){3}$/.test(host) ||
        /(?:^|\.)(?:localhost|local|internal|lan)$/.test(host)) return '';
    return s;
  }

  function origin(url) { return String(url).match(/^https:\/\/[^/]+/)[0]; }

  function idOf(value) {
    const raw = String(value || '').trim();
    if (/^\d{1,6}$/.test(raw)) return raw;
    let m = raw.match(/^daddylive:(\d{1,6})$/);
    if (m) return m[1];
    m = raw.match(/^https:\/\/thedaddy\.li\/daddylive:(\d{1,6})$/);
    if (m) return m[1];
    m = raw.match(/^https:\/\/thedaddy\.li\/(?:watch\.php\?id=(\d{1,6})|(?:stream|cast|watch|plus|casting|player)\/stream-(\d{1,6})\.php)$/);
    if (m) return m[1] || m[2];
    throw new Error('Invalid DaddyLive channel identity. Reopen the channel from this source.');
  }

  async function request(url, referer, deadline, accept) {
    const left = deadline - Date.now();
    if (left <= 100) throw new Error('DaddyLive request deadline exceeded.');
    const headers = { 'User-Agent': UA, Accept: accept || 'text/html,*/*', Referer: referer,
      Origin: origin(referer) };
    const response = await fetchv2(url, headers, 'GET', null,
      { timeoutMs: Math.min(left, 7000), maxBytesHint: MAX_BYTES });
    const status = Number(response && (response.status || response.statusCode));
    if (status === 401 || status === 403) {
      throw new Error('DaddyLive access restricted (HTTP ' + status + '). This route requires provider authorization or browser verification; no playable stream was returned.');
    }
    if (status !== 200) throw new Error('DaddyLive request failed (HTTP ' + status + ').');
    let body = typeof response.text === 'function' ? await response.text() : response.body;
    if (typeof body !== 'string' || !body.trim()) throw new Error('DaddyLive returned an empty response.');
    if (body.length > MAX_BYTES) throw new Error('DaddyLive response exceeds the module limit.');
    return { body, headers };
  }

  function parseCatalogue(html) {
    const items = [], seen = Object.create(null);
    const cards = html.match(/<a\b[^>]*>[\s\S]*?<\/a>/gi) || [];
    for (const card of cards) {
      if (!/(?:^|\s)card(?:\s|$)/.test(attr(card.split('>')[0], 'class'))) continue;
      const href = attr(card.split('>')[0], 'href');
      const m = href.match(/^\/watch\.php\?id=(\d{1,6})$/);
      const titleMatch = card.match(/<[^>]+class=["\x27]card__title["\x27][^>]*>([\s\S]*?)<\//i);
      const title = text(titleMatch && titleMatch[1]);
      if (!m || !title || title.length > 300 || /^18\+/.test(title) || seen[m[1]]) continue;
      seen[m[1]] = true;
      const imageTag = card.match(/<img\b[^>]*>/i);
      let image = imageTag ? attr(imageTag[0], 'src') : '';
      if (image.startsWith('/')) image = BASE + image;
      const imageUrl = publicHttps(image);
      const sports = /sport|cricket|willow|espn|bein|golf|tennis|racing|eurosport|tnt|tsn|dazn|nfl|nba|nhl|ufc/i.test(title);
      items.push({ id: 'daddylive:' + m[1], title, kind: 'channel',
        category: sports ? 'Sports' : 'General', status: 'unknown',
        ...(imageUrl ? { imageUrl } : {}) });
      if (items.length === 1000) break;
    }
    if (!items.length) throw new Error('DaddyLive channel catalogue could not be read. The provider may have changed its page.');
    return items;
  }

  async function catalogue() {
    if (cached && Date.now() - cachedAt < TTL) return cached;
    if (loading) return loading;
    loading = (async () => {
      const res = await request(BASE + '/24-7-channels.php', BASE + '/', Date.now() + 10000);
      const items = parseCatalogue(res.body);
      cached = items; cachedAt = Date.now(); return items;
    })();
    try { return await loading; } finally { loading = null; }
  }

  async function channel(value) {
    const id = 'daddylive:' + idOf(value);
    const item = (await catalogue()).find(row => row.id === id);
    if (!item) throw new Error('This channel is no longer listed by DaddyLive. Refresh the source.');
    return item;
  }

  function frames(html, channelId) {
    const rows = [], re = /<iframe\b[^>]*>/gi;
    let match;
    while ((match = re.exec(html))) {
      let url = attr(match[0], 'src');
      if (url.startsWith('/')) url = BASE + url;
      if (!publicHttps(url)) continue;
      if (url === BASE + '/stream/stream-' + channelId + '.php' ||
          url === 'https://dembed.st/premiumtv/daddy.php?id=' + channelId) rows.push(url);
    }
    return [...new Set(rows)];
  }

  function hlsUrls(html) {
    // Read literal player configuration only. Never execute the site's scripts.
    const out = [], re = /(?:\bSRC\s*=|\b(?:file|source|src)\s*:)\s*(["\x27])(https:\/\/[^"\x27]+)\1/gi;
    let m;
    while ((m = re.exec(html))) {
      const url = publicHttps(m[2].replace(/\\\//g, '/').replace(/&amp;/g, '&'));
      if (url && /\.m3u8(?:\?|$)/i.test(url) && !out.includes(url)) out.push(url);
    }
    return out.slice(0, 2);
  }

  async function stream(value) {
    const id = idOf(value);
    await channel(value);
    const deadline = Date.now() + 13000;
    const queue = [{ url: BASE + '/stream/stream-' + id + '.php', referer: BASE + '/watch.php?id=' + id }];
    const seen = Object.create(null);
    let reason = 'DaddyLive did not expose a native HTTPS HLS stream.';
    for (let n = 0; n < queue.length && n < 3 && Date.now() < deadline; n++) {
      const page = queue[n];
      if (seen[page.url]) continue;
      seen[page.url] = true;
      let html;
      try { html = (await request(page.url, page.referer, deadline)).body; }
      catch (error) { reason = error.message; continue; }
      for (const url of hlsUrls(html)) {
        try {
          const res = await request(url, page.url, deadline, 'application/vnd.apple.mpegurl,*/*');
          if (!/^#EXTM3U\b/.test(res.body.trim()) || /<html|<!doctype/i.test(res.body)) {
            throw new Error('DaddyLive returned a webpage instead of an HLS playlist.');
          }
          if (!/#EXTINF:|#EXT-X-STREAM-INF:/.test(res.body) ||
              /(?:^|\n)[^#\r\n]+\.(?:jpe?g|png|webp)(?:\?|\r?$)/im.test(res.body)) {
            throw new Error('DaddyLive returned an unsupported playlist; native media validation is required.');
          }
          return { streams: ['Auto', url], streamType: 'hls', isLive: true, subtitles: [],
            headers: { ...res.headers, Origin: origin(page.url) } };
        } catch (error) { reason = error.message; }
      }
      for (const url of frames(html, id)) if (!seen[url]) queue.push({ url, referer: page.url });
    }
    throw new Error(reason);
  }

  globalThis.liveHome = async () => ({ items: (await catalogue()).map(row => ({ ...row })) });
  globalThis.searchResults = async query => {
    const words = text(query).toLowerCase().split(' ').filter(Boolean);
    return (await catalogue()).filter(row => words.every(word => row.title.toLowerCase().includes(word)))
      .map(row => ({ id: row.id, title: row.title, image: row.imageUrl || '', url: BASE + '/watch.php?id=' + idOf(row.id) }));
  };
  globalThis.extractDetails = async value => {
    const row = await channel(value);
    return { id: row.id, title: row.title, image: row.imageUrl || '',
      description: 'Live channel listed by DaddyLive. Availability and access depend on the provider.',
      status: 'Ongoing', url: BASE + '/watch.php?id=' + idOf(row.id) };
  };
  globalThis.extractEpisodes = async value => {
    const row = await channel(value);
    return [{ number: 1, href: row.id, title: row.title, subAvailable: true, dubAvailable: false }];
  };
  globalThis.extractStreamUrl = stream;
})();
