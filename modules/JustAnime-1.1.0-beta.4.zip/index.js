(() => {
  'use strict';

  const MODULE_NAME = 'JustAnime';
  const BASE_URL = 'https://core.justanime.to/api';
  const SITE_URL = 'https://justanime.to';
  const USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  function log(message) {
    try {
      if (typeof debugPrint === 'function') debugPrint('[' + MODULE_NAME + '] ' + String(message || ''));
      else if (typeof console !== 'undefined' && console.log) console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function decodeHtml(text) {
    return String(text || '')
      .replace(/&#0?39;|&#x27;|&apos;/g, "'")
      .replace(/&#8217;/g, "'")
      .replace(/&quot;/g, '"')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .trim();
  }

  // ---------- HTTP bridge ----------

  async function requestJson(url, extraHeaders) {
    const headers = Object.assign({
      'User-Agent': USER_AGENT,
      'Accept': 'application/json, text/plain, */*',
      'Referer': SITE_URL + '/',
      'Origin': SITE_URL,
    }, extraHeaders || {});

    let res = null;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, headers, 'GET', null);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { headers });
    }

    const status = Number((res && res.status) || 0);
    if (status < 200 || status >= 300) {
      throw new Error(MODULE_NAME + ': request failed (HTTP ' + status + ')');
    }

    if (res && typeof res.json === 'function') {
      try {
        const j = await res.json();
        if (j !== null && j !== undefined) return j;
      } catch (_) {}
    }
    if (res && res.json && typeof res.json === 'object') return res.json;

    let text = '';
    if (res && typeof res.text === 'function') { try { text = await res.text(); } catch (_) {} }
    else if (res && typeof res.body === 'string') text = res.body;

    if (text) {
      try { return JSON.parse(text); } catch (_) {}
    }
    throw new Error(MODULE_NAME + ': response was not valid JSON');
  }

  // ---------- helpers ----------

  function parseAnimeId(rawInput) {
    const raw = String(rawInput || '').trim();
    const match = raw.match(/^([1-9]\d*)(?::ep:[1-9]\d*)?$/) ||
      raw.match(/^(?:https:\/\/justanime\.to)?\/(?:anime|watch)\/([1-9]\d*)(?:\/|[?#]|$)/);
    return match ? Number(match[1]) : 0;
  }

  function formatTitle(item, fallback) {
    if (!item) return fallback || 'Anime';
    if (typeof item === 'string') return item;
    if (item.title) {
      if (typeof item.title === 'string') return item.title;
      return item.title.english || item.title.romaji || item.title.userPreferred || fallback || 'Anime';
    }
    return item.english || item.romaji || item.userPreferred || fallback || 'Anime';
  }

  function formatCover(item) {
    if (!item) return '';
    if (typeof item.cover === 'string') return item.cover;
    if (typeof item.coverImage === 'string') return item.coverImage;
    if (item.coverImage && typeof item.coverImage === 'object') {
      return item.coverImage.extraLarge || item.coverImage.large || item.coverImage.medium || '';
    }
    if (item.image && typeof item.image === 'string') return item.image;
    return '';
  }

  // ---------- search ----------

  async function searchResults(query) {
    const q = String(query || '').trim();
    let items = [];

    if (q) {
      try {
        const data = await requestJson(BASE_URL + '/search/suggestions?query=' + encodeURIComponent(q));
        if (data && Array.isArray(data.data)) items = data.data;
        else if (Array.isArray(data)) items = data;
      } catch (_) {
        try {
          const sData = await requestJson(BASE_URL + '/search?query=' + encodeURIComponent(q));
          if (sData && Array.isArray(sData.results)) items = sData.results;
          else if (sData && Array.isArray(sData.data)) items = sData.data;
        } catch (_) {}
      }
    } else {
      try {
        const homeData = await requestJson(BASE_URL + '/home');
        if (homeData && Array.isArray(homeData.trending)) items = homeData.trending;
        else if (homeData && Array.isArray(homeData.popular)) items = homeData.popular;
      } catch (_) {}
    }

    return items.map((item) => {
      const id = String(item.id || item._id || item.anilistId || '');
      const title = formatTitle(item, 'Anime #' + id);
      const cover = formatCover(item);
      return {
        id: id,
        href: SITE_URL + '/anime/' + id,
        title: title,
        image: cover,
        poster: cover,
        format: item.type || item.format || 'TV',
        year: item.year || item.seasonYear || 0,
        totalEpisodes: item.episodes || item.totalEpisodes || 0,
      };
    }).filter((r) => Boolean(r.id));
  }

  // ---------- details ----------

  async function extractDetails(urlOrId) {
    let id = parseAnimeId(urlOrId);
    if (!id) throw new Error(MODULE_NAME + ': invalid anime identity');

    const res = await requestJson(BASE_URL + '/anime/' + id);
    const anime = (res && res.data) || res || {};

    const title = formatTitle(anime, 'Anime #' + id);
    const cover = formatCover(anime);
    const banner = anime.bannerImage || anime.backdropUrl || cover;
    const desc = anime.description ? decodeHtml(anime.description.replace(/<[^>]*>/g, '')) : 'Watch on JustAnime';

    return {
      id: String(id),
      href: SITE_URL + '/anime/' + id,
      title: title,
      description: desc,
      image: cover,
      poster: cover,
      banner: banner,
      genres: Array.isArray(anime.genres) ? anime.genres : [],
      status: anime.status || 'UNKNOWN',
      year: anime.seasonYear || anime.year || 0,
      totalEpisodes: anime.episodes || anime.totalEpisodes || 0,
    };
  }

  // ---------- episodes ----------

  async function extractEpisodes(urlOrId) {
    let id = parseAnimeId(urlOrId);
    if (!id) {
      const details = await extractDetails(urlOrId);
      id = parseInt(details.id, 10);
    }
    if (!id) throw new Error(MODULE_NAME + ': unable to parse anime ID for episodes from ' + urlOrId);

    // Fetch page 1
    const p1 = await requestJson(BASE_URL + '/anime/' + id + '/episodes?page=1');
    let allEpisodes = (p1 && Array.isArray(p1.episodes)) ? p1.episodes.slice() : [];
    const totalPages = Number((p1 && p1.totalPages) || 1);

    // Fetch remaining pages up to max 15 pages
    if (totalPages > 1) {
      const fetchPages = [];
      for (let p = 2; p <= Math.min(totalPages, 15); p++) {
        if (fetchPages.length === 4) {
          const batch = await Promise.all(fetchPages.splice(0));
          batch.forEach(function (episodes) { allEpisodes = allEpisodes.concat(episodes); });
        }
        fetchPages.push(
          requestJson(BASE_URL + '/anime/' + id + '/episodes?page=' + p)
            .then((data) => (data && Array.isArray(data.episodes) ? data.episodes : []))
        );
      }
      const pageResults = await Promise.all(fetchPages);
      for (const pageEps of pageResults) {
        allEpisodes = allEpisodes.concat(pageEps);
      }
    }

    if (allEpisodes.length === 0) return [];

    allEpisodes.sort((a, b) => (Number(a.number) || 0) - (Number(b.number) || 0));

    const seen = {};
    return allEpisodes.filter(function (ep) {
      const number = Number(ep.number);
      if (!Number.isInteger(number) || number < 1 || seen[number]) return false;
      seen[number] = true;
      return true;
    }).map((ep) => {
      const epNum = Number(ep.number);
      const epTitle = ep.title ? decodeHtml(ep.title) : 'Episode ' + epNum;
      return {
        id: id + ':ep:' + epNum,
        href: SITE_URL + '/watch/' + id + '/episode/' + epNum,
        number: epNum,
        title: 'S1E' + epNum + ': ' + epTitle,
        description: ep.description ? decodeHtml(ep.description) : '',
        image: ep.image || '',
        subAvailable: typeof ep.subAvailable === 'boolean' ? ep.subAvailable : undefined,
        dubAvailable: typeof ep.dubAvailable === 'boolean' ? ep.dubAvailable : undefined,
      };
    });
  }

  // ---------- extractStreamUrl ----------

  async function resolveProvider(episodeHref, lang, provider) {
    const raw = String(episodeHref || '').trim();
    let animeId = 0;
    let epNum = 0;

    if (/^[1-9]\d*:ep:[1-9]\d*$/.test(raw)) {
      const parts = raw.split(':ep:');
      animeId = parseInt(parts[0], 10);
      epNum = Number(parts[1]);
    } else {
      const m = raw.match(/^(?:https:\/\/justanime\.to)?\/watch\/([1-9]\d*)\/episode\/([1-9]\d*)(?:[?#].*)?$/);
      if (m) {
        animeId = parseInt(m[1], 10);
        epNum = Number(m[2]);
      } else {
        animeId = parseAnimeId(raw);
      }
    }

    if (!animeId || !Number.isInteger(epNum) || epNum < 1) {
      throw new Error(MODULE_NAME + ': a valid explicit episode is required');
    }

    const targetLang = (String(lang || 'sub').toLowerCase() === 'dub') ? 'dub' : 'sub';
    log('Extracting stream for animeId=' + animeId + ', ep=' + epNum + ', lang=' + targetLang);

    // 1. Try AnimeGG resolver (direct verified high-speed MP4)
    try {
      if (provider !== 'AnimeGG') throw new Error('Skipped');
      const ggData = await requestJson(BASE_URL + '/watch/' + animeId + '/episode/' + epNum + '/animegg');
      const langData = ggData[targetLang] || {};
      const sources = (Array.isArray(langData.sources) ? langData.sources : []).filter(s => s && /^https:\/\//.test(s.url || '')).sort((a, b) => (parseInt(a.quality, 10) || 0) - (parseInt(b.quality, 10) || 0));

      if (sources.length > 0) {
        const bestSource = sources[sources.length - 1];
        if (bestSource && bestSource.url) {
          log('AnimeGG stream resolved');
          return {
            url: bestSource.url,
            quality: bestSource.quality || 'auto',
            qualities: sources.slice().reverse().map(s => ({label: s.quality || 'Auto', url: s.url, headers: Object.assign({'User-Agent': USER_AGENT, Referer: 'https://www.animegg.org/'}, langData.headers || {}, s.headers || {})})),
            headers: Object.assign({
              'User-Agent': USER_AGENT,
              'Referer': 'https://www.animegg.org/',
            }, langData.headers || {}, bestSource.headers || {}),
            subtitles: [],
          };
        }
      }
    } catch (err) {
      log('AnimeGG resolver failed: ' + err.message);
    }

    // 2. Try AniNeko resolver (HLS with subtitles)
    try {
      if (provider !== 'AniNeko') throw new Error('Skipped');
      const nkData = await requestJson(BASE_URL + '/watch/' + animeId + '/episode/' + epNum + '/anineko/' + targetLang);
      if (nkData.lang && nkData.lang !== targetLang) throw new Error('Audio language mismatch');
      const sources = nkData && Array.isArray(nkData.sources) ? nkData.sources : [];

      if (sources.length > 0) {
        const bestSource = sources[0];
        if (bestSource && bestSource.url) {
          const subtitles = (nkData.subtitles || []).map((sub) => ({
            url: sub.url,
            lang: sub.lang || 'und',
            label: sub.lang || 'Unknown language',
            default: Boolean(sub.default),
          }));

          log('AniNeko stream resolved');
          return {
            url: bestSource.url,
            quality: bestSource.quality || 'auto',
            headers: Object.assign({
              'User-Agent': USER_AGENT,
              'Referer': (nkData.headers && nkData.headers.Referer) || 'https://otakuhg.site/',
              'Origin': (nkData.headers && nkData.headers.Origin) || 'https://otakuhg.site',
            }, nkData.headers || {}),
            subtitles: subtitles,
          };
        }
      }
    } catch (err) {
      log('AniNeko resolver failed: ' + err.message);
    }

    // 3. Try MegaPlay fallback
    try {
      if (provider !== 'MegaPlay') throw new Error('Skipped');
      const mpData = await requestJson(BASE_URL + '/watch/' + animeId + '/episode/' + epNum + '/megaplay');
      const langData = mpData[targetLang] || {};
      const sources = Array.isArray(langData.sources) ? langData.sources : [];

      if (sources.length > 0) {
        const bestSource = sources[0];
        if (bestSource && bestSource.url) {
          const subtitles = (langData.subtitles || []).map((sub) => ({
            url: sub.file || sub.url,
            lang: sub.label || 'und',
            label: sub.label || 'Unknown language',
            default: Boolean(sub.default),
          }));

          log('MegaPlay stream resolved');
          return {
            url: bestSource.url,
            quality: bestSource.quality || 'auto',
            headers: Object.assign({
              'User-Agent': USER_AGENT,
              'Referer': 'https://megaplay.buzz/',
            }, langData.headers || {}, bestSource.headers || {}),
            subtitles: subtitles,
            intro: langData.intro || null,
            outro: langData.outro || null,
          };
        }
      }
    } catch (err) {
      log('MegaPlay resolver failed: ' + err.message);
    }

    throw new Error(MODULE_NAME + ': no playable streams found for animeId=' + animeId + ', ep=' + epNum);
  }

  function bounded(promise, ms, fallback) {
    return new Promise(function (resolve) {
      const timer = setTimeout(function () { resolve(fallback); }, ms);
      function finish(value) {
        if (typeof clearTimeout === 'function') clearTimeout(timer);
        resolve(value);
      }
      promise.then(finish, function () { finish(fallback); });
    });
  }

  function marker(value) {
    if (!value || !Number.isFinite(Number(value.start)) || !Number.isFinite(Number(value.end))) return null;
    const start = Number(value.start), end = Number(value.end);
    return start >= 0 && end > start ? {start: start, end: end} : null;
  }

  function captionLanguage(label) {
    const name = String(label || '').toLowerCase().trim();
    const codes = {english: 'en', arabic: 'ar', french: 'fr', german: 'de', italian: 'it', spanish: 'es', portuguese: 'pt', russian: 'ru', indonesian: 'id', thai: 'th', vietnamese: 'vi', japanese: 'ja', chinese: 'zh', korean: 'ko', turkish: 'tr', polish: 'pl', dutch: 'nl', danish: 'da', finnish: 'fi', swedish: 'sv', norwegian: 'no', hebrew: 'he', bulgarian: 'bg', czech: 'cs', hungarian: 'hu', romanian: 'ro', greek: 'el', ukrainian: 'uk', hindi: 'hi', malay: 'ms'};
    const word = name.match(/^[a-z]+/);
    if (word && codes[word[0]]) return codes[word[0]];
    return /^[a-z]{2,3}(?:-[a-z0-9]+)*$/.test(name) ? name : 'und';
  }

  async function usable(route) {
    if (!route || !/^https:\/\//.test(route.url || '')) return false;
    const headers = Object.assign({}, route.headers || {}, {Range: 'bytes=0-16383'});
    const res = await fetchv2(route.url, headers, 'GET', null, {maxBytesHint: 16384});
    log('Media probe status=' + (res && res.status));
    if (!res || (res.status !== 200 && res.status !== 206)) return false;
    let body = typeof res.body === 'string' ? res.body : '';
    if (!body && typeof res.text === 'function') body = await res.text();
    if (body.trim().startsWith('#EXTM3U')) {
      if (/^[^#\r\n].*\.(?:jpg|jpeg|png|webp)(?:[?\r\n]|$)/im.test(body)) return false;
      route.streamType = 'hls';
      return /#EXT(?:INF|-X-STREAM-INF|-X-MAP)/.test(body);
    }
    const responseHeaders = res.headers || {};
    const type = String(responseHeaders['content-type'] || responseHeaders['Content-Type'] || '');
    if (/^video\/mp4/i.test(type) || body.slice(0, 32).includes('ftyp')) {
      route.streamType = 'mp4';
      return true;
    }
    return false;
  }

  async function extractStreamUrl(episodeHref, lang) {
    // Three independent provider requests; each keeps its own captions and headers.
    const providers = ['AniNeko', 'MegaPlay', 'AnimeGG'];
    const results = await Promise.all(providers.map(function (provider) {
      return bounded((async function () {
        const route = await resolveProvider(episodeHref, lang, provider);
        if (!await usable(route)) return null;
        route.name = provider;
        route.intro = marker(route.intro);
        route.outro = marker(route.outro);
        const seen = {};
        route.subtitles = (route.subtitles || []).filter(function (track) {
          if (!/^https:\/\//.test(track.url || '') || seen[track.url]) return false;
          seen[track.url] = true;
          track.lang = captionLanguage(track.lang || track.label);
          track.language = track.lang;
          return true;
        });
        return route;
      })(), 14000, null);
    }));
    const entries = results.filter(Boolean);
    if (!entries.length) throw new Error(MODULE_NAME + ': no playable streams for the requested episode and language');
    const primary = entries[0];
    return Object.assign({}, primary, {
      lang: lang === 'dub' ? 'dub' : 'sub',
      streams: [primary.quality || 'Auto', primary.url],
      servers: entries.map(function (entry) {
        return Object.assign({}, entry, {lang: lang === 'dub' ? 'dub' : 'sub'});
      }),
    });
  }

  // ---------- extractHome (discovery_v1) ----------

  async function extractHome() {
    try {
      const data = await requestJson(BASE_URL + '/home');
      const sections = [];

      function mapSection(title, list) {
        if (!Array.isArray(list) || list.length === 0) return null;
        return {
          id: title.toLowerCase().replace(/ /g, '-'),
          title: title,
          style: 'poster',
          items: list.slice(0, 24).map((item) => {
            const id = String(item.id || item._id || item.anilistId || '');
            const name = formatTitle(item, 'Anime #' + id);
            const cover = formatCover(item);
            return {
              id: id,
              href: SITE_URL + '/anime/' + id,
              title: name,
              image: cover,
              poster: cover,
              format: item.type || item.format || 'TV',
            };
          }).filter((r) => Boolean(r.id)),
        };
      }

      if (data && data.trending) {
        const s = mapSection('Trending Anime', data.trending);
        if (s) sections.push(s);
      }
      if (data && data.popular) {
        const s = mapSection('Popular Anime', data.popular);
        if (s) sections.push(s);
      }
      if (data && data.recent) {
        const s = mapSection('Recent Episodes', data.recent);
        if (s) sections.push(s);
      }

      if (sections.length > 0) return { sections };
    } catch (_) {}

    const defaultSearch = await searchResults('');
    return {
      sections: [
        {
          id: 'popular-anime',
          title: 'Popular Anime',
          style: 'poster',
          items: defaultSearch.slice(0, 24),
        }
      ]
    };
  }

  // ---------- Exports on globalThis ----------

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.extractHome = extractHome;
  globalThis.discoveryHome = extractHome;
  globalThis.discoveryFeed = async function (feedId, page) {
    const p = Math.max(1, Number(page) || 1);
    if (p !== 1) return {items: [], page: p, hasMore: false};
    const home = await extractHome();
    const section = home.sections.find(function (s) { return s.id === feedId; });
    return {items: section ? section.items : [], page: p, hasMore: false};
  };

})();
