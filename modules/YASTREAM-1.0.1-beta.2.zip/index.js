// Bundled into each module. No remote code or new runtime APIs.
globalThis.__trioMedia = (() => {
  const parked = Object.create(null);
  function absolute(value, base) {
    if (/^https?:\/\//i.test(value)) return value;
    if (value.indexOf('//') === 0) return 'https:' + value;
    const origin = (base.match(/^https?:\/\/[^/]+/i) || [''])[0];
    if (value[0] === '/') return origin + value;
    const joined=base.split('?')[0].replace(/[^/]*$/, '')+value;
    const suffix=joined.slice(origin.length), parts=suffix.split('/'), clean=[];
    for(const part of parts){if(part==='..')clean.pop();else if(part!=='.')clean.push(part);}
    return origin+clean.join('/');
  }
  async function get(url, headers, deadline, range) {
    for (let hop=0;hop<5;hop++) {
      const host=(url.match(/^https?:\/\/([^/]+)/i)||[])[1];
      if (!host || Date.now() >= deadline || parked[host] > Date.now()) return null;
      const h=Object.assign({},headers,range ? {Range:typeof range==='string'?range:'bytes=0-1023'} : {});
      let timer;
      let r=await Promise.race([
        fetchv2(url,h,'GET',null,{followRedirects:false,maxBytesHint:range?2048:1048576}),
        new Promise(resolve=>{timer=setTimeout(()=>resolve(null),Math.max(1,deadline-Date.now()));})
      ]).finally(()=>{if(typeof clearTimeout==='function') clearTimeout(timer);});
      if (!r) return null;
      const status=Number(r.status), rh=r.headers||{};
      if (status===429 || status===403) {parked[host]=Date.now()+900000;return null;}
      const loc=rh.location||rh.Location;
      if (status>=300 && status<400 && loc) {url=absolute(loc,url);continue;}
      if (!(status>=200 && status<300)) return null;
      // The shipped bridge deliberately returns no body for manual redirects.
      // Once the final URL is known, read the playlist through the text bridge.
      if ((!range || typeof range==='string') && !r.body && Date.now()<deadline) {
        let bodyTimer;
        r=await Promise.race([fetchv2(url,h,'GET',null,{followRedirects:true,maxBytesHint:1048576}),new Promise(resolve=>{bodyTimer=setTimeout(()=>resolve(null),Math.max(1,deadline-Date.now()));})]).finally(()=>{if(typeof clearTimeout==='function')clearTimeout(bodyTimer);});
        if (!r || Number(r.status)<200 || Number(r.status)>=300) return null;
      }
      let body=typeof r.body==='string'?r.body:'';
      if (!body && typeof r.text==='function') body=await r.text();
      console.log('[media-check] '+host+' status='+status+' type='+String(rh['content-type']||rh['Content-Type']||'')+' chars='+body.length);
      const finalHeaders=r.headers||rh;
      return {url,body:body||'',status:Number(r.status),contentRange:String(finalHeaders['content-range']||finalHeaders['Content-Range']||''),type:String(finalHeaders['content-type']||finalHeaders['Content-Type']||'')};
    }
    return null;
  }
  async function verifyTransportPackets(url, headers, deadline) {
    // Single-byte ranges remain lossless through Flutter's UTF-8 text bridge.
    // Require MPEG-TS sync bytes at three packet boundaries, not a MIME guess.
    let total = 0;
    for (const offset of [0,188,376]) {
      const r=await get(url,headers,deadline,'bytes='+offset+'-'+offset);
      const match=r && r.contentRange.match(/^bytes (\d+)-(\d+)\/(\d+)$/i);
      if (!r || r.status!==206 || !match || Number(match[1])!==offset || Number(match[2])!==offset ||
          r.body!=='G' || Number(match[3])<564 || Number(match[3])%188!==0) return false;
      if (total && total!==Number(match[3])) return false;
      total=Number(match[3]);
    }
    return true;
  }
  async function check(candidate, deadline) {
    const headers=candidate.headers||{};
    const hls=candidate.streamType==='hls'||/\.m3u8(?:[?#]|$)/i.test(candidate.url);
    const r=await get(candidate.url,headers,deadline,!hls);
    if (!r || /text\/html|image\//i.test(r.type) || /^\s*(?:<!doctype|<html)/i.test(r.body)) return null;
    if (!hls) {
      // Runtime text bridges may drop binary bodies; require media MIME there.
      if (!/video\/|application\/octet-stream/i.test(r.type) && !/ftyp/.test(r.body.slice(0,32))) return null;
      return Object.assign({},candidate,{url:r.url,streamType:'mp4',qualities:[{label:'Auto',url:r.url,headers}]});
    }
    if (!/^\s*#EXTM3U/.test(r.body)) return null;
    const variants=[];
    const re=/#EXT-X-STREAM-INF:([^\r\n]*)[\r\n]+([^#\r\n][^\r\n]*)/g;
    let m;
    while ((m=re.exec(r.body))) {
      const height=Number((m[1].match(/RESOLUTION=\d+x(\d+)/i)||[])[1])||0;
      variants.push({label:height?height+'p':'Auto',height,url:absolute(m[2].trim(),r.url),headers});
    }
    const checked=[];
    for (const v of variants.length?variants:[{label:'Auto',url:r.url,headers}]) {
      if (Date.now()>=deadline) break;
      const p=variants.length?await get(v.url,headers,deadline,false):r;
      if (!p || !/^\s*#EXTM3U/.test(p.body)) continue;
      const segment=p.body.split(/\r?\n/).map(x=>x.trim()).find(x=>x && x[0]!=='#');
      if (!segment || !/#EXTINF:/.test(p.body)) continue;
      const segmentUrl=absolute(segment,p.url);
      if (/\.(?:jpg|jpeg|png|webp)(?:[?#]|$)/i.test(segmentUrl)) {
        if (!await verifyTransportPackets(segmentUrl,headers,deadline)) continue;
        checked.push(Object.assign({},v,{url:p.url}));
        continue;
      }
      const bytes=await get(segmentUrl,headers,deadline,true);
      if (!bytes || /image\/|text\/html/i.test(bytes.type) || /^\s*(?:<!doctype|<html)/i.test(bytes.body)) continue;
      if (!/video\/|application\/octet-stream/i.test(bytes.type) && bytes.body[0]!=='G' && !/styp|ftyp|moof/.test(bytes.body.slice(0,40))) continue;
      checked.push(Object.assign({},v,{url:p.url}));
    }
    if (!checked.length) return null;
    checked.sort((a,b)=>(b.height||0)-(a.height||0));
    // Preserve external audio groups by keeping their master as the default.
    const externalAudio=/#EXT-X-MEDIA:.*TYPE=AUDIO.*URI=/i.test(r.body);
    if (externalAudio) return Object.assign({},candidate,{url:r.url,streamType:'hls',qualities:[{label:'Auto',url:r.url,headers}]});
    return Object.assign({},candidate,{url:checked[0].url,streamType:'hls',qualities:checked});
  }
  function result(rows, lang) {
    const seen=Object.create(null);
    const servers=rows.filter(r=>{
      const key=r.url+JSON.stringify(r.headers||{})+JSON.stringify(r.subtitles||[]);
      if (seen[key]) return false; seen[key]=true; return true;
    }).map((r,i)=>Object.assign({},r,{id:'server-'+(i+1),name:r.name||'Server '+(i+1),lang,
      streams:r.qualities.flatMap(q=>[q.label,q.url]),subtitles:r.subtitles||[]}));
    if (!servers.length) return {streams:[],servers:[],subtitles:[],lang};
    const first=servers[0];
    return Object.assign({},first,{servers,streams:first.qualities.flatMap(q=>[q.label,q.url])});
  }
  return {absolute,get,check,result};
})();

(function () {
  'use strict';

  var MODULE_NAME = 'YASTREAM';
  var BASE_URL = 'https://yastream.tamthai.de';
  var USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36';
  var PAGE_ACCEPT = 'application/json,text/plain,*/*;q=0.8';
  var HLS_ACCEPT = 'application/vnd.apple.mpegurl,application/x-mpegURL,text/plain,*/*;q=0.8';
  var feedFirstIds = Object.create(null);

  var FEEDS = {
    'kisskh-korean': { type: 'series', id: 'kisskh.series.Korean', title: 'KissKH Korean' },
    'onetouchtv-korean': { type: 'series', id: 'onetouchtv.series.Korean', title: 'OneTouchTV Korean' },
    'kisskh-movies': { type: 'movie', id: 'kisskh.movie.Search', title: 'KissKH Movies' }
  };

  function clean(value) {
    return String(value === null || value === undefined ? '' : value)
      .replace(/&quot;/gi, '"')
      .replace(/&#039;|&#x27;/gi, "'")
      .replace(/&amp;/gi, '&')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function log(message) {
    if (typeof console !== 'undefined' && console.log) {
      console.log('[' + MODULE_NAME + '] ' + String(message));
    }
  }

  function isHttp(value) {
    return /^https?:\/\//i.test(String(value || '').trim());
  }

  function absoluteUrl(value, base) {
    var text = clean(value).replace(/\\\//g, '/');
    if (!text) return '';
    if (/^\/\//.test(text)) return 'https:' + text;
    if (isHttp(text)) return text;
    if (text.charAt(0) === '/') return String(base || BASE_URL).replace(/\/$/, '') + text;
    return String(base || BASE_URL).replace(/\/$/, '') + '/' + text;
  }

  function resolveRelativeUrl(value, base) {
    var text = clean(value).replace(/\\\//g, '/');
    if (!text) return '';
    if (isHttp(text)) return text;
    var baseText = clean(base).split(/[?#]/)[0];
    var schemeMatch = baseText.match(/^([a-z][a-z0-9+.-]*:)/i);
    var scheme = schemeMatch ? schemeMatch[1] : 'https:';
    if (/^\/\//.test(text)) return scheme + text;
    var originMatch = baseText.match(/^([a-z][a-z0-9+.-]*:\/\/[^/]+)/i);
    var origin = originMatch ? originMatch[1] : BASE_URL;
    if (text.charAt(0) === '/') return origin + text;
    var slash = baseText.lastIndexOf('/');
    return (slash >= 0 ? baseText.slice(0, slash + 1) : baseText + '/') + text;
  }

  function asPositiveInt(value, fallback) {
    var number = parseInt(value, 10);
    return isFinite(number) && number > 0 ? number : (fallback || 0);
  }

  function yearOf(value) {
    var text = clean(value);
    var match = text.match(/(?:19|20)\d{2}/);
    return match ? parseInt(match[0], 10) : 0;
  }

  function streamHeaders() {
    return {
      'User-Agent': USER_AGENT,
      Referer: BASE_URL + '/',
      Origin: BASE_URL
    };
  }

  async function readBody(response) {
    if (!response) return '';
    if (typeof response.json === 'function') {
      try { var parsed = await response.json(); if (parsed !== null && parsed !== undefined) return JSON.stringify(parsed); } catch (_) {}
    }
    var bodyText = typeof response.body === 'string' ? response.body : null;
    if (bodyText) return bodyText;
    if (response.json && typeof response.json === 'object') {
      try { return JSON.stringify(response.json); } catch (_) {}
    }
    var textValue = null;
    if (typeof response.text === 'function') {
      try {
        var text = await response.text();
        if (typeof text === 'string') {
          textValue = text;
          if (text) return text;
        }
      } catch (_) {}
    }
    if (typeof response.json === 'function') {
      try {
        var json = await response.json();
        return json === null || json === undefined ? '' : JSON.stringify(json);
      } catch (_) {}
    }
    if (bodyText !== null) return bodyText;
    if (textValue !== null) return textValue;
    if (response.body && typeof response.body === 'object') {
      try { return JSON.stringify(response.body); } catch (_) {}
    }
    return '';
  }

  async function requestText(url, extraHeaders) {
    var headers = {
      'User-Agent': USER_AGENT,
      Accept: PAGE_ACCEPT,
      Referer: BASE_URL + '/'
    };
    var extras = extraHeaders || {};
    Object.keys(extras).forEach(function (key) { headers[key] = extras[key]; });
    var response;
    try {
      if (typeof globalThis.fetchv2 === 'function') {
        response = await globalThis.fetchv2(url, headers, 'GET', null);
      } else if (typeof fetch === 'function') {
        response = await fetch(url, { method: 'GET', headers: headers });
      } else {
        throw new Error('fetch bridge unavailable');
      }
    } catch (error) {
      return { ok: false, status: 0, text: '', error: error && error.message ? error.message : 'request failed' };
    }
    var status = Number(response && response.status) || 0;
    return {
      ok: status >= 200 && status < 400,
      status: status,
      text: await readBody(response),
      error: ''
    };
  }

  async function requestJson(url) {
    var response = await requestText(url, { Accept: PAGE_ACCEPT });
    if (!response.ok || !response.text) {
      throw new Error('YASTREAM request failed (' + response.status + ')');
    }
    try {
      return JSON.parse(response.text);
    } catch (_) {
      throw new Error('YASTREAM returned invalid JSON');
    }
  }

  function encodeId(value) {
    return encodeURIComponent(clean(value));
  }

  function makeRoute(kind, type, id) {
    return BASE_URL + '/' + kind + '/' + type + '/' + encodeId(id) + '.json';
  }

  function parseRoute(value) {
    var raw = clean(value);
    var withoutQuery = raw.split('?')[0].split('#')[0];
    var match = withoutQuery.match(/\/(meta|stream|subtitles)\/(movie|series)\/([^/]+?)(?:\.json)?$/i);
    if (match) {
      var decoded = match[3];
      try { decoded = decodeURIComponent(decoded); } catch (_) {}
      return { kind: match[1].toLowerCase(), type: match[2].toLowerCase(), id: decoded };
    }
    if (/^(?:kisskh|onetouchtv|idrama|tmdb|tvdb):[^\s/?#]+$|^tt\d+(?::\d+)*$/i.test(raw)) {
      return { kind: '', type: /^onetouchtv:/i.test(raw) ? 'series' : 'series', id: raw };
    }
    return null;
  }

  function catalogUrl(type, catalogId, query, page) {
    var skip = Math.max(0, (asPositiveInt(page, 1) - 1) * 20);
    var extra = 'skip=' + skip;
    if (query) extra += '&search=' + encodeURIComponent(query);
    return BASE_URL + '/catalog/' + type + '/' + encodeURIComponent(catalogId) + '/' + extra + '.json';
  }

  function rawMetas(payload) {
    return payload && Array.isArray(payload.metas) ? payload.metas : [];
  }

  function mapCard(raw, fallbackType) {
    if (!raw || typeof raw !== 'object') return null;
    var type = clean(raw.type || fallbackType || 'series').toLowerCase();
    if (type !== 'movie' && type !== 'series') type = fallbackType || 'series';
    var id = clean(raw.id);
    var title = clean(raw.name || raw.title);
    if (!id || !title) return null;
    var image = absoluteUrl(raw.poster || raw.image || raw.thumbnail, BASE_URL);
    var backdrop = absoluteUrl(raw.background || raw.backdrop || image, BASE_URL);
    return {
      id: makeRoute('meta', type, id),
      href: makeRoute('meta', type, id),
      url: makeRoute('meta', type, id),
      title: title,
      name: title,
      image: image,
      poster: image,
      thumbnail: image,
      backdrop: backdrop,
      description: clean(raw.description || raw.overview || raw.synopsis),
      year: yearOf(raw.releaseInfo || raw.year || raw.released),
      rating: Number(raw.rating || raw.score || 0) || 0,
      tags: raw.country ? [clean(raw.country)] : [],
      type: type,
      isMovie: type === 'movie',
      subAvailable: true,
      dubAvailable: false
    };
  }

  function dedupeCards(items) {
    var seen = Object.create(null);
    return (items || []).filter(function (item) {
      var key = item && (item.href || item.id);
      if (!key || seen[key]) return false;
      seen[key] = true;
      return true;
    });
  }

  function queryMatches(item, query) {
    var q = clean(query).toLowerCase();
    if (!q) return true;
    var title = clean(item && (item.title || item.name)).toLowerCase();
    if (title.indexOf(q) >= 0) return true;
    var tokens = q.split(/\s+/).filter(Boolean);
    return tokens.every(function (token) { return title.indexOf(token) >= 0; });
  }

  async function fetchCatalog(type, id, query, page) {
    var payload = await requestJson(catalogUrl(type, id, query, page));
    return rawMetas(payload).map(function (raw) { return mapCard(raw, type); }).filter(Boolean);
  }

  async function searchResults(query, page) {
    var q = clean(query);
    if (!q) {
      var home = await discoveryFeed('kisskh-korean', 1);
      return home.items || [];
    }
    var results = [];
    var routes = [
      { type: 'series', id: 'kisskh.series.Search' },
      { type: 'series', id: 'onetouchtv.series.Search' },
      { type: 'movie', id: 'kisskh.movie.Search' }
    ];
    for (var i = 0; i < routes.length; i += 1) {
      try {
        var cards = await fetchCatalog(routes[i].type, routes[i].id, q, page || 1);
        results = results.concat(cards.filter(function (item) { return queryMatches(item, q); }));
      } catch (error) {
        log('search route failed: ' + routes[i].id);
      }
    }
    return dedupeCards(results).slice(0, 40);
  }

  async function discoveryHome() {
    var configs = [
      { feedId: 'kisskh-korean', type: 'series', id: 'kisskh.series.Korean', title: 'KissKH Korean' },
      { feedId: 'onetouchtv-korean', type: 'series', id: 'onetouchtv.series.Korean', title: 'OneTouchTV Korean' },
      { feedId: 'kisskh-movies', type: 'movie', id: 'kisskh.movie.Search', title: 'KissKH Movies' }
    ];
    var sections = [];
    for (var i = 0; i < configs.length; i += 1) {
      try {
        var items = (await fetchCatalog(configs[i].type, configs[i].id, '', 1)).slice(0, 12);
        if (items.length) sections.push({ id: configs[i].feedId, title: configs[i].title, items: items,
          style: 'poster', viewAll: {mode: 'feed', feedId: configs[i].feedId} });
      } catch (error) {
        log('home route failed: ' + configs[i].id);
      }
    }
    if (sections.length) sections.unshift({id:'featured',title:'Featured',style:'hero',items:sections[0].items.slice(0,8)});
    return { sections: sections };
  }

  async function discoveryFeed(feedId, page) {
    var config = FEEDS[feedId] || FEEDS['kisskh-korean'];
    var pageNumber = asPositiveInt(page, 1);
    try {
      var items = await fetchCatalog(config.type, config.id, '', pageNumber);
      var first = items.length ? items[0].href : '';
      if (pageNumber > 1 && first && feedFirstIds[feedId] === first) {
        return { feedId: feedId, page: pageNumber, items: [], hasMore: false };
      }
      if (pageNumber === 1) feedFirstIds[feedId] = first;
      return { feedId: feedId, page: pageNumber, items: items, hasMore: items.length >= 20 };
    } catch (error) {
      return { feedId: feedId, page: pageNumber, items: [], hasMore: false, error: String(error && error.message || error) };
    }
  }

  async function fetchMeta(ref) {
    if (!ref) throw new Error('Invalid YASTREAM reference');
    var candidates = [];
    if (ref.kind && ref.type && ref.id) candidates.push(makeRoute('meta', ref.type, ref.id));
    else if (ref.id) {
      candidates.push(makeRoute('meta', 'series', ref.id));
      candidates.push(makeRoute('meta', 'movie', ref.id));
    }
    var lastError = null;
    for (var i = 0; i < candidates.length; i += 1) {
      try {
        var payload = await requestJson(candidates[i]);
        // OneTouchTV returns its slug without the provider prefix in metadata.
        if (payload && payload.meta && (clean(payload.meta.id) === ref.id ||
          /^onetouchtv:/.test(ref.id) && clean(payload.meta.id) === ref.id.slice(11))) {
          return { type: candidates[i].indexOf('/movie/') >= 0 ? 'movie' : 'series', meta: payload.meta };
        }
      } catch (error) { lastError = error; }
    }
    throw lastError || new Error('metadata unavailable');
  }

  function mapMeta(meta, type, ref) {
    var title = clean(meta && (meta.name || meta.title)) || 'Unavailable';
    var image = absoluteUrl(meta && (meta.poster || meta.image || meta.thumbnail), BASE_URL);
    var backdrop = absoluteUrl(meta && (meta.background || meta.backdrop || image), BASE_URL);
    var id = clean(ref && ref.id) || clean(meta && meta.id);
    var href = makeRoute('meta', type, id);
    var tags = [];
    if (meta && meta.country) tags.push(clean(meta.country));
    if (meta && Array.isArray(meta.genres)) tags = tags.concat(meta.genres.map(clean).filter(Boolean));
    return {
      id: href,
      href: href,
      url: href,
      title: title,
      name: title,
      image: image,
      poster: image,
      thumbnail: image,
      backdrop: backdrop,
      description: clean(meta && (meta.description || meta.overview || meta.synopsis)),
      year: yearOf(meta && (meta.released || meta.releaseInfo || meta.year)),
      rating: Number(meta && (meta.rating || meta.score || 0)) || 0,
      tags: tags,
      type: type,
      isMovie: type === 'movie',
      subAvailable: true,
      dubAvailable: false
    };
  }

  async function extractDetails(urlOrId) {
    var ref = parseRoute(urlOrId);
    try {
      var loaded = await fetchMeta(ref);
      return mapMeta(loaded.meta, loaded.type, ref);
    } catch (error) {
      return {
        id: clean(urlOrId), href: clean(urlOrId), title: 'Unavailable', name: 'Unavailable',
        image: '', poster: '', backdrop: '', description: '', year: 0, tags: [],
        type: 'series', isMovie: false, subAvailable: true, dubAvailable: false,
        error: String(error && error.message || error)
      };
    }
  }

  function mapEpisode(meta, type, video, index) {
    var rawId = clean(video && video.id);
    if (!rawId) return null;
    var seasonValue = video && (video.season !== undefined ? video.season : video.seasonNumber);
    var season = seasonValue === 0 ? 0 : asPositiveInt(seasonValue, 1);
    var numberValue = video && (video.episode !== undefined ? video.episode : video.number !== undefined ? video.number : video.episodeNumber);
    var number = Number(numberValue);
    if (!isFinite(number) || number < 0 || numberValue === undefined) number = index + 1;
    var streamHref = makeRoute('stream', type, rawId);
    var poster = absoluteUrl(video && (video.thumbnail || video.poster || video.background), BASE_URL) ||
      absoluteUrl(meta && meta.poster, BASE_URL);
    var baseTitle = clean(video && (video.title || video.name)) || (type === 'movie' ? clean(meta.name) : 'Episode ' + number);
    var displayTitle = type === 'movie' ? baseTitle : 'S' + season + 'E' + number + ' - ' + baseTitle;
    return {
      id: streamHref,
      href: streamHref,
      number: number,
      episodeNumber: number,
      season: season,
      seasonNumber: season,
      title: displayTitle,
      name: baseTitle,
      image: poster,
      poster: poster,
      thumbnail: poster,
      description: clean(video && (video.description || video.overview)),
      subAvailable: true,
      dubAvailable: false
    };
  }

  async function extractEpisodes(seriesId) {
    var ref = parseRoute(seriesId);
    try {
      var loaded = await fetchMeta(ref);
      var videos = loaded.meta && Array.isArray(loaded.meta.videos) ? loaded.meta.videos : [];
      if (!videos.length && loaded.type === 'movie') {
        var movieId = clean(loaded.meta.behaviorHints && loaded.meta.behaviorHints.defaultVideoId) || clean(loaded.meta.id);
        videos = [{ id: movieId, title: loaded.meta.name, season: 1, episode: 1 }];
      }
      var seen = Object.create(null);
      var output = videos.map(function (video, index) {
        var episode = mapEpisode(loaded.meta, loaded.type, video, index);
        if (!episode || seen[episode.href]) return null;
        seen[episode.href] = true;
        return episode;
      }).filter(Boolean);
      output.sort(function (a, b) {
        return (a.season - b.season) || (a.number - b.number);
      });
      return output;
    } catch (error) {
      log('extractEpisodes failed');
      return [];
    }
  }

  function languageLabel(code) {
    var text = clean(code).toLowerCase();
    var labels = { eng: 'English', en: 'English', ara: 'Arabic', ar: 'Arabic', khm: 'Khmer', km: 'Khmer', ind: 'Indonesian', id: 'Indonesian', fra: 'French', fr: 'French', spa: 'Spanish', es: 'Spanish', ita: 'Italian', it: 'Italian', msa: 'Malay', may: 'Malay', vie: 'Vietnamese', vie: 'Vietnamese', zho: 'Chinese', zh: 'Chinese', tha: 'Thai', th: 'Thai' };
    return labels[text] || (text ? text.toUpperCase() : 'Subtitle');
  }

  function mapSubtitles(list) {
    if (!Array.isArray(list)) return [];
    return list.map(function (raw) {
      if (!raw || typeof raw !== 'object') return null;
      var url = absoluteUrl(raw.url || raw.file, BASE_URL);
      if (!url) return null;
      var lang = clean(raw.lang || raw.language || 'und');
      return { url: url, file: url, lang: lang, language: lang, label: clean(raw.label) || languageLabel(lang), headers: playbackHeaders(raw) };
    }).filter(Boolean);
  }

  function dedupeSubtitles(items) {
    var seen = Object.create(null);
    return (items || []).filter(function (item) {
      var key = item.url + '|' + item.lang;
      if (seen[key]) return false;
      seen[key] = true;
      return true;
    });
  }

  function masterVariantUrl(playlist, base) {
    var lines = String(playlist || '').split(/\r?\n/);
    var variants = [];
    for (var i = 0; i < lines.length; i += 1) {
      var line = clean(lines[i]);
      if (line.toUpperCase().indexOf('#EXT-X-STREAM-INF:') !== 0) continue;
      var bandwidthMatch = line.match(/BANDWIDTH=(\d+)/i);
      var bandwidth = bandwidthMatch ? parseInt(bandwidthMatch[1], 10) : 0;
      for (var j = i + 1; j < lines.length; j += 1) {
        var candidate = clean(lines[j]);
        if (!candidate || candidate.charAt(0) === '#') continue;
        var resolved = resolveRelativeUrl(candidate, base);
        if (resolved) variants.push({ url: resolved, bandwidth: bandwidth });
        break;
      }
    }
    variants.sort(function (a, b) { return b.bandwidth - a.bandwidth; });
    return variants.length ? variants[0].url : '';
  }

  async function prepareHlsUrl(url) {
    var response = await requestText(url, { Accept: HLS_ACCEPT });
    if (!response.ok) {
      // Keep an unprobed URL only for transport failures. An explicit HTTP
      // error is a bad candidate and should not win the player race.
      return { url: url, valid: response.status === 0 };
    }
    var body = String(response.text || '').trim();
    if (body.indexOf('#EXTM3U') < 0) return { url: url, valid: true };
    var child = masterVariantUrl(body, url);
    return { url: child || url, valid: true };
  }

  function streamPreference(stream) {
    var url = clean(stream && stream.url).toLowerCase();
    var score = 0;
    // Prefer a directly addressable media playlist. Some older decoders do
    // not follow protocol-relative child playlists in a master manifest.
    if (url.indexOf('/master/') >= 0) score -= 20;
    if (url.indexOf('/child/') >= 0) score += 10;
    if (url.indexOf('.m3u8') >= 0) score += 2;
    return score;
  }

  function playbackHeaders(raw) {
    var headers = streamHeaders();
    var supplied = raw && (raw.behaviorHints && raw.behaviorHints.proxyHeaders && raw.behaviorHints.proxyHeaders.request || raw.headers);
    Object.keys(supplied || {}).forEach(function (key) {
      if (/^[a-z0-9-]+$/i.test(key) && typeof supplied[key] === 'string' && !/[\r\n]/.test(supplied[key])) {
        Object.keys(headers).forEach(function (existing) { if (existing.toLowerCase() === key.toLowerCase()) delete headers[existing]; });
        headers[key] = supplied[key];
      }
    });
    return headers;
  }

  async function extractStreamUrl(episodeHref, lang) {
    var requested = clean(lang || 'sub').toLowerCase() || 'sub';
    if (requested !== 'sub') {
      return { streams: [], subtitles: [], lang: requested, error: { message: 'YASTREAM exposes original-audio streams; no verified dub route is available.' } };
    }
    var ref = parseRoute(episodeHref);
    if (!ref || !ref.id) return { streams: [], subtitles: [], lang: requested, error: { message: 'Invalid YASTREAM episode reference' } };
    var loaded;
    try {
      loaded = await requestJson(ref.kind === 'stream' ? makeRoute('stream', ref.type, ref.id) : makeRoute('stream', ref.type || 'series', ref.id));
    } catch (error) {
      return { streams: [], subtitles: [], lang: requested, error: { message: String(error && error.message || error) } };
    }
    var rawStreams = loaded && Array.isArray(loaded.streams) ? loaded.streams : [];
    var subtitles = [];
    try {
      var subtitlePayload = await requestJson(makeRoute('subtitles', ref.type || 'series', ref.id));
      subtitles = mapSubtitles(subtitlePayload && subtitlePayload.subtitles);
    } catch (_) {}
    var streams = [], seen = Object.create(null);
    var deadline = Date.now() + 20000;
    for (var index = 0; index < rawStreams.length; index += 1) {
      if (Date.now() >= deadline || index >= 6) break;
      var raw = rawStreams[index];
      var url = absoluteUrl(raw && (raw.url || raw.file || raw.stream), BASE_URL);
      if (!url) continue;
      var type = /\.m3u8(?:$|[?#])/i.test(url) ? 'hls' : (/\.mp4(?:$|[?#])/i.test(url) ? 'mp4' : 'hls');
      var label = clean(raw.name || raw.title || raw.description) || ('Source ' + (index + 1));
      var headers = playbackHeaders(raw);
      var key = url + JSON.stringify(headers);
      if (seen[key]) continue;
      seen[key] = true;
      var checked = await globalThis.__trioMedia.check({url: url, headers: headers, name: label,
        provider: 'yastream', kind: type, streamType: type,
        subtitles: dedupeSubtitles(mapSubtitles(raw.subtitles).concat(subtitles))}, deadline);
      if (checked) streams.push(checked);
    }
    if (!streams.length) return { streams: [], subtitles: [], lang: requested, error: { message: 'YASTREAM returned no media URL' } };
    var result = globalThis.__trioMedia.result(streams, 'sub');
    result.audioLanguage = 'original';
    return result;
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { searchResults: searchResults, extractDetails: extractDetails, extractEpisodes: extractEpisodes, extractStreamUrl: extractStreamUrl, discoveryHome: discoveryHome, discoveryFeed: discoveryFeed };
  }
})();
