(() => {
  'use strict';
  const MODULE_NAME = 'toonix-v1';
  const BASE = 'https://toonix.bond';
  const USER_AGENT =
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

  const PAGE_TTL_MS = 10 * 60 * 1000;
  const CATALOG_TTL_MS = 15 * 60 * 1000;
  const STREAM_TTL_MS = 5 * 60 * 1000;
  const HOST_PARK_MS = 15 * 60 * 1000;
  const REQ_TIMEOUT_MS = 20000;
  const MAX_EPISODES = 400;
  const MAX_SEASONS = 30;
  const SEARCH_MAX_RESULTS = 60;
  const FEED_PAGE_SIZE = 50;

  // Language evidence map (sampled 2026-09-12, whisper small; see
  // qa-language-evidence.md + qa coverage sweep). The catalogue is MIXED: most
  // sampled titles carry Hindi dub audio, some carry the English original
  // (Avatar sampled `en` 0.64; Batman TAS `hi` 0.97). Anything outside this map
  // gets NO language word in its label - never a blanket claim, never a guess.
  const LANG_BY_SLUG = {
    'ben-10': 'Hindi',
    'ben-10-alien-force': 'Hindi',
    'ben-10-ultimate-alien': 'Hindi',
    'ben-10-omniverse': 'Hindi',
    'ben-10-reboot': 'Hindi',
    'doraemon': 'Hindi',
    'shin-chan': 'Hindi',
    'pokemon': 'Hindi',
    'chhota-bheem': 'Hindi',
    'batman-the-animated-series': 'Hindi',
    'adventure-time': 'Hindi',
    'chacha-bhatija': 'Hindi',
    'bandbudh-aur-budbak': 'Hindi',
    'roll-no-21': 'Hindi',
    '2112-the-birth-of-doraemon': 'Hindi',
    'avatar-the-last-airbender': 'English',
  };

  function langWordFor(slug) {
    const ev = LANG_BY_SLUG[String(slug || '').toLowerCase()];
    if (!ev) return '';
    return ev === 'Hindi' ? 'Hindi Dub' : ev;
  }

  function routeLabel(slug, height) {
    const parts = [];
    const word = langWordFor(slug);
    if (word) parts.push(word);
    parts.push(PROVIDER_LABEL);
    if (height) parts.push(height + 'p');
    return parts.join(' · ');
  }

  // Route `lang` is the app's sub/dub routing code (routes are filtered against
  // the viewer's preference), not a language claim - the label carries language.
  const WORKER_LANG = 'dub';
  const WORKER_LANG_LABEL = 'Hindi Dub';
  const PROVIDER_LABEL = 'Toonix';

  const HLS_HOSTS = [
    'https://v1.hlsfastcdn.workers.dev',
    'https://v2.hlsfastnet.workers.dev',
    'https://v3.hlsfastio.workers.dev',
  ];

  const hostParked = Object.create(null);
  const pageCache = Object.create(null);
  const streamCache = Object.create(null);
  let catalogCache = null;

  function log(msg) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(msg || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((r) => setTimeout(r, Math.max(1, Number(ms) || 0)));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return Promise.race([promise, sleep(waitMs).then(() => fallback)]);
  }

  function cleanText(value) {
    return String(value == null ? '' : value)
      .replace(/\s+/g, ' ')
      .trim();
  }

  function htmlUnescape(value) {
    return String(value == null ? '' : value)
      .replace(/&amp;/g, '&')
      .replace(/&#x27;/g, "'")
      .replace(/&#39;/g, "'")
      .replace(/&quot;/g, '"')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&nbsp;/g, ' ');
  }

  function escapeRegExp(value) {
    return String(value == null ? '' : value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  async function readResponseBody(res) {
    if (!res) return '';
    if (res.json !== undefined && res.json !== null && typeof res.json !== 'function') {
      try {
        return JSON.stringify(res.json);
      } catch (_) {}
    }
    if (typeof res.body === 'string' && res.body.length) return res.body;
    if (typeof res.text === 'function') {
      try {
        const text = await res.text();
        if (typeof text === 'string' && text.length) return text;
      } catch (_) {}
    }
    if (typeof res.json === 'function') {
      try {
        return JSON.stringify(await res.json());
      } catch (_) {}
    }
    return '';
  }

  function hostOf(url) {
    try {
      return String(new URL(String(url)).host || '');
    } catch (_) {
      const m = String(url || '').match(/^https?:\/\/([^/]+)/i);
      return m ? m[1] : '';
    }
  }

  function parkedUntil(host) {
    const until = hostParked[host] || 0;
    return until > Date.now() ? until : 0;
  }

  function parkHost(host, status) {
    if (!host) return;
    hostParked[host] = Date.now() + HOST_PARK_MS;
    log('host parked for 15m after HTTP ' + status + ': ' + host);
  }

  function mediaHeaders() {
    return {
      'User-Agent': USER_AGENT,
      Referer: BASE + '/',
      Origin: BASE,
    };
  }

  function headerOf(headers, name) {
    if (!headers) return '';
    const want = String(name).toLowerCase();
    if (typeof headers.get === 'function') {
      try {
        return headers.get(name) || '';
      } catch (_) {}
    }
    const keys = Object.keys(headers);
    for (let i = 0; i < keys.length; i++) {
      if (keys[i].toLowerCase() === want) {
        const v = headers[keys[i]];
        return v == null ? '' : String(v);
      }
    }
    return '';
  }

  async function request(url, options) {
    const cfg = options || {};
    const method = cfg.method || 'GET';
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/xhtml+xml,application/json,*/*',
        Origin: BASE,
        Referer: BASE + '/',
      },
      cfg.headers || {},
    );
    const body = cfg.body == null ? null : cfg.body;
    const host = hostOf(url);
    const parked = cfg.ignorePark ? 0 : parkedUntil(host);
    if (parked) {
      return { ok: false, status: 429, rateLimited: true, parkedUntil: parked, host, body: '', json: null, headers: {} };
    }
    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body, cfg.fetchOpts || undefined);
        const status = Number((res && res.status) || 0);
        if (status === 429 || status === 403) parkHost(host, status);
        const textBody = await readResponseBody(res);
        return {
          ok: !!(res && (res.ok === true || (status >= 200 && status < 300))),
          status,
          rateLimited: status === 429,
          host,
          body: textBody,
          json: (function () {
            try {
              return JSON.parse(String(textBody || '').trim());
            } catch (_) {
              return null;
            }
          })(),
          headers: (res && res.headers) || {},
        };
      }
      if (typeof fetch === 'function') {
        const res = await fetch(url, Object.assign({ method, headers, body }, cfg.fetchOpts || {}));
        const textBody = await res.text();
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          body: textBody,
          json: null,
          headers: {},
        };
      }
    } catch (e) {
      log('request error: ' + (e && e.message ? e.message : String(e)));
    }
    return { ok: false, status: 0, body: '', json: null, headers: {} };
  }

  // ---------- flight-payload helpers ----------

  function normFlight(html) {
    return String(html == null ? '' : html).replace(/\\+"/g, '"');
  }

  function walkBraces(text, openIdx) {
    if (!text || openIdx < 0 || text.charAt(openIdx) !== '{') return null;
    let depth = 0;
    let inStr = false;
    let esc = false;
    const max = Math.min(text.length, openIdx + 200000);
    for (let i = openIdx; i < max; i++) {
      const ch = text.charAt(i);
      if (inStr) {
        if (esc) esc = false;
        else if (ch === '\\') esc = true;
        else if (ch === '"') inStr = false;
      } else if (ch === '"') {
        inStr = true;
      } else if (ch === '{') {
        depth += 1;
      } else if (ch === '}') {
        depth -= 1;
        if (depth === 0) return text.slice(openIdx, i + 1);
      }
    }
    return null;
  }

  function pluckCardFields(text, href) {
    if (!text) return null;
    const g = (re) => {
      const mm = text.match(re);
      return mm ? mm[1] : '';
    };
    const title = g(/"title":"([^"]*)"/);
    const poster = g(/"poster":"([^"]*)"/);
    const yearRaw = g(/"year":(null|\d{4})/);
    const type = g(/"type":"([^"]*)"/);
    const genresRaw = g(/"genres":\[([^\]]*)\]/);
    const genres = genresRaw
      ? genresRaw
          .split(',')
          .map((s) => htmlUnescape(s.replace(/^\s*"|"\s*$/g, '')))
          .filter(Boolean)
      : [];
    return {
      slug: String(href || '').replace(/^\/[^/]+\//, ''),
      href: href || '',
      poster: poster || '',
      title: htmlUnescape(title || ''),
      year: yearRaw && yearRaw !== 'null' ? parseInt(yearRaw, 10) : null,
      type: type || '',
      genres,
    };
  }

  function parseCards(html) {
    const t = normFlight(html);
    const out = [];
    const seen = Object.create(null);
    const re = /"href":"(\/(?:show|title)\/[^"\\]{1,180})"/g;
    let m;
    while ((m = re.exec(t))) {
      const href = m[1];
      if (seen[href]) continue;
      let card = null;
      const start = t.lastIndexOf('{"slug":"', m.index);
      if (start >= 0 && t.indexOf('{', m.index) >= start) {
        const objText = walkBraces(t, start);
        if (objText) {
          try {
            card = JSON.parse(objText);
          } catch (_) {
            card = pluckCardFields(objText, href);
          }
        }
      }
      if (!card || !card.href) {
        card = pluckCardFields(t.slice(Math.max(0, m.index - 500), m.index + 900), href);
      }
      if (!card || !card.href || !card.title) continue;
      seen[href] = 1;
      if (!card.slug) card.slug = String(card.href).replace(/^\/[^/]+\//, '');
      out.push(card);
    }
    return out;
  }

  function toResult(card) {
    const r = {
      href: card.href,
      title: card.title,
      image: card.poster || card.image || '',
    };
    if (card.year) r.year = card.year;
    if (card.type) r.type = card.type;
    return r;
  }

  // ---------- caching ----------

  async function getPage(path, ttlMs) {
    const cached = pageCache[path];
    if (cached && Date.now() - cached.savedAt < (ttlMs || PAGE_TTL_MS)) return cached.text;
    const res = await settleWithin(request(BASE + path), REQ_TIMEOUT_MS, null);
    if (res && res.ok && typeof res.body === 'string' && res.body.length) {
      pageCache[path] = { savedAt: Date.now(), text: res.body };
      return res.body;
    }
    return cached ? cached.text : null;
  }

  async function getCatalog() {
    if (catalogCache && Date.now() - catalogCache.savedAt < CATALOG_TTL_MS) return catalogCache.cards;
    const html = await getPage('/search', CATALOG_TTL_MS);
    if (!html) return catalogCache ? catalogCache.cards : [];
    const cards = parseCards(html);
    if (cards.length) catalogCache = { savedAt: Date.now(), cards };
    return cards;
  }

  // ---------- refs ----------

  function parseRef(raw) {
    let s = cleanText(raw);
    if (!s) return null;
    s = s.replace(/^https?:\/\/[^/]+/i, '');
    s = s.replace(/\/+$/, '');
    let m;
    if ((m = s.match(/^\/show\/([a-z0-9-]+)\/(\d+)\/(\d+)$/i))) return { kind: 'episode', slug: m[1], season: parseInt(m[2], 10), ep: parseInt(m[3], 10) };
    if ((m = s.match(/^\/show\/([a-z0-9-]+)\/(\d+)$/i))) return { kind: 'season', slug: m[1], season: parseInt(m[2], 10) };
    if ((m = s.match(/^\/show\/([a-z0-9-]+)$/i))) return { kind: 'show', slug: m[1] };
    if ((m = s.match(/^\/title\/([a-z0-9-]+)$/i))) return { kind: 'movie', slug: m[1] };
    if ((m = s.match(/^\/watch\/([a-z0-9-]+)$/i))) return { kind: 'watch', slug: m[1] };
    if (/^[a-z0-9][a-z0-9-]{0,119}$/i.test(s)) return { kind: 'show', slug: s };
    return null;
  }

  // ---------- search ----------

  function normalizeForMatch(value) {
    return String(value == null ? '' : value)
      .toLowerCase()
      .replace(/['\u2019]s\b/g, ' ')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  }

  async function searchResults(query, page) {
    const q = cleanText(query).toLowerCase();
    const cards = await getCatalog();
    if (!cards.length) return [];
    if (!q) {
      // Empty query = the app's legacy home row: serve the catalogue front page
      // (the runtime home step calls searchResults('') when discovery is absent).
      const home = [];
      for (let i = 0; i < cards.length && home.length < 40; i++) home.push(toResult(cards[i]));
      log('searchResults(empty) -> home catalogue ' + home.length);
      return home;
    }
    // Punctuation must not break a match: "doraemon nobita dinosaur" has to find
    // "Doraemon: Nobita's Dinosaur". Normalize both sides (drop possessives and
    // punctuation) and fall back to token-subset matching.
    const qNorm = normalizeForMatch(q);
    const qTokens = qNorm.split(' ').filter(Boolean);
    const boundary = new RegExp('(^|[^a-z0-9])' + escapeRegExp(qNorm));
    const hits = [];
    for (let i = 0; i < cards.length; i++) {
      const c = cards[i];
      const titleNorm = normalizeForMatch(c.title);
      const slugNorm = normalizeForMatch(String(c.slug || '').replace(/-/g, ' '));
      const titleTokens = titleNorm.split(' ').filter(Boolean);
      const slugTokens = slugNorm.split(' ').filter(Boolean);
      const allIn = (tokens, list) => tokens.length > 0 && tokens.every((t) => list.indexOf(t) >= 0);
      let score = 0;
      if (titleNorm === qNorm) score = 100;
      else if (titleNorm.indexOf(qNorm) === 0) score = 80;
      else if (boundary.test(titleNorm)) score = 70;
      else if (titleNorm.indexOf(qNorm) >= 0) score = 60;
      else if (slugNorm.indexOf(qNorm) >= 0) score = 45;
      else if (allIn(qTokens, titleTokens)) score = 40;
      else if (allIn(qTokens, slugTokens)) score = 30;
      else if (Array.isArray(c.genres) && c.genres.some((g) => normalizeForMatch(g).indexOf(qNorm) >= 0)) score = 25;
      if (score) hits.push({ c, score });
    }
    hits.sort((a, b) => b.score - a.score || String(a.c.title).length - String(b.c.title).length);
    const out = [];
    for (let i = 0; i < hits.length && out.length < SEARCH_MAX_RESULTS; i++) out.push(toResult(hits[i].c));
    log('searchResults "' + q + '" -> ' + out.length + ' hits');
    return out;
  }

  // ---------- details ----------

  async function extractDetails(urlOrId) {
    const ref = parseRef(urlOrId);
    if (!ref) return { title: '', description: '' };
    let path = null;
    if (ref.kind === 'show' || ref.kind === 'season' || ref.kind === 'episode') path = '/show/' + ref.slug;
    else if (ref.kind === 'movie') path = '/title/' + ref.slug;
    else if (ref.kind === 'watch') path = '/title/' + ref.slug;
    if (!path) return { title: '', description: '' };
    const html = await getPage(path, PAGE_TTL_MS);
    if (!html) return { title: '', description: '' };
    const t = normFlight(html);
    let title = '';
    const tm = html.match(/<title>([^<]*)<\/title>/);
    if (tm) title = cleanText(htmlUnescape(tm[1]).replace(/\s*[·-]\s*Toonix\s*$/i, ''));
    let description = '';
    const dm = html.match(/<meta\s+name="description"\s+content="([^"]*)"/i);
    if (dm) {
      description = cleanText(htmlUnescape(dm[1]));
      if (/^Toonix is a clean, fast streaming platform/i.test(description)) description = '';
    }
    let image = '';
    const im = t.match(/"poster":"(https:\/\/[^"]+)"/);
    if (im) image = im[1];
    const out = { title: title || ref.slug, description, url: path };
    if (image) out.image = image;
    return out;
  }

  // ---------- episodes ----------

  function parseSeasonNumbers(t, slug) {
    const re = new RegExp('"/show/' + escapeRegExp(slug) + '/(\\d+)"', 'g');
    const seen = Object.create(null);
    const out = [];
    let m;
    while ((m = re.exec(t))) {
      const n = parseInt(m[1], 10);
      if (isNaN(n) || seen[n]) continue;
      seen[n] = 1;
      out.push(n);
    }
    return out;
  }

  function parseSeasonEpisodes(t, slug, season) {
    const re = new RegExp('"/show/' + escapeRegExp(slug) + '/' + season + '/(\\d+)"', 'g');
    const seen = Object.create(null);
    const out = [];
    let m;
    while ((m = re.exec(t))) {
      const en = parseInt(m[1], 10);
      if (isNaN(en) || seen[en]) continue;
      seen[en] = 1;
      const win = t.slice(m.index, m.index + 1400);
      let title = '';
      const am = win.match(/"alt":"([^"]{1,300})"/) || win.match(/alt="([^"]{1,300})"/);
      if (am) title = cleanText(htmlUnescape(am[1]));
      out.push({ en, title });
    }
    out.sort((a, b) => a.en - b.en);
    return out;
  }

  async function mapLimited(items, limit, fn) {
    const out = new Array(items.length);
    let next = 0;
    const n = Math.max(1, Math.min(limit, items.length));
    const workers = [];
    for (let w = 0; w < n; w++) {
      workers.push(
        (async () => {
          for (;;) {
            const i = next++;
            if (i >= items.length) return;
            try {
              out[i] = await fn(items[i], i);
            } catch (_) {
              out[i] = null;
            }
          }
        })(),
      );
    }
    await Promise.all(workers);
    return out;
  }

  async function extractEpisodes(seriesId) {
    const ref = parseRef(seriesId);
    if (!ref) return [];
    if (ref.kind === 'movie' || ref.kind === 'watch') {
      return [
        {
          number: 1,
          href: '/watch/' + ref.slug,
          title: 'Movie',
          subAvailable: false,
          dubAvailable: true,
        },
      ];
    }
    if (ref.kind === 'episode') return [];
    const showPath = '/show/' + ref.slug;
    const html = await getPage(showPath, PAGE_TTL_MS);
    if (!html) return [];
    const t = normFlight(html);
    let seasons = parseSeasonNumbers(t, ref.slug);
    if (ref.kind === 'season' && seasons.indexOf(ref.season) >= 0) {
      seasons = [ref.season];
    }
    if (!seasons.length) seasons = [1];
    if (seasons.length > MAX_SEASONS) {
      log('season list capped at ' + MAX_SEASONS + ' for ' + ref.slug);
      seasons = seasons.slice(0, MAX_SEASONS);
    }
    const seasonHtmls = await mapLimited(seasons, 3, (sn) =>
      getPage(showPath + '/' + sn, PAGE_TTL_MS),
    );
    const out = [];
    for (let i = 0; i < seasons.length; i++) {
      if (out.length >= MAX_EPISODES) break;
      const sn = seasons[i];
      const sHtml = seasonHtmls[i];
      if (!sHtml) continue;
      const eps = parseSeasonEpisodes(normFlight(sHtml), ref.slug, sn);
      for (let e = 0; e < eps.length; e++) {
        const en = eps[e].en;
        out.push({
          number: out.length + 1,
          seasonNumber: sn,
          episodeNumber: en,
          href: '/show/' + ref.slug + '/' + sn + '/' + en,
          title: sn > 0 ? 'S' + sn + 'E' + en : 'SP' + en,
          subAvailable: false,
          dubAvailable: true,
        });
        if (out.length >= MAX_EPISODES) break;
      }
    }
    if (out.length >= MAX_EPISODES) log('episode list capped at ' + MAX_EPISODES + ' for ' + ref.slug);
    log('extractEpisodes ' + ref.slug + ' -> ' + out.length + ' eps (' + seasons.length + ' seasons)');
    return out;
  }

  // ---------- streams ----------

  function noRoute(message, code) {
    return {
      streams: [],
      subtitles: [],
      error: { code: code || 'NO_ROUTE', message: message || 'No usable route for this episode.' },
    };
  }

  function extractSrcFromPage(t) {
    if (!t) return null;
    const m = t.match(/"src":"(https:[^"]+)","poster"/);
    if (m) return m[1];
    const re = /"src":"(https:[^"]+)"/g;
    let mm;
    while ((mm = re.exec(t))) {
      const u = mm[1];
      if (/workers\.dev\/ep\//.test(u) || /\.mp4(\?|#|$)/i.test(u) || /\.m3u8(\?|#|$)/i.test(u)) return u;
    }
    return null;
  }

  function isWorkerSrc(url) {
    return /^https:\/\/v[123]\.(?:hlsfastcdn|hlsfastnet|hlsfastio)\.workers\.dev\/ep\//.test(String(url || ''));
  }

  function absUrl(u, base) {
    const s = String(u || '').trim().replace(/^["']|["']$/g, '');
    if (/^https?:\/\//i.test(s)) return s;
    if (s.indexOf('//') === 0) return 'https:' + s;
    const m = String(base || '').match(/^(https?:\/\/[^/]+)(\/.*)?$/);
    const origin = m ? m[1] : BASE;
    const path = m && m[2] ? m[2] : '/';
    if (s.charAt(0) === '/') return origin + s;
    return origin + path.replace(/[^/]*$/, '') + s;
  }

  function parseMasterPlaylist(text, baseUrl) {
    const lines = String(text || '').split('\n');
    const variants = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i].trim();
      if (l.indexOf('#EXT-X-STREAM-INF') !== 0) continue;
      const attrs = l.slice(l.indexOf(':') + 1);
      let height = null;
      let bandwidth = null;
      const rm = attrs.match(/RESOLUTION=\d+x(\d+)/i);
      if (rm) height = parseInt(rm[1], 10);
      const bm = attrs.match(/BANDWIDTH=(\d+)/i);
      if (bm) bandwidth = parseInt(bm[1], 10);
      for (let j = i + 1; j < lines.length; j++) {
        const n = lines[j].trim();
        if (!n) continue;
        if (n.charAt(0) === '#') continue;
        variants.push({ url: absUrl(n, baseUrl), height, bandwidth });
        i = j;
        break;
      }
    }
    variants.sort((a, b) => (b.height || 0) - (a.height || 0) || (b.bandwidth || 0) - (a.bandwidth || 0));
    return variants;
  }

  function mediaSegments(text, baseUrl) {
    const lines = String(text || '').split('\n');
    const segs = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i].trim();
      if (!l || l.charAt(0) === '#') continue;
      segs.push(absUrl(l, baseUrl));
    }
    return segs;
  }

  function isMediaPlaylist(text) {
    return /^\s*#EXTM3U/.test(text) && !/#EXT-X-STREAM-INF/.test(text);
  }

  function mirrorUrlsFor(url) {
    const m = String(url || '').match(/^https:\/\/v[123]\.(?:hlsfastcdn|hlsfastnet|hlsfastio)\.workers\.dev(\/.*)$/);
    if (!m) return [url];
    const out = [url];
    for (let i = 0; i < HLS_HOSTS.length; i++) {
      const u = HLS_HOSTS[i] + m[1];
      if (u !== url) out.push(u);
    }
    return out;
  }

  function withHlsHint(url) {
    // The CDN's episode endpoint serves an HLS playlist (content-type
    // application/vnd.apple.mpegurl) from an extension-less path (/ep/<id>).
    // Some HLS consumers - the S2 analyzer's ffprobe path included - gate their
    // permissive segment-extension flags on the URL shape, and ffmpeg 8's default
    // HLS policy rejects the CDN's extension-less segment paths (/a/<id>) outright.
    // Signal HLS explicitly with a parameter the CDN ignores (verified 2026-09-12:
    // the response is byte-identical). The app's bundled ffmpeg 6.0 needs no hint.
    const u = String(url || '');
    if (/\.m3u8(?:\?|$)|\/m3u8\//i.test(u)) return u;
    return u + (u.indexOf('?') >= 0 ? '&' : '?') + 'ext=.m3u8';
  }

  async function probeSegment(url) {
    const res = await settleWithin(
      request(url, { headers: Object.assign({ Range: 'bytes=0-1' }, mediaHeaders()), ignorePark: true }),
      12000,
      null,
    );
    if (!res) return false;
    return res.status === 200 || res.status === 206;
  }

  async function buildHlsResult(src, slug) {
    const pl = await settleWithin(request(src, { headers: mediaHeaders() }), REQ_TIMEOUT_MS, null);
    const body = pl && pl.ok ? String(pl.body || '') : '';
    if (!/^\s*#EXTM3U/.test(body)) {
      log('hls playlist unavailable (status ' + (pl ? pl.status : 'timeout') + ')');
      return noRoute('Source unavailable for this episode (upstream stream token missing).', 'SOURCE_UNAVAILABLE');
    }
    const variants = parseMasterPlaylist(body, src);
    const routes = [];
    let topProbeUrl = null;
    if (variants.length) {
      const top = variants[0];
      const vres = await settleWithin(request(top.url, { headers: mediaHeaders() }), REQ_TIMEOUT_MS, null);
      const vbody = vres && vres.ok ? String(vres.body || '') : '';
      let topSegs = [];
      if (isMediaPlaylist(vbody)) topSegs = mediaSegments(vbody, top.url);
      if (!topSegs.length) {
        log('top variant playlist unavailable');
        return noRoute('Variant playlist unavailable upstream.', 'SOURCE_UNAVAILABLE');
      }
      topProbeUrl = topSegs[0];
      for (let i = 0; i < variants.length; i++) {
        const v = variants[i];
        routes.push({
          label: routeLabel(slug, v.height),
          url: withHlsHint(v.url),
          height: v.height || undefined,
          bandwidth: v.bandwidth || undefined,
          streamType: 'hls',
          kind: 'hls',
          provider: 'toonix',
          lang: WORKER_LANG,
          headers: mediaHeaders(),
        });
      }
    } else {
      const segs = mediaSegments(body, src);
      if (!segs.length) return noRoute('Playlist contains no segments.', 'SOURCE_UNAVAILABLE');
      topProbeUrl = segs[0];
      routes.push({
        label: routeLabel(slug, null),
        url: withHlsHint(src),
        streamType: 'hls',
        kind: 'hls',
        provider: 'toonix',
        lang: WORKER_LANG,
        headers: mediaHeaders(),
      });
    }
    let probeOk = false;
    if (topProbeUrl) {
      probeOk = await probeSegment(topProbeUrl);
      if (!probeOk) log('segment byte probe inconclusive; keeping validated playlist');
    }
    return assemble(routes, probeOk);
  }

  async function validateMp4(url) {
    let resolved = url;
    // Range on BOTH requests: archive.org serves 302 -> node URL, and probing the
    // resolved file without a Range would pull the whole movie inside the bridge.
    const probeHeaders = Object.assign({ Range: 'bytes=0-1023' }, mediaHeaders());
    const head = await settleWithin(
      request(url, { headers: probeHeaders, fetchOpts: { followRedirects: false }, ignorePark: true }),
      15000,
      null,
    );
    if (head && [301, 302, 303, 307, 308].indexOf(head.status) >= 0) {
      const loc = headerOf(head.headers, 'location');
      if (loc) resolved = absUrl(loc, url);
    }
    const probe = await settleWithin(
      request(resolved, { headers: probeHeaders, ignorePark: true }),
      15000,
      null,
    );
    if (!probe) return { ok: false, status: 0, resolved };
    const okStatus = probe.status === 200 || probe.status === 206;
    const bodyHead = String(probe.body || '').slice(0, 64);
    const sig = bodyHead.indexOf('ftyp') >= 0;
    const ct = headerOf(probe.headers, 'content-type');
    const ok = okStatus && (sig || /video\/|octet-stream/i.test(ct));
    return { ok, status: probe.status, resolved, sig, ct };
  }

  async function buildMp4Result(src, slug) {
    const v = await validateMp4(src);
    if (!v.ok) {
      log('mp4 route failed validation (status ' + (v.status || '?') + ')');
      return noRoute('Source file unavailable upstream (HTTP ' + (v.status || '?') + ').', 'SOURCE_UNAVAILABLE');
    }
    const word = langWordFor(slug);
    const route = {
      label: (word ? word + ' · ' : '') + 'Direct MP4',
      url: v.resolved,
      streamType: 'mp4',
      kind: 'mp4',
      provider: 'file',
      lang: WORKER_LANG,
      headers: mediaHeaders(),
    };
    return {
      streams: [route],
      qualities: [],
      servers: [
        { name: PROVIDER_LABEL + ' CDN', server: PROVIDER_LABEL + ' CDN', url: v.resolved, headers: mediaHeaders(), lang: WORKER_LANG, streamType: 'mp4' },
      ],
      url: v.resolved,
      stream: v.resolved,
      headers: mediaHeaders(),
      streamType: 'mp4',
      subtitles: [],
      lang: WORKER_LANG,
    };
  }

  function assemble(routes, probeOk) {
    const top = routes[0];
    const mirrors = mirrorUrlsFor(top.url);
    const servers = [];
    for (let i = 0; i < mirrors.length; i++) {
      const name = i === 0 ? PROVIDER_LABEL + ' CDN' : PROVIDER_LABEL + ' CDN ' + (i + 1);
      servers.push({
        name,
        server: name,
        url: mirrors[i],
        headers: mediaHeaders(),
        lang: WORKER_LANG,
        streamType: 'hls',
      });
    }
    const qualities = [];
    for (let i = 0; i < routes.length; i++) {
      const r = routes[i];
      if (!r.height) continue;
      qualities.push({ label: r.height + 'p · ' + PROVIDER_LABEL, url: r.url, headers: r.headers, height: r.height });
    }
    const result = {
      streams: routes,
      qualities,
      servers,
      url: top.url,
      stream: top.url,
      headers: top.headers,
      streamType: top.streamType || 'hls',
      subtitles: [],
      lang: WORKER_LANG,
    };
    if (top.height) result.quality = top.height;
    log('streams ok: routes=' + routes.length + ' mirrors=' + servers.length + ' probe=' + (probeOk ? 'ok' : 'inconclusive'));
    return result;
  }

  async function extractStreamUrl(episodeHref, lang) {
    const ref = parseRef(episodeHref);
    if (!ref || (ref.kind !== 'episode' && ref.kind !== 'watch' && ref.kind !== 'movie')) {
      return noRoute('Unrecognised episode reference.', 'BAD_REF');
    }
    const path = ref.kind === 'episode' ? '/show/' + ref.slug + '/' + ref.season + '/' + ref.ep : '/watch/' + ref.slug;
    const cached = streamCache[path];
    if (cached && Date.now() - cached.savedAt < STREAM_TTL_MS) {
      log('extractStreamUrl cache hit: ' + path);
      return cached.result;
    }
    const html = await getPage(path, PAGE_TTL_MS);
    if (!html) return noRoute('Page fetch failed.', 'PAGE_FETCH_FAILED');
    const src = extractSrcFromPage(normFlight(html));
    if (!src) return noRoute('No playable source found on this page.', 'SOURCE_UNAVAILABLE');
    const result = isWorkerSrc(src) ? await buildHlsResult(src, ref.slug) : await buildMp4Result(src, ref.slug);
    if (String(lang || '').toLowerCase() === 'sub') {
      log('sub requested; source carries ' + WORKER_LANG_LABEL + ' audio only (reported as dub)');
    }
    if (result && result.streams && result.streams.length) {
      streamCache[path] = { savedAt: Date.now(), result };
    }
    return result;
  }

  // ---------- discovery ----------

  function parseHomeSections(t) {
    // ref-defs map (NN:{"slug":...) used by some rows
    const defs = Object.create(null);
    const dre = /(\d+):\{"slug":"/g;
    let dm;
    while ((dm = dre.exec(t))) {
      const ot = walkBraces(t, t.indexOf('{', dm.index));
      if (!ot) continue;
      try {
        const c = JSON.parse(ot);
        if (c && c.href && c.title) defs[dm[1]] = c;
      } catch (_) {}
    }
    const sections = [];
    const seenTitles = Object.create(null);
    const re = /"viewAllHref":"([^"]+)"/g;
    let m;
    while ((m = re.exec(t))) {
      const viewAllHref = m[1];
      const tp = t.lastIndexOf('"title":"', m.index);
      if (tp < 0) continue;
      const bs = t.lastIndexOf('{', tp);
      if (bs < 0) continue;
      const objText = walkBraces(t, bs);
      if (!objText) continue;
      let j = null;
      try {
        j = JSON.parse(objText);
      } catch (_) {}
      let title = j && j.title ? j.title : '';
      if (!title) {
        const tm = objText.match(/"title":"([^"]+)"/);
        title = tm ? htmlUnescape(tm[1]) : '';
      }
      title = cleanText(htmlUnescape(title));
      if (!title || seenTitles[title]) continue;
      seenTitles[title] = 1;
      const items = [];
      const cre = /"card":\{"slug":"/g;
      let cm;
      while ((cm = cre.exec(objText))) {
        const ot = walkBraces(objText, objText.indexOf('{', cm.index));
        if (!ot) continue;
        try {
          const c = JSON.parse(ot);
          if (c && c.href && c.title) items.push(c);
        } catch (_) {}
      }
      const rre = /"card":"\$(\d+)"/g;
      let rm;
      while ((rm = rre.exec(objText))) {
        const c = defs[rm[1]];
        if (c && c.href && c.title) items.push(c);
      }
      sections.push({ title, viewAllHref, items });
    }
    return sections;
  }

  // Hero banners are full-width, so ask TMDB for a larger rendition of the same
  // image (TMDB serves any size at the same path). Non-TMDB posters pass through.
  function heroImage(url) {
    const u = String(url || '');
    if (!u) return '';
    return /image\.tmdb\.org\/t\/p\//.test(u) ? u.replace(/\/t\/p\/[^/]+\//, '/t/p/w780/') : u;
  }

  async function discoveryHome() {
    try {
      const html = await getPage('/', PAGE_TTL_MS);
      if (!html) return { sections: [] };
      const sections = [];
      const parsed = parseHomeSections(normFlight(html));
      for (let i = 0; i < parsed.length; i++) {
        const s = parsed[i];
        if (!s.items.length) continue; // collection rows are not title cards
        const id = (/trending/i.test(s.title) ? 'trending' : /movie/i.test(s.title) ? 'movies' : /show|series/i.test(s.title) ? 'shows' : 'row-' + i);
        const feedId = id === 'trending' ? null : id;
        const sec = {
          id,
          title: s.title,
          style: 'poster',
          items: s.items.slice(0, 30).map((c, idx) => ({
            href: c.href,
            title: c.title,
            image: c.poster || '',
            poster: c.poster || '',
            rank: idx + 1,
          })),
        };
        if (feedId) sec.viewAll = { mode: 'feed', feedId };
        sections.push(sec);
      }
      // A discovery-enabled module owns the whole home screen: the app's own
      // "Featured" hero carousel only renders on the legacy (non-discovery) path,
      // so a discovery module must emit the hero itself or the home screen has
      // no featured row at all.
      const heroSource =
        parsed.filter((s) => /trending/i.test(s.title) && s.items.length)[0] ||
        parsed.filter((s) => s.items.length)[0];
      if (heroSource) {
        sections.unshift({
          id: 'featured',
          title: 'Featured',
          style: 'hero',
          items: heroSource.items.slice(0, 8).map((c, idx) => ({
            href: c.href,
            title: c.title,
            image: heroImage(c.poster),
            poster: heroImage(c.poster),
            rank: idx + 1,
          })),
        });
      }
      log('discoveryHome sections=' + sections.length + ' hero=' + (heroSource ? 'yes' : 'no'));
      return { sections: sections.slice(0, 12) };
    } catch (e) {
      log('discoveryHome error: ' + (e && e.message ? e.message : e));
      return { sections: [] };
    }
  }

  function catalogueByType(cards, typeWant) {
    const out = [];
    for (let i = 0; i < cards.length; i++) {
      const c = cards[i];
      if (!c || !c.href) continue;
      const t = String(c.type || '').toUpperCase();
      const isMovie = t === 'MOVIE' || /^\/title\//.test(c.href);
      const isShow = t === 'SHOW' || /^\/show\//.test(c.href);
      if (typeWant === 'MOVIE' && isMovie) out.push(c);
      else if (typeWant === 'SHOW' && isShow) out.push(c);
    }
    return out;
  }

  async function discoveryFeed(feedId, page) {
    const id = cleanText(feedId || '');
    const p = Math.max(1, Number(page) || 1);
    try {
      if (id === 'shows' || id === 'movies') {
        const cards = await getCatalog();
        const list = catalogueByType(cards, id === 'movies' ? 'MOVIE' : 'SHOW');
        const slice = list.slice((p - 1) * FEED_PAGE_SIZE, p * FEED_PAGE_SIZE);
        return {
          items: slice.map(toResult),
          page: p,
          hasMore: p * FEED_PAGE_SIZE < list.length && slice.length > 0,
        };
      }
      if (id === 'trending') {
        const html = await getPage('/', PAGE_TTL_MS);
        const parsed = html ? parseHomeSections(normFlight(html)) : [];
        let sec = null;
        for (let i = 0; i < parsed.length; i++) if (/trending/i.test(parsed[i].title)) sec = parsed[i];
        const items = sec ? sec.items.slice(0, FEED_PAGE_SIZE) : [];
        return { items: p === 1 ? items.map(toResult) : [], page: p, hasMore: false };
      }
      return { items: [], page: p, hasMore: false };
    } catch (e) {
      log('discoveryFeed error: ' + (e && e.message ? e.message : e));
      return { items: [], page: p, hasMore: false };
    }
  }

  // exports
  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  Object.assign(globalThis, {
    searchResults,
    extractDetails,
    extractEpisodes,
    extractStreamUrl,
    discoveryHome,
    discoveryFeed,
  });
})();
