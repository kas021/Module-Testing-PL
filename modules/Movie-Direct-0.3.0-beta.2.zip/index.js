/**
 * Movie Direct 0.3.0-beta.2 private - TMDB identity + independent VideoEasy lookup.
 * Runtime hosts: api.themoviedb.org, api.speedracelight.com, VideoEasy CDNs.
 * Does not scrape StreamingUnity or YFlix. Does not label unknown/Italian as English.
 */
(function () {
  'use strict';

  var MODULE = 'Movie Direct';
  var TMDB = 'https://api.themoviedb.org/3';
  var TMDB_KEY = 'e1a8efff4415028c5c266b3fcd50db6e';
  var VIDEASY_API = 'https://api.speedracelight.com';
  var VIDEASY_PLAYER = 'https://player.videasy.to';
  var VIDEASY_MAGIC = [109, 118, 109, 49];
  var UA =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
  var FAKE = /tiktokcdn|ibyteimg|ad-site-i18n|\/obj\/ad-site|\.png(?:\?|$)/i;
  var LANGS = [
    { code: 'hi', re: /\bhindi\b/i },
    { code: 'es', re: /\b(spanish|espanol|español|latino|castellano)\b/i },
    { code: 'de', re: /\b(german|deutsch)\b/i },
    { code: 'pt', re: /\b(portuguese|portugues|português)\b/i },
    { code: 'fr', re: /\b(french|francais|français)\b/i },
    { code: 'ar', re: /\barabic\b/i },
    { code: 'it', re: /\bitalian\b/i },
    { code: 'ja', re: /\bjapanese\b/i },
    { code: 'ko', re: /\bkorean\b/i },
    { code: 'en', re: /\b(english|eng)\b/i },
  ];
  var ENGLISH_ENDPOINTS = [
    { path: '/cdn/sources-with-title', name: 'Videasy CDN' },
    { path: '/m4uhd/sources-with-title', name: 'M4UHD' },
  ];
  var metadataCache = {};
  var inflight = {};
  var providerRetryAt = 0;
  var REQUEST_LIMIT = 40;
  var RESOLVE_MS = 22000;

  function log(msg) {
    try { console.log('[' + MODULE + '] ' + String(msg || '')); } catch (_) {}
  }

  function clean(value) {
    return String(value == null ? '' : value).replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function headers(extra) {
    var out = { 'User-Agent': UA, Accept: '*/*' };
    var src = extra || {};
    Object.keys(src).forEach(function (k) { out[k] = src[k]; });
    return out;
  }

  function videasyHeaders() {
    return {
      'User-Agent': UA,
      Accept: 'application/json,text/plain,*/*',
      Origin: VIDEASY_PLAYER,
      Referer: VIDEASY_PLAYER + '/',
    };
  }

  function videasyStreamHeaders() {
    return {
      'User-Agent': UA,
      Accept: 'application/vnd.apple.mpegurl,application/x-mpegURL,video/*,*/*',
      Origin: VIDEASY_PLAYER,
      Referer: VIDEASY_PLAYER + '/',
    };
  }

  async function readBody(response) {
    if (!response) return '';
    if (typeof response.body === 'string' && response.body) return response.body;
    if (response.json && typeof response.json !== 'function') {
      try { return JSON.stringify(response.json); } catch (_) {}
    }
    if (typeof response.text === 'function') {
      try {
        var text = await response.text();
        if (typeof text === 'string' && text) return text;
      } catch (_) {}
    }
    if (typeof response.json === 'function') {
      try {
        var json = await response.json();
        if (json != null) return typeof json === 'string' ? json : JSON.stringify(json);
      } catch (_) {}
    }
    return '';
  }

  function header(response, name) {
    var values = response && response.headers;
    if (!values) return '';
    if (typeof values.get === 'function') return values.get(name) || '';
    var key = Object.keys(values).filter(function (k) { return k.toLowerCase() === name; })[0];
    return key ? String(values[key]) : '';
  }

  function failure(code, stage, status) {
    return { ok: false, status: status || 0, text: '', json: null, code: code, stage: stage };
  }

  function active(ctx) {
    return !ctx || (!ctx.closed && Date.now() < ctx.deadline && ctx.requests < REQUEST_LIMIT);
  }

  function retryDelay(value) {
    if (/^\d+(?:\.\d+)?$/.test(String(value))) return Math.max(1000, Number(value) * 1000);
    var time = Date.parse(value);
    return isFinite(time) ? Math.max(1000, time - Date.now()) : 60000;
  }

  async function request(url, extraHeaders, method, body, ctx, stage) {
    stage = stage || 'metadata';
    if (!active(ctx)) return failure('budget_exhausted', stage);
    if (!safeUrl(url)) return failure('invalid_url', stage);
    var provider = url.indexOf(VIDEASY_API + '/') === 0;
    if (provider && Date.now() < providerRetryAt) return failure('rate_limited', stage, 429);
    if (ctx) ctx.requests += 1;
    var start = Date.now();
    var timeout = Math.min(8000, ctx ? ctx.deadline - start : 8000);
    var result = await withTimeout((async function () {
      try {
        if (typeof fetchv2 !== 'function') return failure('transport_missing', stage);
        var response = await fetchv2(url, headers(extraHeaders), method || 'GET', body || null,
          { maxBytesHint: 1500000, responseClass: stage === 'segment' ? 'binary' : 'text' });
        var status = Number(response && response.status) || 0;
        if (provider && status === 429) {
          providerRetryAt = Math.max(providerRetryAt, Date.now() + retryDelay(header(response, 'retry-after')));
        }
        if (ctx && (ctx.closed || Date.now() >= ctx.deadline)) return failure('budget_exhausted', stage);
        if (status < 200 || status >= 300) return failure(status === 429 ? 'rate_limited' : 'http_error', stage, status);
        var text = await readBody(response);
        var json = null;
        try { json = JSON.parse(text); } catch (_) {}
        return { ok: true, status: status, text: text, json: json, stage: stage,
          contentType: header(response, 'content-type') };
      } catch (_) { return failure('transport_error', stage); }
    })(), timeout, failure('timeout', stage));
    if (ctx && !ctx.closed) {
      ctx.diagnostics.push({ stage: stage, status: result.status, code: result.code || 'ok',
        ms: Date.now() - start });
    }
    return result;
  }

  function withTimeout(promise, ms, fallback) {
    var timer;
    return Promise.race([promise, new Promise(function (resolve) {
      timer = setTimeout(function () { resolve(fallback); }, Math.max(1, ms));
    })]).then(function (value) {
      if (typeof clearTimeout === 'function') clearTimeout(timer);
      return value;
    }, function (error) {
      if (typeof clearTimeout === 'function') clearTimeout(timer);
      throw error;
    });
  }

  async function tmdb(path, ctx) {
    var cached = metadataCache[path];
    if (cached && cached.expires > Date.now()) return cached.data;
    var url = TMDB + path + (path.indexOf('?') >= 0 ? '&' : '?') + 'api_key=' + encodeURIComponent(TMDB_KEY) + '&language=en-US';
    var res = await request(url, { Accept: 'application/json' }, 'GET', null, ctx, 'metadata');
    if (!res.ok || !res.json || typeof res.json !== 'object') {
      var error = new Error('Metadata is unavailable.');
      error.result = res.ok ? failure('invalid_json', 'metadata', res.status) : res;
      throw error;
    }
    var keys = Object.keys(metadataCache);
    if (keys.length >= 24) delete metadataCache[keys[0]];
    metadataCache[path] = { data: res.json, expires: Date.now() + 300000 };
    return res.json;
  }

  function href(type, id, season, episode) {
    var base = 'https://www.themoviedb.org/' + type + '/' + id;
    if (type === 'tv' && season && episode) return base + '?season=' + season + '&episode=' + episode;
    return base;
  }

  function parseHref(value) {
    var raw = String(value || '').trim();
    var match = raw.match(/^(movie|tv):([1-9]\d*)(?::([1-9]\d*):([1-9]\d*))?$/i);
    if (!match) {
      var absolute = raw.match(/^https:\/\/(?:www\.)?themoviedb\.org\/(movie|tv)\/([1-9]\d*)\/?(?:\?([^#]*))?(?:#.*)?$/i);
      if (!absolute) return null;
      var params = {};
      var invalid = false;
      (absolute[3] || '').split('&').filter(Boolean).forEach(function (part) {
        var pair = part.split('=');
        if (pair[0] !== 'season' && pair[0] !== 'episode') return;
        if (params[pair[0]] || !/^[1-9]\d*$/.test(pair[1] || '')) invalid = true;
        params[pair[0]] = pair[1];
      });
      if (invalid || (!!params.season !== !!params.episode)) return null;
      match = [raw, absolute[1], absolute[2], params.season, params.episode];
    }
    if (!match) return null;
    if (match[1].toLowerCase() === 'movie' && (match[3] || match[4])) return null;
    return {
      type: match[1].toLowerCase(),
      id: String(match[2]),
      season: match[3] ? Number(match[3]) : null,
      episode: match[4] ? Number(match[4]) : null,
    };
  }

  function mapItem(row, forcedType) {
    if (!row) return null;
    var type = String(forcedType || row.media_type || '').toLowerCase();
    if (type !== 'movie' && type !== 'tv') return null;
    if (row.adult === true) return null;
    var id = Number(row.id);
    var title = clean(row.title || row.name || row.original_title || row.original_name);
    if (!id || !title) return null;
    var year = String(row.release_date || row.first_air_date || '').slice(0, 4);
    var image = row.poster_path ? 'https://image.tmdb.org/t/p/w500' + row.poster_path : '';
    return {
      id: href(type, id),
      href: href(type, id),
      title: title + (year ? ' (' + year + ')' : ''),
      image: image,
      poster: image,
      type: type,
      mediaType: type,
      year: year || undefined,
      tmdbId: id,
    };
  }

  function videasyImul(a, b) {
    if (typeof Math.imul === 'function') return Math.imul(a, b) >>> 0;
    a = a >>> 0;
    b = b >>> 0;
    var ah = (a >>> 16) & 0xffff, al = a & 0xffff;
    var bh = (b >>> 16) & 0xffff, bl = b & 0xffff;
    return ((al * bl + (((ah * bl + al * bh) << 16) >>> 0)) >>> 0) >>> 0;
  }

  function videasyU32(x) { return x >>> 0; }

  function videasyMix(e) {
    e = videasyU32(e);
    e ^= e >>> 16;
    e = videasyImul(e, 2246822507);
    e ^= e >>> 13;
    e = videasyImul(e, 3266489909);
    e ^= e >>> 16;
    return videasyU32(e);
  }

  function videasyRotl(e, t) {
    e = videasyU32(e);
    t = t & 31;
    if (!t) return e;
    return videasyU32((e << t) | (e >>> (32 - t)));
  }

  function videasyB64Decode(input) {
    var s = String(input || '').replace(/-/g, '+').replace(/_/g, '/').replace(/\s+/g, '');
    var pad = s.length % 4 === 0 ? s : s + '===='.slice(s.length % 4);
    var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var out = [];
    var buf = 0;
    var bits = 0;
    var i;
    for (i = 0; i < pad.length; i += 1) {
      var ch = pad.charAt(i);
      if (ch === '=') break;
      var v = alphabet.indexOf(ch);
      if (v < 0) continue;
      buf = (buf << 6) | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out.push((buf >>> bits) & 0xff);
      }
    }
    return out;
  }

  function videasyUtf8Decode(bytes) {
    var out = '';
    var i = 0;
    while (i < bytes.length) {
      var c = bytes[i];
      i += 1;
      if (c < 0x80) out += String.fromCharCode(c);
      else if (c < 0xe0) {
        var c2 = bytes[i];
        i += 1;
        out += String.fromCharCode(((c & 0x1f) << 6) | (c2 & 0x3f));
      } else if (c < 0xf0) {
        var c2b = bytes[i];
        var c3 = bytes[i + 1];
        i += 2;
        out += String.fromCharCode(((c & 0x0f) << 12) | ((c2b & 0x3f) << 6) | (c3 & 0x3f));
      } else {
        var c2c = bytes[i];
        var c3b = bytes[i + 1];
        var c4 = bytes[i + 2];
        i += 3;
        var cp = ((c & 7) << 18) | ((c2c & 0x3f) << 12) | ((c3b & 0x3f) << 6) | (c4 & 0x3f);
        cp -= 0x10000;
        out += String.fromCharCode(0xd800 + (cp >> 10), 0xdc00 + (cp & 0x3ff));
      }
    }
    return out;
  }

  function videasyKeystate(seed, mediaId) {
    var tNum = Number(mediaId) || 0;
    var S = Object.create(null);
    var fnv = 2166136261;
    var seedStr = String(seed || '');
    var i;
    for (i = 0; i < seedStr.length; i += 1) {
      fnv = videasyImul(fnv ^ seedStr.charCodeAt(i), 16777619);
    }
    var a = videasyMix(videasyMix(fnv) ^ videasyMix(videasyU32(tNum) ^ 2654435769));
    var e;
    for (e = 0; e < 8; e += 1) {
      var tSlot = a % 61;
      a = videasyRotl(videasyU32(a + 2654435769), 7 + (7 & e));
      S[tSlot] = videasyU32(a ^ videasyMix(a));
      a = videasyMix(videasyU32(a + tSlot));
    }
    return { S: S, acc: videasyMix(videasyU32(2779096485 ^ a)) };
  }

  function videasyNextWord(state, tCounter) {
    var r = state.S;
    var o = state.acc;
    var n = o % 61;
    var present = Object.prototype.hasOwnProperty.call(r, n);
    var iMask = present ? 0xffffffff : 0;
    var l = present ? videasyU32(r[n]) : 0;
    var aVal = videasyU32(l ^ videasyImul(2654435769, tCounter + 1));
    var s = o;
    var d = videasyU32(videasyU32(s ^ aVal) | videasyU32(s & aVal & iMask));
    d = videasyU32(videasyRotl(videasyU32(d + o), 31 & n) ^ videasyRotl(o, 31 & videasyImul(n, 7)));
    o = videasyMix(videasyU32(d + 2654435769));
    r[n] = o;
    state.acc = o;
    return o;
  }

  function videasyKeystream(seed, mediaId, length) {
    var state = videasyKeystate(seed, mediaId);
    var out = new Array(length);
    var o = 0;
    var e = 0;
    while (e < length) {
      var t = videasyNextWord(state, o);
      o += 1;
      out[e] = t & 255;
      e += 1;
      if (e < length) { out[e] = (t >>> 8) & 255; e += 1; }
      if (e < length) { out[e] = (t >>> 16) & 255; e += 1; }
      if (e < length) { out[e] = (t >>> 24) & 255; e += 1; }
    }
    return out;
  }

  function videasyDecrypt(payload, seed, mediaId) {
    var raw = videasyB64Decode(String(payload || '').trim().replace(/^"|"$/g, ''));
    if (!raw.length) throw new Error('videasy empty payload');
    var ks = videasyKeystream(seed, mediaId, raw.length);
    var plain = new Array(raw.length);
    var i;
    for (i = 0; i < raw.length; i += 1) plain[i] = raw[i] ^ ks[i];
    for (i = 0; i < VIDEASY_MAGIC.length; i += 1) {
      if (plain[i] !== VIDEASY_MAGIC[i]) throw new Error('videasy decrypt magic mismatch');
    }
    return videasyUtf8Decode(plain.slice(4));
  }

  function detectLanguage(blob) {
    var text = String(blob || '');
    var codes = { en: 'en', eng: 'en', es: 'es', spa: 'es', it: 'it', ita: 'it',
      fr: 'fr', fra: 'fr', fre: 'fr', ar: 'ar', ara: 'ar', de: 'de', deu: 'de',
      ger: 'de', ja: 'ja', jpn: 'ja', ko: 'ko', kor: 'ko', pt: 'pt', por: 'pt',
      zh: 'zh', zho: 'zh', chi: 'zh', ru: 'ru', rus: 'ru', hi: 'hi', hin: 'hi',
      tr: 'tr', tur: 'tr', nl: 'nl', nld: 'nl', pl: 'pl', pol: 'pl', sv: 'sv',
      swe: 'sv', el: 'el', ell: 'el', th: 'th', tha: 'th', vi: 'vi', vie: 'vi',
      id: 'id', ind: 'id', ro: 'ro', ron: 'ro', uk: 'uk', ukr: 'uk' };
    var code = text.trim().toLowerCase().split(/[-_]/)[0];
    if (codes[code]) return codes[code];
    var i;
    for (i = 0; i < LANGS.length; i += 1) {
      if (LANGS[i].re.test(text)) return LANGS[i].code;
    }
    return '';
  }

  function heightFromQuality(value) {
    var text = String(value || '');
    if (/4k|2160|uhd/i.test(text)) return 2160;
    if (/1080/i.test(text)) return 1080;
    if (/720/i.test(text)) return 720;
    if (/480/i.test(text)) return 480;
    return 0;
  }

  function joinUrl(base, rel) {
    rel = String(rel || '').trim();
    if (!rel || /[\s\\]/.test(rel)) return '';
    if (/^[a-z][a-z0-9+.-]*:/i.test(rel)) return safeUrl(rel) ? rel : '';
    var match = String(base).match(/^(https:\/\/[^/]+)(\/[^?#]*)?(?:\?[^#]*)?/i);
    if (!match) return '';
    if (rel.indexOf('//') === 0) return safeUrl('https:' + rel) ? 'https:' + rel : '';
    var path = match[2] || '/';
    if (rel.charAt(0) === '?') return match[1] + path + rel;
    if (rel.charAt(0) !== '/') rel = path.slice(0, path.lastIndexOf('/') + 1) + rel;
    var suffix = rel.match(/[?#].*$/);
    var parts = rel.replace(/[?#].*$/, '').split('/');
    var normalized = [];
    parts.forEach(function (part) {
      if (part === '..') normalized.pop();
      else if (part !== '.' && part !== '') normalized.push(part);
    });
    var result = match[1] + '/' + normalized.join('/') + (suffix ? suffix[0] : '');
    return safeUrl(result) ? result : '';
  }

  function safeUrl(value) {
    var match = String(value || '').match(/^https:\/\/([a-z0-9.-]+)(?::443)?(?:[/?#]|$)/i);
    if (!match || /[\s\\]/.test(value)) return false;
    var host = match[1].toLowerCase();
    return host.indexOf('.') > 0 && !/^[\d.]+$/.test(host) &&
      !/(?:^|\.)(?:localhost|local|internal|test|invalid)$/.test(host);
  }

  function attributes(line) {
    var out = {};
    var pattern = /([A-Z0-9-]+)=(?:"([^"]*)"|([^,]*))/g;
    var match;
    while ((match = pattern.exec(line))) out[match[1]] = match[2] == null ? match[3] : match[2];
    return out;
  }

  function hlsMetadata(text, base, hdrs) {
    var lines = String(text || '').split(/\r?\n/);
    var variants = [], tracks = [], audio = [];
    lines.forEach(function (line, i) {
      if (line.indexOf('#EXT-X-MEDIA:') === 0) {
        var attr = attributes(line);
        if (attr.TYPE === 'AUDIO') audio.push(attr);
        if (attr.TYPE === 'SUBTITLES') tracks.push({ url: joinUrl(base, attr.URI),
          lang: attr.LANGUAGE, label: attr.NAME, format: 'hls' });
      }
      if (line.indexOf('#EXT-X-STREAM-INF:') !== 0) return;
      var attr = attributes(line), next = i + 1;
      while (next < lines.length && (!lines[next].trim() || lines[next].charAt(0) === '#')) next += 1;
      var url = joinUrl(base, lines[next]);
      if (!url) return;
      var size = String(attr.RESOLUTION || '').split('x');
      variants.push({ url: url, height: Number(size[1]) || 0, audioGroup: attr.AUDIO,
        label: size[1] ? size[1] + 'p' : 'Auto', headers: hdrs });
    });
    return { variants: variants, subtitles: tracks, audio: audio };
  }

  function firstMedia(master, base) {
    var lines = String(master || '').split(/\r?\n/);
    var i;
    for (i = 0; i < lines.length; i += 1) {
      var line = lines[i].trim();
      if (line.indexOf('#EXT-X-STREAM-INF') === 0) {
        var j;
        for (j = i + 1; j < lines.length; j += 1) {
          var next = lines[j].trim();
          if (!next || next.charAt(0) === '#') continue;
          return joinUrl(base, next);
        }
      }
    }
    for (i = 0; i < lines.length; i += 1) {
      var media = lines[i].trim();
      if (!media || media.charAt(0) === '#') continue;
      return joinUrl(base, media);
    }
    return '';
  }

  function parseAudioLang(master) {
    var found = [];
    String(master || '').split(/\r?\n/).forEach(function (line) {
      if (line.indexOf('#EXT-X-MEDIA:') !== 0 || !/TYPE=AUDIO/i.test(line)) return;
      var m = line.match(/LANGUAGE="([^"]+)"/i);
      if (m) found.push(m[1].toLowerCase());
    });
    return found;
  }

  function mapCaptions(rawList) {
    var out = [];
    var seen = {};
    (Array.isArray(rawList) ? rawList : []).forEach(function (row) {
      if (!row || typeof row !== 'object') return;
      var file = String(row.url || row.file || row.src || '').trim();
      if (!safeUrl(file) || seen[file]) return;
      if (/thumb|sprite/i.test(file)) return;
      // Player expects standalone VTT/SRT, not segmented subtitle playlists.
      if (row.format === 'hls' || /\.m3u8(?:[?#]|$)/i.test(file)) return;
      seen[file] = true;
      var rawLang = clean(row.lang || row.language || row.label || '').toLowerCase();
      var lang = detectLanguage(rawLang) || detectLanguage(row.label) || 'und';
      out.push({
        id: file,
        url: file,
        file: file,
        label: clean(row.label || row.language || row.lang || 'Subtitle'),
        language: lang,
        lang: lang,
        kind: 'subtitles',
        headers: videasyStreamHeaders(),
      });
    });
    return out;
  }

  async function probeHls(url, hdrs, ctx) {
    if (!url || FAKE.test(url)) return { ok: false, reason: 'fake_url' };
    var playlist = await request(url, hdrs, 'GET', null, ctx, 'playlist');
    if (!playlist.ok || playlist.text.indexOf('#EXTM3U') < 0) {
      return { ok: false, reason: 'not_hls', status: playlist.status };
    }
    var info = hlsMetadata(playlist.text, url, hdrs);
    var child = firstMedia(playlist.text, url);
    if (!child || FAKE.test(child)) return { ok: false, reason: 'no_media' };
    var body = playlist.text;
    var mediaUrl = url;
    if (info.variants.length && child !== url) {
      var variant = await request(child, hdrs, 'GET', null, ctx, 'variant');
      if (!variant.ok || variant.text.indexOf('#EXTM3U') < 0) return { ok: false, reason: 'variant_fail' };
      body = variant.text;
      mediaUrl = child;
    }
    var seg = firstMedia(body, mediaUrl);
    if (!seg || FAKE.test(seg)) return { ok: false, reason: 'fake_seg' };
    // Text-only bridge can reject obvious placeholders, not certify binary decode.
    // QA separately verifies real bytes and decoding in FFmpeg and Player.
    var segment = await request(seg, Object.assign({}, hdrs, { Range: 'bytes=0-4095' }), 'GET', null, ctx, 'segment');
    if (!segment.ok) return { ok: false, reason: 'seg_' + segment.status };
    var sample = segment.text || '';
    if (!sample || sample.length < 16) return { ok: false, reason: 'seg_empty' };
    if (/^\s*(?:#EXTM3U|\{|\[)/.test(sample)) return { ok: false, reason: 'seg_not_media' };
    if (/^\s*<(?:!doctype|html)/i.test(sample)) return { ok: false, reason: 'seg_html' };
    // Some CDNs mislabel transport bytes image/jpeg. A real MPEG-TS header or
    // fMP4 box can override MIME; an image signature never can.
    var tsHeader = sample.charCodeAt(0) === 0x47 && (sample.charCodeAt(3) & 0x30) !== 0 &&
      sample.slice(1, 8).indexOf('\u0000') >= 0;
    var mp4Header = /^(?:ftyp|styp|moof)$/.test(sample.slice(4, 8));
    if (/^(?:text\/|image\/|application\/(?:json|vnd.apple.mpegurl|x-mpegurl))/i.test(segment.contentType) &&
        !tsHeader && !mp4Header) return { ok: false, reason: 'seg_wrong_type' };
    if (/PNG|JFIF|GIF8|WEBP/i.test(sample.slice(0, 64))) return { ok: false, reason: 'seg_image' };
    var langs = parseAudioLang(playlist.text);
    return { ok: true, master: playlist.text, audioLangs: langs, metadata: info };
  }

  async function resolveVideasy(ref, ctx) {
    var path = '/' + ref.type + '/' + ref.id + '?append_to_response=external_ids';
    var meta = await tmdb(path, ctx);
    if (!meta) return [];
    if (String(meta.id) !== ref.id) throw new Error('metadata_identity_mismatch');
    var title = clean(meta.title || meta.name || ref.id);
    var year = String(meta.release_date || meta.first_air_date || '').slice(0, 4);
    var imdbId = clean((meta.external_ids && meta.external_ids.imdb_id) || meta.imdb_id);
    var seed = '';
    var seedAttempt;
    for (seedAttempt = 0; seedAttempt < 2 && !seed && active(ctx); seedAttempt += 1) {
      var seedRes = await request(VIDEASY_API + '/seed?mediaId=' + encodeURIComponent(ref.id),
        videasyHeaders(), 'GET', null, ctx, 'seed');
      seed = seedRes.ok && seedRes.json && seedRes.json.seed ? String(seedRes.json.seed) : '';
      if (!seed) {
        ctx.failure = seedRes.ok ? failure('empty_seed', 'seed', seedRes.status) : seedRes;
        if (seedRes.status === 429 || seedRes.status === 403 || seedRes.status === 401) break;
        if (seedAttempt === 0 && active(ctx)) await new Promise(function (resolve) { setTimeout(resolve, 600); });
      }
    }
    if (!seed) return [];
    var params = {
      title: title,
      mediaType: ref.type,
      year: year,
      tmdbId: ref.id,
      imdbId: imdbId,
      enc: '2',
      seed: seed,
    };
    if (ref.type === 'tv') {
      params.seasonId = Number(ref.season || 1);
      params.episodeId = Number(ref.episode || 1);
    }
    var hdrs = videasyStreamHeaders();
    var q = Object.keys(params).filter(function (k) {
      return params[k] != null && params[k] !== '';
    }).map(function (k) {
      return encodeURIComponent(k) + '=' + encodeURIComponent(String(params[k]));
    }).join('&');
    // Two real API routes, sharing one rate-limit domain. This is not two
    // independent companies. Results are awaited; no background module work.
    var results = await Promise.all(ENGLISH_ENDPOINTS.map(async function (endpoint) {
      var res = await request(VIDEASY_API + endpoint.path + '?' + q, videasyHeaders(),
        'GET', null, ctx, 'sources:' + endpoint.name);
      if (!res.ok || !res.text || !active(ctx)) return [];
      var data = null;
      try { data = res.json && Array.isArray(res.json.sources) ? res.json :
        JSON.parse(videasyDecrypt(res.text, seed, ref.id)); } catch (_) {
        ctx.diagnostics.push({ stage: 'sources:' + endpoint.name, code: 'invalid_source_payload', status: res.status });
        return [];
      }
      if (!data || !Array.isArray(data.sources)) return [];
      if (data.tmdbId != null && String(data.tmdbId) !== ref.id) return [];
      if (ref.type === 'tv' && ((data.seasonId != null && Number(data.seasonId) !== ref.season) ||
          (data.episodeId != null && Number(data.episodeId) !== ref.episode))) return [];
      var sources = data.sources.slice(0, 8);
      var captions = mapCaptions(data.subtitles || data.subs || data.tracks);
      var servers = [], seen = {};
      for (var s = 0; s < sources.length && active(ctx); s += 1) {
        var src = sources[s];
        var url = String(src && src.url || '');
        if (!safeUrl(url) || seen[url] || /\.mpd(\?|$)/i.test(url)) continue;
        var labeled = detectLanguage(src.lang || src.audio || src.language);
        var audioLanguage = labeled || 'und';
        var probe = await probeHls(url, hdrs, ctx);
        if (!probe || !probe.ok || !active(ctx)) {
          ctx.diagnostics.push({ stage: 'media:' + endpoint.name, code: probe.reason || 'budget_exhausted' });
          continue;
        }
        var masterLangs = (probe.audioLangs || []).map(detectLanguage).filter(Boolean);
        if (masterLangs.length === 1) audioLanguage = masterLangs[0];
        // Multiple audio tracks are not proof the currently selected one is English.
        seen[url] = true;
        var height = heightFromQuality(src.quality || src.label);
        var localCaptions = mapCaptions(src.subtitles || src.tracks || []);
        var combinedCaptions = mapCaptions(localCaptions.concat(captions));
        var existing = servers.filter(function (row) {
          return row.audioLanguage === audioLanguage && JSON.stringify(row.subtitles) === JSON.stringify(combinedCaptions);
        })[0];
        var quality = height ? { label: height + 'p', height: height, url: url, headers: hdrs, streamType: 'hls' } : null;
        var qualities = quality ? [quality] : [];
        // Keep an external-audio master intact: a bare video rendition can lose sound.
        var audio = probe.metadata.audio;
        for (var v = 0; v < probe.metadata.variants.length && active(ctx); v += 1) {
          var variant = probe.metadata.variants[v];
          if (!variant.height || audio.some(function (a) { return a['GROUP-ID'] === variant.audioGroup && a.URI; })) continue;
          var variantProbe = await probeHls(variant.url, hdrs, ctx);
          if (variantProbe.ok) qualities.push({ label: variant.label, height: variant.height,
            url: variant.url, headers: hdrs, streamType: 'hls' });
        }
        if (existing) {
          existing.qualities = existing.qualities.concat(qualities);
          if (height > (existing.height || 0) && height <= 1080) {
            existing.url = url;
            existing.height = height;
          }
          continue;
        }
        servers.push({
          name: endpoint.name + (audioLanguage === 'und' ? ' (audio unspecified)' : ' (' + audioLanguage + ')'),
          url: url,
          height: height,
          headers: hdrs,
          streamType: 'hls',
          lang: 'sub',
          audioLanguage: audioLanguage,
          subtitles: combinedCaptions,
          qualities: qualities,
        });
      }
      return servers;
    }));
    var all = [], seen = {};
    results.forEach(function (rows) { rows.forEach(function (row) {
      var key = row.url + JSON.stringify(row.headers) + JSON.stringify(row.subtitles);
      if (!seen[key]) { all.push(row); seen[key] = true; }
    }); });
    all.sort(function (a, b) {
      function rank(row) { return row.audioLanguage === 'en' ? 0 : row.audioLanguage === 'und' ? 1 : 2; }
      return rank(a) - rank(b);
    });
    return all;
  }

  function pack(servers, lang, ctx) {
    var primary = servers && servers[0];
    if (!primary || !primary.url) {
      return {
        streams: [],
        subtitles: [],
        lang: lang,
        error: { code: ctx && ctx.failure ? ctx.failure.code : 'no_verified_stream',
          stage: ctx && ctx.failure ? ctx.failure.stage : 'resolution',
          message: Date.now() < providerRetryAt ? 'The provider is limiting requests. Please wait before trying again.' :
            'Movie Direct could not verify a stream. Try again later or choose another source.' },
        diagnostics: ctx ? ctx.diagnostics : [],
      };
    }
    return {
      url: primary.url,
      streams: [{ url: primary.url, label: 'Auto', headers: primary.headers, streamType: 'hls' }].concat(primary.qualities || []),
      headers: primary.headers,
      streamType: primary.streamType || 'hls',
      lang: lang,
      audioLanguage: primary.audioLanguage || 'und',
      quality: 'Auto',
      defaultQuality: 'Auto',
      qualities: [{ label: 'Auto', url: primary.url, headers: primary.headers }].concat(primary.qualities || []),
      subtitles: primary.subtitles || [],
      servers: servers.map(function (row) {
        return {
          name: row.name,
          label: row.name,
          url: row.url,
          headers: row.headers,
          streamType: row.streamType || 'hls',
          lang: lang,
          audioLanguage: row.audioLanguage,
          subtitles: row.subtitles || [],
          qualities: row.qualities || [],
        };
      }),
      provider: 'videasy',
      diagnostics: ctx ? ctx.diagnostics : [],
    };
  }

  async function searchResults(query, page) {
    var q = clean(query);
    try {
      var path = q
        ? '/search/multi?query=' + encodeURIComponent(q) + '&include_adult=false&page=' + Math.max(1, Number(page) || 1)
        : '/trending/all/week?page=' + Math.max(1, Number(page) || 1);
      var data = await withTimeout(tmdb(path), 8000, null);
      return ((data && data.results) || []).map(function (row) { return mapItem(row); }).filter(Boolean).slice(0, 40);
    } catch (error) {
      log('search failed');
      return [];
    }
  }

  async function extractDetails(urlOrId) {
    var ref = parseHref(urlOrId);
    if (!ref) {
      return { title: 'Unavailable', description: 'Select an exact catalogue entry.' };
    }
    try {
      var meta = await tmdb('/' + ref.type + '/' + ref.id);
      var item = mapItem(meta, ref.type);
      if (!item) return { title: 'Unavailable', description: '', href: urlOrId };
      item.description = clean(meta.overview);
      item.synopsis = item.description;
      item.genres = (meta.genres || []).map(function (g) { return g && g.name; }).filter(Boolean);
      item.tmdbId = Number(ref.id);
      return item;
    } catch (_) {
      return { title: 'Unavailable', description: '', href: urlOrId };
    }
  }

  async function extractEpisodes(seriesId) {
    var ref = parseHref(seriesId);
    if (!ref) return [];
    if (ref.type === 'movie') {
      return [{
        id: href('movie', ref.id),
        href: href('movie', ref.id),
        number: 1,
        episodeNumber: 1,
        title: 'Movie',
        subAvailable: true,
        dubAvailable: false,
      }];
    }
    try {
      var meta = await tmdb('/tv/' + ref.id);
      var seasons = Array.isArray(meta.seasons) ? meta.seasons : [];
      var out = [];
      var s;
      for (s = 0; s < seasons.length && out.length < 400; s += 1) {
        var season = seasons[s];
        var num = Number(season && season.season_number);
        if (!isFinite(num) || num < 1) continue;
        var packSeason = await withTimeout(tmdb('/tv/' + ref.id + '/season/' + num), 8000, null);
        var episodes = (packSeason && Array.isArray(packSeason.episodes)) ? packSeason.episodes : [];
        episodes.forEach(function (ep) {
          var n = Number(ep && ep.episode_number);
          if (!n) return;
          out.push({
            id: href('tv', ref.id, num, n),
            href: href('tv', ref.id, num, n),
            season: num,
            number: n,
            episodeNumber: n,
            title: clean(ep.name) || ('S' + num + 'E' + n),
            subAvailable: true,
            dubAvailable: false,
          });
        });
      }
      return out;
    } catch (_) {
      return [];
    }
  }

  async function extractStreamUrl(episodeHref, lang) {
    var want = String(lang || 'sub').toLowerCase();
    if (want === 'dub' || want === 'vf') {
      return {
        streams: [],
        subtitles: [],
        lang: want,
        error: { message: 'Movie Direct does not advertise English Dub. Non-English audio is not Dub.' },
      };
    }
    var ref = parseHref(episodeHref);
    if (!ref) {
      return { streams: [], subtitles: [], error: { message: 'Invalid Movie Direct identity.' } };
    }
    if (ref.type === 'tv' && (!ref.season || !ref.episode)) {
      return { streams: [], subtitles: [], error: { message: 'TV identity is missing season/episode.' } };
    }
    var key = ref.type + ':' + ref.id + ':' + ref.season + ':' + ref.episode;
    if (inflight[key]) return JSON.parse(JSON.stringify(await inflight[key]));
    if (Object.keys(inflight).length >= 2) return {
      streams: [], subtitles: [], error: { code: 'busy', message: 'A resolution is already in progress. Try again shortly.' } };
    var ctx = { deadline: Date.now() + RESOLVE_MS, closed: false, requests: 0, diagnostics: [] };
    var pending = (async function () {
      try {
        var servers = await withTimeout(resolveVideasy(ref, ctx), RESOLVE_MS, null);
        if (!servers) ctx.failure = failure('timeout', 'resolution');
        return pack(servers, 'sub', ctx);
      } catch (error) {
        ctx.failure = error.result || failure('resolution_error', 'resolution');
        return pack(null, 'sub', ctx);
      } finally { ctx.closed = true; }
    })();
    inflight[key] = pending;
    try { return JSON.parse(JSON.stringify(await pending)); }
    finally { delete inflight[key]; }
  }

  async function discoveryHome() {
    try {
      var trending = await tmdb('/trending/all/week?page=1');
      var movies = await tmdb('/movie/popular?page=1');
      var tv = await tmdb('/tv/popular?page=1');
      return {
        sections: [
          { id: 'md-trending', title: 'Trending', style: 'hero', items: (trending.results || []).map(function (r) { return mapItem(r); }).filter(Boolean).slice(0, 8) },
          { id: 'md-movies', title: 'Popular movies', style: 'poster', items: (movies.results || []).map(function (r) { return mapItem(r, 'movie'); }).filter(Boolean) },
          { id: 'md-tv', title: 'Popular TV', style: 'poster', items: (tv.results || []).map(function (r) { return mapItem(r, 'tv'); }).filter(Boolean) },
        ],
      };
    } catch (_) {
      return { sections: [] };
    }
  }

  async function discoveryFeed(feedId, page) {
    var pageNumber = Math.max(1, Number(page) || 1);
    var path = '/trending/all/week?page=' + pageNumber;
    if (String(feedId || '').indexOf('movie') >= 0) path = '/movie/popular?page=' + pageNumber;
    if (String(feedId || '').indexOf('tv') >= 0) path = '/tv/popular?page=' + pageNumber;
    try {
      var data = await tmdb(path);
      var type = path.indexOf('/tv/') === 0 ? 'tv' : (path.indexOf('/movie/') === 0 ? 'movie' : '');
      var items = (data.results || []).map(function (row) { return mapItem(row, type || undefined); }).filter(Boolean);
      return { feedId: feedId || 'trending', page: pageNumber, items: items, hasMore: items.length >= 20 };
    } catch (_) {
      return { feedId: feedId || 'trending', page: pageNumber, items: [], hasMore: false };
    }
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
