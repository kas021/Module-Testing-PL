/* Goyabu (goyabu.io) — Portuguese (Brazil) anime catalogue for Synthetiq Player.
 *
 * Chain proven live 2026-09-16:
 *   search  : /?s=<query>                      -> <article class="boxAN"> cards
 *   details : /anime/<slug>/                    -> h1, og:*, .sinopse, #year, .status
 *   episodes: /anime/<slug>/                    -> const allEpisodes = [ {id, episodio, link, audio, ...} ]
 *   stream  : /<episode-id>                     -> var playersData = [ {select:"blogger", url:"https://www.blogger.com/video.g?token=..."} ]
 *             blogger token -> batchexecute WcwnYd -> googlevideo.com MP4 (itag 22/18)
 *
 * Returns direct googlevideo MP4 URLs (verified with a 2-byte range probe before returning).
 */
(function () {
  'use strict';

  const SITE = 'https://goyabu.io';
  const BLOGGER_PLAYER = 'https://www.blogger.com/video.g?token=';
  const BATCHEXECUTE = 'https://www.blogger.com/_/BloggerVideoPlayerUi/data/batchexecute';
  const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
  const HTML_HEADERS = {
    'User-Agent': UA,
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.6',
  };
  const ITAG_PRIORITY = { 22: 720, 18: 360, 59: 480, 78: 480 };

  const episodesCache = {};

  const now = () => Date.now();
  const remaining = (deadline, cap) => Math.max(800, Math.min(deadline - now(), cap));

  function cleanText(value) {
    return String(value == null ? '' : value)
      .replace(/<[^>]*>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&')
      .replace(/&quot;/gi, '"')
      .replace(/&#0?39;|&apos;/gi, "'")
      .replace(/&aacute;/gi, 'á').replace(/&eacute;/gi, 'é').replace(/&iacute;/gi, 'í')
      .replace(/&oacute;/gi, 'ó').replace(/&uacute;/gi, 'ú').replace(/&atilde;/gi, 'ã')
      .replace(/&otilde;/gi, 'õ').replace(/&ccedil;/gi, 'ç').replace(/&ecirc;/gi, 'ê')
      .replace(/&ocirc;/gi, 'ô').replace(/&acirc;/gi, 'â')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function absolute(href, base) {
    const value = String(href == null ? '' : href).trim();
    if (!value) return '';
    if (/^https?:\/\//i.test(value)) return value;
    if (/^\/\//.test(value)) return 'https:' + value;
    if (/^\//.test(value)) return SITE + value;
    return (base || SITE) + '/' + value.replace(/^\.?\//, '');
  }

  async function requestText(url, headers, timeoutMs, method, body) {
    const opts = timeoutMs ? { timeoutMs } : undefined;
    let res;
    if (typeof fetchv2 === 'function') {
      res = await fetchv2(url, Object.assign({}, headers), method || 'GET', body || null, opts);
    } else if (typeof fetch === 'function') {
      res = await fetch(url, { method: method || 'GET', headers: headers || {}, body: body || undefined });
    } else {
      throw new Error('No HTTP transport available');
    }
    const status = Number(res && (res.status || res.statusCode)) || 0;
    let text = '';
    if (res && typeof res.text === 'function') {
      text = await res.text();
    } else if (res && typeof res.body === 'string') {
      text = res.body;
    } else if (res && res.body != null) {
      text = String(res.body);
    }
    if (!text && res && typeof res.json === 'function') {
      try {
        const parsed = await res.json();
        if (parsed != null) text = JSON.stringify(parsed);
      } catch (_) { /* keep empty */ }
    }
    return { status, text, headers: (res && res.headers) || {} };
  }

  /* ───────────── HTML parsing helpers ───────────── */

  function parseCards(html) {
    const cards = [];
    const re = /<article class="boxAN">([\s\S]*?)<\/article>/gi;
    let m;
    while ((m = re.exec(html))) {
      const block = m[1];
      const href = (block.match(/href="([^"]+)"/) || [])[1] || '';
      if (!href || href.indexOf('/anime/') < 0) continue;
      const title = cleanText((block.match(/title="([^"]+)"/) || [])[1] || (block.match(/class="title[^"]*"[^>]*>([^<]+)</) || [])[1] || '');
      const image = absolute((block.match(/<img[^>]+src="([^"]+)"/) || [])[1] || '');
      const audio = cleanText((block.match(/class="audio-box[^"]*"[^>]*>([^<]+)</) || [])[1] || '');
      if (!title) continue;
      cards.push({ href: absolute(href), title, image, audio });
    }
    return cards;
  }

  function parseEpisodeArray(html) {
    const i = html.indexOf('allEpisodes');
    if (i < 0) return [];
    const j = html.indexOf('[', i);
    if (j < 0) return [];
    let depth = 0;
    for (let k = j; k < html.length; k += 1) {
      const ch = html.charAt(k);
      if (ch === '[') depth += 1;
      else if (ch === ']') {
        depth -= 1;
        if (depth === 0) {
          try {
            const arr = JSON.parse(html.slice(j, k + 1));
            return Array.isArray(arr) ? arr : [];
          } catch (_) {
            return [];
          }
        }
      }
    }
    return [];
  }

  function parsePlayers(html) {
    const i = html.indexOf('playersData');
    if (i < 0) return [];
    const j = html.indexOf('[', i);
    if (j < 0) return [];
    let depth = 0;
    for (let k = j; k < html.length; k += 1) {
      const ch = html.charAt(k);
      if (ch === '[') depth += 1;
      else if (ch === ']') {
        depth -= 1;
        if (depth === 0) {
          try {
            const arr = JSON.parse(html.slice(j, k + 1));
            return Array.isArray(arr) ? arr : [];
          } catch (_) {
            return [];
          }
        }
      }
    }
    return [];
  }

  /* ───────────── Blogger (googlevideo) resolver ───────────── */

  function itagFromUrl(url) {
    const m = String(url || '').match(/[?&]itag=(\d+)/);
    return m ? Number(m[1]) : 0;
  }

  async function resolveBloggerStreams(token, deadline) {
    const referer = BLOGGER_PLAYER + token;
    const page = await requestText(referer, { 'User-Agent': UA, 'Accept-Language': 'pt-BR,pt;q=0.9' }, remaining(deadline, 8000));
    if (page.status !== 200) throw new Error('blogger page HTTP ' + page.status);
    const fsid = (page.text.match(/"FdrFJe"\s*:\s*"(-?\d+)"/) || [])[1];
    const bl = (page.text.match(/"cfb2h"\s*:\s*"([^"]+)"/) || [])[1];
    if (!fsid || !bl) throw new Error('blogger session params missing');

    const fReq = JSON.stringify([[['WcwnYd', JSON.stringify([token, null, 0]), null, 'generic']]]);
    const query = 'rpcids=WcwnYd&source-path=%2Fvideo.g&f.sid=' + fsid + '&bl=' + encodeURIComponent(bl) + '&hl=pt-BR&_reqid=1&rt=c';
    const res = await requestText(
      BATCHEXECUTE + '?' + query,
      {
        'User-Agent': UA,
        'Accept-Language': 'pt-BR,pt;q=0.9',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'X-Same-Domain': '1',
        Referer: referer,
      },
      remaining(deadline, 8000),
      'POST',
      'f.req=' + encodeURIComponent(fReq)
    );
    if (res.status !== 200) throw new Error('batchexecute HTTP ' + res.status);

    let jsonLine = null;
    const lines = String(res.text || '').split('\n');
    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i].trim();
      if (line.indexOf('[[') === 0) { jsonLine = line; break; }
    }
    if (!jsonLine) throw new Error('batchexecute payload missing');
    const outer = JSON.parse(jsonLine);
    if (!outer || !outer[0] || typeof outer[0][2] !== 'string') throw new Error('batchexecute outer shape unexpected');
    const inner = JSON.parse(outer[0][2]);
    const streams = (inner && inner[2]) || [];
    const ranked = [];
    for (let i = 0; i < streams.length; i += 1) {
      const entry = streams[i];
      if (!entry || typeof entry[0] !== 'string') continue;
      if (entry[0].indexOf('googlevideo.com') < 0) continue;
      const itag = (entry[1] && entry[1][0]) || itagFromUrl(entry[0]);
      ranked.push({ url: entry[0], score: ITAG_PRIORITY[itag] || itag || 0 });
    }
    ranked.sort((a, b) => b.score - a.score);
    const seen = {};
    const urls = [];
    for (let i = 0; i < ranked.length; i += 1) {
      if (seen[ranked[i].url]) continue;
      seen[ranked[i].url] = true;
      urls.push(ranked[i].url);
    }
    if (!urls.length) throw new Error('no googlevideo URLs');
    return urls;
  }

  /* ───────────── Home / search ───────────── */

  async function searchResults(query) {
    const deadline = now() + 15000;
    const term = String(query == null ? '' : query).trim();
    const res = await requestText(
      SITE + '/?s=' + encodeURIComponent(term),
      Object.assign({}, HTML_HEADERS, { Referer: SITE + '/' }),
      remaining(deadline, 12000)
    );
    if (res.status !== 200) throw new Error('Goyabu search HTTP ' + res.status);
    return parseCards(res.text).map((c) => ({
      id: c.href,
      href: c.href,
      title: c.title,
      image: c.image,
      poster: c.image,
      type: 'video',
      ...(c.audio ? { description: c.audio } : {}),
    }));
  }

  /* ───────────── Details ───────────── */

  async function extractDetails(urlOrId) {
    const deadline = now() + 15000;
    const url = absolute(urlOrId);
    if (url.indexOf('/anime/') < 0) throw new Error('Goyabu details: not an anime URL');
    const res = await requestText(url, Object.assign({}, HTML_HEADERS, { Referer: SITE + '/' }), remaining(deadline, 12000));
    if (res.status !== 200) throw new Error('Goyabu details HTTP ' + res.status);
    const html = res.text;

    const title = cleanText((html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i) || [])[1] || '');
    let description = cleanText((html.match(/class="sinopse-short"[^>]*>([\s\S]*?)<\/span>/i) || [])[1] || '');
    if (!description) description = cleanText((html.match(/property="og:description" content="([^"]+)"/i) || [])[1] || '');
    const image = absolute((html.match(/property="og:image" content="([^"]+)"/i) || [])[1] || '');
    const year = cleanText((html.match(/id="year"[^>]*>([\s\S]*?)<\/li>/i) || [])[1] || '');
    const status = cleanText((html.match(/class="status[^"]*"[^>]*>([\s\S]*?)<\/li>/i) || [])[1] || '');
    const genres = [];
    const genreRe = /href="https:\/\/goyabu\.io\/genero\/([^/"]+)\/?"/gi;
    let gm;
    while ((gm = genreRe.exec(html))) {
      const label = cleanText(decodeURIComponent(gm[1]).replace(/-/g, ' '));
      if (label && genres.indexOf(label) < 0) genres.push(label);
    }

    return {
      id: url,
      href: url,
      url,
      title,
      description,
      image,
      poster: image,
      author: '',
      status,
      genres,
      ...(year ? { year } : {}),
      type: 'video',
    };
  }

  /* ───────────── Episodes ───────────── */

  async function extractEpisodes(seriesId) {
    const deadline = now() + 15000;
    const url = absolute(seriesId);
    if (url.indexOf('/anime/') < 0) return [];
    if (episodesCache[url] && now() - episodesCache[url].at < 180000) return episodesCache[url].items;
    const res = await requestText(url, Object.assign({}, HTML_HEADERS, { Referer: SITE + '/' }), remaining(deadline, 12000));
    if (res.status !== 200) throw new Error('Goyabu episodes HTTP ' + res.status);
    const raw = parseEpisodeArray(res.text);
    const items = [];
    for (let i = 0; i < raw.length; i += 1) {
      const ep = raw[i] || {};
      const link = absolute(ep.link);
      if (!link) continue;
      const num = Number(ep.episodio);
      const audio = String(ep.audio || '').toLowerCase();
      const isDub = /ptbr|pt-br|dublado|dub/.test(audio);
      items.push({
        number: Number.isFinite(num) && num > 0 ? num : i + 1,
        href: link,
        title: cleanText(ep.episode_name) || ('Episódio ' + (Number.isFinite(num) && num > 0 ? num : i + 1)),
        season: null,
        subAvailable: !isDub,
        dubAvailable: isDub,
      });
    }
    items.sort((a, b) => a.number - b.number);
    if (items.length) episodesCache[url] = { at: now(), items };
    return items;
  }

  /* ───────────── Stream ───────────── */

  async function probeMedia(url, deadline) {
    try {
      const res = await requestText(url, { 'User-Agent': UA, Range: 'bytes=0-1' }, remaining(deadline, 6000));
      const status = res.status;
      const type = String((res.headers && (res.headers['content-type'] || res.headers['Content-Type'])) || '');
      if ((status === 200 || status === 206) && (/video\/|application\/octet-stream|audio\/mp4/i.test(type) || !type)) return true;
      return false;
    } catch (_) {
      return false;
    }
  }

  async function extractStreamUrl(episodeHref, lang) {
    const deadline = now() + 16000;   // stay under the 20s tester cap and the app's 30s budget
    const url = absolute(episodeHref);
    if (!url) return { streams: [] };
    const res = await requestText(url, Object.assign({}, HTML_HEADERS, { Referer: SITE + '/' }), remaining(deadline, 12000));
    if (res.status !== 200) throw new Error('Goyabu episode HTTP ' + res.status);

    const players = parsePlayers(res.text);
    const bloggerPlayers = [];
    for (let i = 0; i < players.length; i += 1) {
      const p = players[i] || {};
      const purl = String(p.url || '');
      if (purl.indexOf('blogger.com/video.g?token=') >= 0) bloggerPlayers.push(purl);
    }
    // fall back to any token-bearing player URL
    if (!bloggerPlayers.length) {
      for (let i = 0; i < players.length; i += 1) {
        const purl = String((players[i] || {}).url || '');
        if (purl.indexOf('token=') >= 0) bloggerPlayers.push(purl);
      }
    }

    for (let i = 0; i < bloggerPlayers.length; i += 1) {
      if (now() >= deadline) break;
      const token = (bloggerPlayers[i].match(/[?&]token=([^&]+)/) || [])[1];
      if (!token) continue;
      try {
        const urls = await resolveBloggerStreams(token, deadline);
        for (let j = 0; j < urls.length; j += 1) {
          if (now() >= deadline) break;
          if (await probeMedia(urls[j], deadline)) {
            return { url: urls[j], headers: { 'User-Agent': UA }, streamType: 'mp4' };
          }
        }
      } catch (_) { /* try next player */ }
    }
    return { streams: [] };
  }

  /* ───────────── Discovery ───────────── */

  async function rankingBuckets(deadline) {
    const res = await requestText(
      SITE + '/wp-json/cronos/v1/views/ranking-all?limit=10&type=anime',
      Object.assign({}, HTML_HEADERS, { Accept: 'application/json, text/plain, */*', Referer: SITE + '/' }),
      remaining(deadline, 12000)
    );
    if (res.status !== 200) throw new Error('Goyabu ranking HTTP ' + res.status);
    const data = JSON.parse(res.text);
    const rankings = (data && data.rankings) || {};
    const map = (list) => (Array.isArray(list) ? list : [])
      .map((it) => ({
        id: it.permalink || '', href: it.permalink || '', title: cleanText(it.title),
        image: absolute(it.poster || ''), poster: absolute(it.poster || ''), type: 'video',
        ...(it.rating ? { description: '★ ' + it.rating + (it.views_formatted ? ' · ' + it.views_formatted + ' views' : '') } : {}),
      }))
      .filter((it) => it.href);
    return { week: map(rankings.week), day: map(rankings.day), month: map(rankings.month) };
  }

  async function discoveryHome() {
    const deadline = now() + 18000;
    const sections = [];
    let buckets = { week: [], day: [], month: [] };
    try { buckets = await rankingBuckets(deadline); } catch (_) { /* catalogue-only fallback */ }
    if (buckets.week.length) sections.push({ id: 'semana', title: 'Populares da Semana', style: 'hero', items: buckets.week.slice(0, 8) });
    if (buckets.day.length) sections.push({ id: 'hoje', title: 'Mais Assistidos Hoje', style: 'poster', items: buckets.day });
    try {
      const browse = await requestText(SITE + '/?s=', Object.assign({}, HTML_HEADERS, { Referer: SITE + '/' }), remaining(deadline, 12000));
      if (browse.status === 200) {
        const catalogue = parseCards(browse.text).slice(0, 30).map((c) => ({
          id: c.href, href: c.href, title: c.title, image: c.image, poster: c.image, type: 'video',
          ...(c.audio ? { description: c.audio } : {}),
        }));
        if (catalogue.length) sections.push({ id: 'catalogo', title: 'Catálogo (Dublado & Legendado)', style: 'poster', items: catalogue, viewAll: { mode: 'feed', feedId: 'catalogo' } });
      }
    } catch (_) { /* ranking-only fallback */ }
    return { sections };
  }

  async function discoveryFeed(feedId, page) {
    const deadline = now() + 15000;
    const pageNum = Math.max(1, Number(page) || 1);
    const feed = String(feedId || '');
    if (feed === 'populares') {
      if (pageNum > 1) return { items: [], page: pageNum, hasMore: false };
      const buckets = await rankingBuckets(deadline);
      return { items: buckets.month.length ? buckets.month : buckets.week, page: 1, hasMore: false };
    }
    if (feed === 'catalogo' && pageNum <= 1) {
      const res = await requestText(SITE + '/?s=', Object.assign({}, HTML_HEADERS, { Referer: SITE + '/' }), remaining(deadline, 12000));
      if (res.status !== 200) throw new Error('Goyabu feed HTTP ' + res.status);
      const items = parseCards(res.text).slice(0, 50).map((c) => ({
        id: c.href, href: c.href, title: c.title, image: c.image, poster: c.image, type: 'video',
        ...(c.audio ? { description: c.audio } : {}),
      }));
      return { items, page: 1, hasMore: false };
    }
    if (feed.indexOf('genero:') === 0 && pageNum <= 1) {
      const slug = feed.slice('genero:'.length).replace(/[^a-z0-9-]/gi, '');
      const res = await requestText(SITE + '/generos/' + slug, Object.assign({}, HTML_HEADERS, { Referer: SITE + '/' }), remaining(deadline, 12000));
      if (res.status !== 200) return { items: [], page: 1, hasMore: false };
      const items = parseCards(res.text).slice(0, 50).map((c) => ({
        id: c.href, href: c.href, title: c.title, image: c.image, poster: c.image, type: 'video',
        ...(c.audio ? { description: c.audio } : {}),
      }));
      return { items, page: 1, hasMore: false };
    }
    return { items: [], page: pageNum, hasMore: false };
  }

  /* ───────────── Exports ───────────── */

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
