// SoloLatino (sololatino.net) — Synthetiq module v1
// Spanish-Latino movies, series and anime.
//
// Chain: site search API -> detail/episode pages -> [fast path] IMDb-derived player URL
//        (embed69.org/f/<imdb>[-SxE]) -> client-side PoW -> AES-CBC-decrypted hoster links
//        -> Vidhide resolver -> real HLS. The site's token API (/api/player-url) is kept as
//        a graceful fallback only: it needs a Laravel session cookie pair that some fetch
//        bridges do not retain, while the IMDb-derived route is cookie-free and faster.
//
// Engineering notes:
//  - The app JS sandbox has no atob/btoa, TextEncoder/TextDecoder, URL or crypto.subtle:
//    base64, UTF-8, SHA-256 and AES-CBC are implemented here in plain JS on plain Arrays.
//  - Episodes use a monotonic global ordinal in `number` (multi-season lists stay
//    ascending); the true on-site episode number rides in `episodeNumber`.
//  - Never log or embed signed stream URLs / tokens. Failure snapshots expose no bare
//    top-level scalar strings (naive stream pickers treat any string as a candidate URL).

var BASE = 'https://sololatino.net';
var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
var DEADLINE_MS = 17000;

function log() {
  try {
    var args = Array.prototype.slice.call(arguments);
    args.unshift('[sololatino]');
    console.log.apply(console, args);
  } catch (_) {}
}

// ── small utils ──────────────────────────────────────────────────────────────

function clean(s) {
  return String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
}
function pad2(n) {
  return (n < 10 ? '0' : '') + n;
}
function stripTags(s) {
  return clean(String(s || '').replace(/<[^>]*>/g, ' '));
}
function decodeEntities(s) {
  return String(s || '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&#x27;/gi, "'");
}
function absUrl(u) {
  u = decodeEntities(clean(u));
  if (!u) return '';
  if (u.indexOf('//') === 0) return 'https:' + u;
  if (u.indexOf('http') === 0) return u;
  if (u.charAt(0) !== '/') u = '/' + u;
  return BASE + u;
}
function toPath(urlOrId) {
  var s = clean(urlOrId);
  s = decodeURIComponent(s);
  if (s.indexOf('sololatino:') === 0) s = s.slice('sololatino:'.length);
  if (s.indexOf('http') === 0) {
    var m = s.match(/^https?:\/\/[^/]+(\/.*)$/i);
    s = m ? m[1] : s;
  }
  if (s.charAt(0) !== '/') s = '/' + s;
  s = s.split('#')[0].split('?')[0];
  if (!/^\/(serie|pelicula)\//i.test(s)) return null;
  return s;
}
function kindOfPath(path) {
  if (/^\/pelicula\//i.test(path)) return 'movie';
  var em = path.match(/temporada-(\d+)\/episodio-(\d+)/i);
  if (em) return 'episode';
  if (/^\/serie\//i.test(path)) return 'series';
  return 'unknown';
}
function hostOf(u) {
  var m = String(u || '').match(/^https?:\/\/([^/]+)/i);
  return m ? m[1] : '';
}
function originOf(u) {
  var h = hostOf(u);
  return h ? 'https://' + h : BASE;
}
function now() {
  return Date.now();
}
function sleep(ms) {
  return new Promise(function (res) {
    setTimeout(res, Math.max(0, ms | 0));
  });
}

// ── base64 / utf8 (no atob / TextEncoder in the app sandbox) ─────────────────

var B64CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
var B64MAP = (function () {
  var m = {};
  for (var i = 0; i < B64CHARS.length; i++) m[B64CHARS.charAt(i)] = i;
  return m;
})();

function b64ToBytes(str) {
  var s = String(str || '').replace(/\s+/g, '');
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  var out = [];
  for (var i = 0; i < s.length; i += 4) {
    var c0 = B64MAP[s.charAt(i)];
    var c1 = B64MAP[s.charAt(i + 1)];
    var c2 = B64MAP[s.charAt(i + 2)];
    var c3 = B64MAP[s.charAt(i + 3)];
    var n = ((c0 << 18) | (c1 << 12) | ((c2 == null ? 0 : c2) << 6) | (c3 == null ? 0 : c3)) >>> 0;
    out.push((n >> 16) & 0xff);
    if (c2 != null) out.push((n >> 8) & 0xff);
    if (c3 != null) out.push(n & 0xff);
  }
  return out;
}

function utf8Encode(str) {
  var s = String(str == null ? '' : str);
  var out = [];
  for (var i = 0; i < s.length; i++) {
    var c = s.charCodeAt(i);
    if (c < 0x80) out.push(c);
    else if (c < 0x800) {
      out.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f));
    } else if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length) {
      var d = s.charCodeAt(i + 1);
      var cp = 0x10000 + ((c - 0xd800) << 10) + (d - 0xdc00);
      out.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3f), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
      i++;
    } else {
      out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f));
    }
  }
  return out;
}

function utf8Decode(bytes) {
  var out = '';
  for (var i = 0; i < bytes.length; ) {
    var b = bytes[i];
    if (b < 0x80) {
      out += String.fromCharCode(b);
      i += 1;
    } else if (b >= 0xc0 && b < 0xe0) {
      out += String.fromCharCode(((b & 0x1f) << 6) | (bytes[i + 1] & 0x3f));
      i += 2;
    } else if (b >= 0xe0 && b < 0xf0) {
      out += String.fromCharCode(((b & 0x0f) << 12) | ((bytes[i + 1] & 0x3f) << 6) | (bytes[i + 2] & 0x3f));
      i += 3;
    } else {
      var cp = ((b & 0x07) << 18) | ((bytes[i + 1] & 0x3f) << 12) | ((bytes[i + 2] & 0x3f) << 6) | (bytes[i + 3] & 0x3f);
      cp -= 0x10000;
      out += String.fromCharCode(0xd800 + (cp >> 10), 0xdc00 + (cp & 0x3ff));
      i += 4;
    }
  }
  return out;
}

function bytesToHex(bytes) {
  var hex = '0123456789abcdef';
  var out = '';
  for (var i = 0; i < bytes.length; i++) {
    out += hex.charAt((bytes[i] >> 4) & 0xf) + hex.charAt(bytes[i] & 0xf);
  }
  return out;
}

// ── SHA-256 (plain JS, plain arrays) ─────────────────────────────────────────

var SHA_K = [
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
];

function ror(x, n) {
  return ((x >>> n) | (x << (32 - n))) >>> 0;
}

function sha256Bytes(bytes) {
  var msg = bytes.slice(0);
  var bitLen = msg.length * 8;
  msg.push(0x80);
  while (msg.length % 64 !== 56) msg.push(0);
  msg.push(0, 0, 0, 0);
  msg.push((bitLen >>> 24) & 0xff, (bitLen >>> 16) & 0xff, (bitLen >>> 8) & 0xff, bitLen & 0xff);

  var h0 = 0x6a09e667, h1 = 0xbb67ae85, h2 = 0x3c6ef372, h3 = 0xa54ff53a;
  var h4 = 0x510e527f, h5 = 0x9b05688c, h6 = 0x1f83d9ab, h7 = 0x5be0cd19;

  var w = new Array(64);
  for (var off = 0; off < msg.length; off += 64) {
    for (var i = 0; i < 16; i++) {
      w[i] = ((msg[off + i * 4] << 24) | (msg[off + i * 4 + 1] << 16) | (msg[off + i * 4 + 2] << 8) | msg[off + i * 4 + 3]) >>> 0;
    }
    for (i = 16; i < 64; i++) {
      var s0 = (ror(w[i - 15], 7) ^ ror(w[i - 15], 18) ^ (w[i - 15] >>> 3)) >>> 0;
      var s1 = (ror(w[i - 2], 17) ^ ror(w[i - 2], 19) ^ (w[i - 2] >>> 10)) >>> 0;
      w[i] = (w[i - 16] + s0 + w[i - 7] + s1) >>> 0;
    }
    var a = h0, b = h1, c = h2, d = h3, e = h4, f = h5, g = h6, h = h7;
    for (i = 0; i < 64; i++) {
      var S1 = (ror(e, 6) ^ ror(e, 11) ^ ror(e, 25)) >>> 0;
      var ch = ((e & f) ^ (~e & g)) >>> 0;
      var t1 = (h + S1 + ch + SHA_K[i] + w[i]) >>> 0;
      var S0 = (ror(a, 2) ^ ror(a, 13) ^ ror(a, 22)) >>> 0;
      var maj = ((a & b) ^ (a & c) ^ (b & c)) >>> 0;
      var t2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0;
      d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    h0 = (h0 + a) >>> 0; h1 = (h1 + b) >>> 0; h2 = (h2 + c) >>> 0; h3 = (h3 + d) >>> 0;
    h4 = (h4 + e) >>> 0; h5 = (h5 + f) >>> 0; h6 = (h6 + g) >>> 0; h7 = (h7 + h) >>> 0;
  }
  var out = [];
  [h0, h1, h2, h3, h4, h5, h6, h7].forEach(function (x) {
    out.push((x >>> 24) & 0xff, (x >>> 16) & 0xff, (x >>> 8) & 0xff, x & 0xff);
  });
  return out;
}

function sha256Hex(str) {
  return bytesToHex(sha256Bytes(utf8Encode(str)));
}

// ── AES-256-CBC decrypt (plain JS, FIPS-197, decrypt-only + PKCS#7 strip) ────
// S-box is generated from GF(2^8) math at load time (no hand-typed tables).

var AES = (function () {
  function xtime(a) {
    var hi = a & 0x80;
    a = (a << 1) & 0xff;
    if (hi) a ^= 0x1b;
    return a;
  }
  function gmul(a, b) {
    var p = 0;
    for (var i = 0; i < 8; i++) {
      if (b & 1) p ^= a;
      a = xtime(a);
      b >>= 1;
    }
    return p & 0xff;
  }
  function ginv(x) {
    if (x === 0) return 0;
    var r = 1, base = x, e = 254;
    while (e) {
      if (e & 1) r = gmul(r, base);
      base = gmul(base, base);
      e >>= 1;
    }
    return r;
  }
  var SBOX = new Array(256), ISBOX = new Array(256);
  (function () {
    for (var x = 0; x < 256; x++) {
      var inv = ginv(x);
      var s = (inv ^ ((inv << 1) | (inv >>> 7)) ^ ((inv << 2) | (inv >>> 6)) ^ ((inv << 3) | (inv >>> 5)) ^ ((inv << 4) | (inv >>> 4)) ^ 0x63) & 0xff;
      SBOX[x] = s;
    }
    for (x = 0; x < 256; x++) ISBOX[SBOX[x]] = x;
  })();

  var RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36];

  function expandKey(key) {
    var Nk = 8, Nr = 14, w = new Array(4 * (Nr + 1));
    var i;
    for (i = 0; i < Nk; i++) {
      w[i] = ((key[4 * i] << 24) | (key[4 * i + 1] << 16) | (key[4 * i + 2] << 8) | key[4 * i + 3]) >>> 0;
    }
    for (i = Nk; i < 4 * (Nr + 1); i++) {
      var t = w[i - 1];
      if (i % Nk === 0) {
        t = ((t << 8) | (t >>> 24)) >>> 0; // RotWord
        t = ((SBOX[(t >>> 24) & 0xff] << 24) | (SBOX[(t >>> 16) & 0xff] << 16) | (SBOX[(t >>> 8) & 0xff] << 8) | SBOX[t & 0xff]) >>> 0; // SubWord
        t = (t ^ (RCON[(i / Nk) - 1] << 24)) >>> 0;
      } else if (i % Nk === 4) {
        t = ((SBOX[(t >>> 24) & 0xff] << 24) | (SBOX[(t >>> 16) & 0xff] << 16) | (SBOX[(t >>> 8) & 0xff] << 8) | SBOX[t & 0xff]) >>> 0;
      }
      w[i] = (w[i - Nk] ^ t) >>> 0;
    }
    return w;
  }

  function decryptBlock(state, w) {
    // state: 16 bytes, layout state[4*col + row]
    var i, c, r;
    function addRoundKey(round) {
      for (c = 0; c < 4; c++) {
        var kw = w[round * 4 + c];
        state[4 * c] ^= (kw >>> 24) & 0xff;
        state[4 * c + 1] ^= (kw >>> 16) & 0xff;
        state[4 * c + 2] ^= (kw >>> 8) & 0xff;
        state[4 * c + 3] ^= kw & 0xff;
      }
    }
    function invShiftRows() {
      var t = state.slice(0);
      for (r = 1; r < 4; r++) {
        for (c = 0; c < 4; c++) {
          state[4 * c + r] = t[4 * (((c - r) % 4 + 4) % 4) + r];
        }
      }
    }
    function invSubBytes() {
      for (i = 0; i < 16; i++) state[i] = ISBOX[state[i]];
    }
    function invMixColumns() {
      for (c = 0; c < 4; c++) {
        var a0 = state[4 * c], a1 = state[4 * c + 1], a2 = state[4 * c + 2], a3 = state[4 * c + 3];
        state[4 * c] = gmul(a0, 14) ^ gmul(a1, 11) ^ gmul(a2, 13) ^ gmul(a3, 9);
        state[4 * c + 1] = gmul(a0, 9) ^ gmul(a1, 14) ^ gmul(a2, 11) ^ gmul(a3, 13);
        state[4 * c + 2] = gmul(a0, 13) ^ gmul(a1, 9) ^ gmul(a2, 14) ^ gmul(a3, 11);
        state[4 * c + 3] = gmul(a0, 11) ^ gmul(a1, 13) ^ gmul(a2, 9) ^ gmul(a3, 14);
      }
    }
    addRoundKey(14);
    for (var round = 13; round >= 1; round--) {
      invShiftRows();
      invSubBytes();
      addRoundKey(round);
      invMixColumns();
    }
    invShiftRows();
    invSubBytes();
    addRoundKey(0);
  }

  function decryptCbc(keyBytes, ivBytes, ctBytes) {
    var w = expandKey(keyBytes);
    var out = [];
    var prev = ivBytes.slice(0, 16);
    for (var off = 0; off + 16 <= ctBytes.length; off += 16) {
      var block = ctBytes.slice(off, off + 16);
      var st = block.slice(0);
      decryptBlock(st, w);
      for (var i = 0; i < 16; i++) out.push(st[i] ^ prev[i]);
      prev = block;
    }
    // PKCS#7 strip (guard: only when the padding is structurally valid)
    if (out.length && out.length % 16 === 0) {
      var pad = out[out.length - 1];
      if (pad >= 1 && pad <= 16 && pad <= out.length) {
        var ok = true;
        for (var j = 0; j < pad; j++) {
          if (out[out.length - 1 - j] !== pad) { ok = false; break; }
        }
        if (ok) out = out.slice(0, out.length - pad);
      }
    }
    return out;
  }

  return { decryptCbc: decryptCbc };
})();

// ── Dean-Edwards JS unpacker (vidhide-family pages) ──────────────────────────

function unpackPacker(payload, radix, count, words) {
  return payload.replace(/\b[\w$]+\b/g, function (w) {
    var idx = parseInt(w, radix);
    if (isNaN(idx) || idx < 0 || idx >= count) return w;
    var rep = words[idx];
    return rep != null && rep !== '' ? rep : w;
  });
}

function tryUnpackEval(html) {
  var m = html.match(/eval\(function\(p,a,c,k,e,[dr]?\)\{[\s\S]*?\}\('([\s\S]*?)',(\d+),(\d+),'([\s\S]*?)'\.split\('\|'\)/);
  if (!m) return null;
  var payload = m[1].replace(/\\'/g, "'");
  var radix = parseInt(m[2], 10);
  var count = parseInt(m[3], 10);
  var words = m[4].split('|');
  return unpackPacker(payload, radix, count, words);
}

function unescapeJs(s) {
  return String(s || '').replace(/\\\//g, '/').replace(/\\u0026/gi, '&').replace(/\\"/g, '"').replace(/\\'/g, "'");
}

// ── network helpers (fetchv2; cookies are handled by the app bridge) ─────────

var SESSION = { xsrf: null, sanctumAt: 0 };

function harvestXsrf(res) {
  try {
    var sc = res && res.headers ? (res.headers['set-cookie'] || res.headers['Set-Cookie'] || res.headers['SET-COOKIE']) : null;
    if (!sc) return;
    var list = Array.isArray(sc) ? sc : [String(sc)];
    for (var i = 0; i < list.length; i++) {
      var m = String(list[i]).match(/(?:^|[;\s,])XSRF-TOKEN=([^;,]+)/);
      if (m) {
        var v = m[1];
        try { v = decodeURIComponent(v); } catch (_) {}
        if (v) SESSION.xsrf = v;
      }
    }
  } catch (_) {}
}

async function resText(res) {
  var t = '';
  try { t = await res.text(); } catch (_) {}
  if (!t && res && typeof res.body === 'string') t = res.body;
  return t || '';
}

async function resJson(res) {
  try {
    var j = await res.json();
    if (j != null) return j;
  } catch (_) {}
  try {
    var b = res && typeof res.body === 'string' ? res.body : '';
    if (b) return JSON.parse(b);
  } catch (_) {}
  return null;
}

async function httpGet(url, headers, opts) {
  var res = await fetchv2(url, Object.assign({ 'User-Agent': UA }, headers || {}), 'GET', null, opts || {});
  harvestXsrf(res);
  return res;
}

async function httpPostJson(url, obj, headers) {
  var body = JSON.stringify(obj);
  var res = await fetchv2(url, Object.assign({ 'User-Agent': UA, 'Content-Type': 'application/json', Accept: 'application/json' }, headers || {}), 'POST', body, {});
  harvestXsrf(res);
  return res;
}

async function ensureSession() {
  if (SESSION.xsrf) return;
  try {
    await httpGet(BASE + '/sanctum/csrf-cookie', { Accept: '*/*', Referer: BASE + '/' });
    SESSION.sanctumAt = now();
  } catch (e) {
    log('sanctum error:', e && e.message);
  }
}

// ── page parsers ─────────────────────────────────────────────────────────────

function pageTitle(html) {
  var m = html.match(/<h1[^>]*class="[^"]*sr-only[^"]*"[^>]*>([\s\S]*?)<\/h1>/i);
  if (m) return stripTags(m[1]);
  m = html.match(/<title>([\s\S]*?)<\/title>/i);
  if (m) {
    var t = stripTags(m[1]);
    t = t.replace(/^Ver\s+/i, '').replace(/\s+Online Latino.*$/i, '').replace(/\s*[—|-]\s*SoloLatino.*$/i, '').replace(/\s*\((19|20)\d{2}\)\s*$/, '');
    return t;
  }
  return '';
}

function pageYear(html, title) {
  var m = html.match(/<title>[^<]*\((\d{4})\)/i);
  if (m) return parseInt(m[1], 10);
  m = String(title || '').match(/\((19|20)\d{2}\)/);
  if (m) return parseInt(m[0].replace(/[()]/g, ''), 10);
  return null;
}

function pageDescription(html) {
  var m = html.match(/<meta\s+name="description"\s+content="([^"]*)"/i) || html.match(/<meta\s+property="og:description"\s+content="([^"]*)"/i);
  if (m) return clean(decodeEntities(m[1]));
  m = html.match(/<p class="text-sm[^"]*"[^>]*style="color:#[0-9a-f]+"[^>]*>([\s\S]*?)<\/p>/i);
  return m ? stripTags(m[1]) : '';
}

function pagePoster(html, title) {
  var re = /<img[^>]+src="(https:\/\/image\.tmdb\.org\/t\/p\/w\d+\/[^"]+)"[^>]*>/gi;
  var m, best = null, any = null;
  while ((m = re.exec(html))) {
    var tag = m[0];
    if (/platform-logo/i.test(tag)) continue;
    var alt = (tag.match(/alt="([^"]*)"/) || [])[1] || '';
    if (!any) any = m[1];
    if (/w(500|780|1280)\//.test(m[1]) && alt && title && clean(alt).toLowerCase() === clean(title).toLowerCase()) {
      best = m[1];
      break;
    }
    if (/w(500|780|1280)\//.test(m[1]) && !best) best = m[1];
  }
  return best || any || null;
}

function langName(code) {
  var map = { mx: 'Latino', esp: 'Castellano', es: 'Español', sub: 'Subtitulado', en: 'Inglés', lat: 'Latino' };
  return map[String(code || '').toLowerCase()] || 'Latino';
}

function parseLangLabel(html) {
  var m = html.match(/data-lang-tab="([^"]+)"[^>]*>([\s\S]*?)<\/button>/i);
  if (m) {
    var label = stripTags(m[2]).replace(/[\u{1F1E6}-\u{1F1FF}\u{1F300}-\u{1FAFF}\u2600-\u27BF]/gu, '').trim();
    if (label) return { code: m[1], label: clean(label) };
    return { code: m[1], label: langName(m[1]) };
  }
  return { code: 'mx', label: 'Latino' };
}

function parsePlayerButtons(html) {
  // Each server button carries a per-language encrypted token; group them by data-lang-group when present.
  var buttons = [];
  var re = /<button[^>]*data-player-token="([^"]+)"[^>]*>([\s\S]*?)<\/button>/gi;
  var m;
  while ((m = re.exec(html))) {
    var tag = m[0];
    var group = (tag.match(/data-lang-group="([^"]+)"/) || [])[1] || null;
    buttons.push({ token: m[1], label: stripTags(m[2]), group: group });
  }
  if (!buttons.length) {
    re = /data-player-token="([^"]+)"/gi;
    var seen = {};
    while ((m = re.exec(html))) {
      if (seen[m[1]]) continue;
      seen[m[1]] = true;
      buttons.push({ token: m[1], label: 'Servidor ' + (buttons.length + 1), group: null });
    }
  }
  // tokens are encrypted blobs (base64); skip anything pathologically short
  return buttons.filter(function (b) {
    return b.token && b.token.length > 24;
  });
}

function parseImdb(html) {
  var m = String(html || '').match(/imdb\.com\/title\/(tt\d{7,9})/i);
  return m ? m[1] : null;
}

function parseEpisodesFromSeriesPage(html) {
  var out = [];
  var re = /<a[^>]*href="(https?:\/\/[^"]*?|\/[^"]*?)temporada-(\d+)\/episodio-(\d+)"[^>]*class="ep-item[^"]*"[^>]*>([\s\S]*?)<\/a>/gi;
  var m;
  while ((m = re.exec(html))) {
    var href = m[1] + 'temporada-' + m[2] + '/episodio-' + m[3];
    var season = parseInt(m[2], 10);
    var number = parseInt(m[3], 10);
    var inner = m[4];
    var img = (inner.match(/<img[^>]+src="([^"]+)"/i) || [])[1] || null;
    var t = (inner.match(/<p class="text-sm font-semibold[^"]*"[^>]*>([\s\S]*?)<\/p>/i) || [])[1];
    var name = t ? stripTags(t) : '';
    name = name.replace(/\.(mp4|mkv|mov|avi|webm)$/i, '').trim();
    var syn = (inner.match(/<p class="text-xs mt-1 line-clamp-2"[^>]*>([\s\S]*?)<\/p>/i) || [])[1];
    var date = (inner.match(/<p class="text-xs mt-1"[^>]*>([\s\S]*?)<\/p>/i) || [])[1];
    out.push({
      season: season,
      number: number,
      episodeNumber: number,
      title: 'S' + pad2(season) + 'E' + pad2(number) + (name ? ': ' + clean(name) : ''),
      href: toPath(href),
      image: img,
      description: syn ? stripTags(syn) : null,
      airdate: date ? stripTags(date) : null
    });
  }
  // dedupe by season/number (first wins) and sort ascending
  var seen = {};
  out = out.filter(function (e) {
    var k = e.season + ':' + e.number;
    if (seen[k]) return false;
    seen[k] = true;
    return true;
  });
  out.sort(function (a, b) { return a.season - b.season || a.number - b.number; });
  return out;
}

// ── embed69: PoW + AES-CBC decrypted hoster links ────────────────────────────

function parseEmbed69(html) {
  var ch = (html.match(/POW_CHALLENGE\s*=\s*'([^']+)'/) || [])[1];
  var salt = (html.match(/POW_SALT\s*=\s*'([^']+)'/) || [])[1];
  var diff = (html.match(/POW_DIFFICULTY\s*=\s*(\d+)/) || [])[1];
  if (!ch || !salt) return null;
  var di = parseInt(diff || '3', 10);
  if (!(di >= 1 && di <= 6)) di = 3;

  var i = html.indexOf('dataLink');
  if (i < 0) return null;
  i = html.indexOf('[', i);
  if (i < 0) return null;
  // bracket scan with string awareness
  var depth = 0, inStr = false, esc = false, end = -1;
  for (var j = i; j < html.length; j++) {
    var c = html.charAt(j);
    if (inStr) {
      if (esc) esc = false;
      else if (c === '\\') esc = true;
      else if (c === '"') inStr = false;
    } else {
      if (c === '"') inStr = true;
      else if (c === '[' || c === '{') depth++;
      else if (c === ']' || c === '}') {
        depth--;
        if (depth === 0) { end = j + 1; break; }
      }
    }
  }
  if (end < 0) return null;
  var data;
  try { data = JSON.parse(html.slice(i, end)); } catch (e) { return null; }
  if (!data || !data.length) return null;
  return { challenge: ch, salt: salt, difficulty: di, dataLink: data };
}

function solvePow(challenge, salt, difficulty) {
  var target = '';
  for (var k = 0; k < difficulty; k++) target += '0';
  var nonce = 0;
  var cap = 2000000;
  while (nonce < cap) {
    var hex = sha256Hex(challenge + nonce);
    if (hex.slice(0, difficulty) === target) {
      var key = sha256Bytes(utf8Encode(challenge + nonce + salt));
      return { nonce: nonce, key: key };
    }
    nonce++;
  }
  return null;
}

function decryptHosterLinks(parsed) {
  var solved = solvePow(parsed.challenge, parsed.salt, parsed.difficulty);
  if (!solved) return [];
  var links = [];
  for (var f = 0; f < parsed.dataLink.length; f++) {
    var file = parsed.dataLink[f] || {};
    var lang = clean(file.video_language || '').toUpperCase() || 'LAT';
    var embeds = file.sortedEmbeds || [];
    for (var e = 0; e < embeds.length; e++) {
      var emb = embeds[e] || {};
      if (!emb.link) continue;
      try {
        var raw = b64ToBytes(emb.link);
        if (raw.length < 32) continue;
        var iv = raw.slice(0, 16);
        var ct = raw.slice(16);
        var pt = AES.decryptCbc(solved.key, iv, ct);
        var url = unescapeHtmlLite(utf8Decode(pt));
        if (url && /^https?:\/\//i.test(url)) {
          links.push({ servername: clean(emb.servername || ''), url: url, lang: lang });
        }
      } catch (err) {
        log('decrypt link failed:', emb.servername, err && err.message);
      }
    }
  }
  return links;
}

function unescapeHtmlLite(s) {
  return String(s || '').replace(/&amp;/g, '&').trim();
}

// ── hoster resolvers ─────────────────────────────────────────────────────────

// Vidhide rotates mirror domains; some mirrors tarpit every request (~20s). The file id is
// portable across mirrors, so swap known-slow hosts for the current fast mirror.
var VIDHIDE_MIRROR_SWAPS = { 'morencius.com': 'callistanise.com', 'minochinos.com': 'callistanise.com' };
function swapVidhideMirror(url) {
  var host = hostOf(url);
  if (!host) return url;
  for (var k in VIDHIDE_MIRROR_SWAPS) {
    if (host === k || host.indexOf('.' + k) >= 0) {
      return url.replace('://' + host + '/', '://' + VIDHIDE_MIRROR_SWAPS[k] + '/');
    }
  }
  return url;
}

function hosterFamily(servername, url) {
  var s = (clean(servername) + ' ' + hostOf(url)).toLowerCase();
  if (s.indexOf('vidhide') >= 0 || s.indexOf('morencius') >= 0 || s.indexOf('minochinos') >= 0 || s.indexOf('acek-cdn') >= 0) return 'vidhide';
  if (s.indexOf('streamwish') >= 0 || s.indexOf('hglink') >= 0 || s.indexOf('strwish') >= 0 || s.indexOf('swish') >= 0) return 'streamwish';
  if (s.indexOf('voe') >= 0) return 'voe';
  return 'unknown';
}

function parseMasterQuality(masterText) {
  var best = null;
  var re = /RESOLUTION=(\d+)x(\d+)/gi;
  var m;
  while ((m = re.exec(masterText))) {
    var h = parseInt(m[2], 10);
    if (!best || h > best) best = h;
  }
  return best ? best + 'p' : 'Auto';
}

function parseVariantUrl(masterUrl, masterText) {
  var lines = String(masterText || '').split(/\r?\n/);
  for (var i = 0; i < lines.length; i++) {
    var l = lines[i].trim();
    if (!l || l.charAt(0) === '#') continue;
    if (/^https?:\/\//i.test(l)) return l;
    var base = masterUrl.split('?')[0];
    base = base.slice(0, base.lastIndexOf('/') + 1);
    return base + l;
  }
  return null;
}

async function verifyHls(url, headers) {
  try {
    var res = await httpGet(url, headers, {});
    if (res.status < 200 || res.status >= 400) return null;
    var body = await resText(res);
    if (body.indexOf('#EXTM3U') < 0) return null;
    var quality = parseMasterQuality(body);
    var variant = parseVariantUrl(url, body);
    return { quality: quality, variant: variant };
  } catch (e) {
    log('verifyHls failed:', e && e.message);
    return null;
  }
}

async function resolveVidhide(url, pageReferer) {
  url = swapVidhideMirror(url);
  var origin = originOf(url);
  var res = await httpGet(url, { Referer: pageReferer || origin + '/' }, {});
  if (res.status < 200 || res.status >= 400) return null;
  var html = await resText(res);
  var unpacked = tryUnpackEval(html) || html;
  var master = null;
  var m = unpacked.match(/hls4\s*:\s*["'](https?:[^"']+master\.m3u8[^"']*)["']/i) ||
          unpacked.match(/hls3\s*:\s*["'](https?:[^"']+master\.m3u8[^"']*)["']/i) ||
          unpacked.match(/hls2\s*:\s*["'](https?:[^"']+master\.m3u8[^"']*)["']/i);
  if (m) master = unescapeJs(m[1]);
  if (!master) {
    var any = unpacked.match(/https?:\/\/[^"'\s\\]+master\.m3u8[^"'\s\\]*/i);
    if (any) master = unescapeJs(any[0]);
  }
  if (!master) {
    var mp4 = unpacked.match(/https?:\/\/[^"'\s\\]+\.mp4[^"'\s\\]*/i);
    if (mp4) {
      var mp4url = unescapeJs(mp4[0]);
      var chk = await httpGet(mp4url, { Referer: origin + '/' }, {});
      if (chk.status >= 200 && chk.status < 400) {
        return { url: mp4url, streamType: 'mp4', quality: 'Auto', headers: { Referer: origin + '/' } };
      }
    }
    return null;
  }
  var verified = await verifyHls(master, { Referer: origin + '/' });
  if (!verified) return null;
  return {
    url: master,
    streamType: 'hls',
    quality: verified.quality,
    headers: { Referer: origin + '/' }
  };
}

// ── player-url POST (token fallback path) ────────────────────────────────────

async function playerUrlFor(token, pagePath, metaCsrf) {
  var referer = absUrl(pagePath);
  for (var attempt = 0; attempt < 2; attempt++) {
    await ensureSession();
    var headers = {
      Origin: BASE,
      Referer: referer
    };
    if (SESSION.xsrf) headers['X-XSRF-TOKEN'] = SESSION.xsrf;
    else if (metaCsrf) headers['X-CSRF-TOKEN'] = metaCsrf;
    var res = await httpPostJson(BASE + '/api/player-url', { t: token }, headers);
    if (res.status === 419) {
      SESSION.xsrf = null;
      SESSION.sanctumAt = 0;
      log('player-url 419; refreshing session');
      continue;
    }
    if (res.status < 200 || res.status >= 400) {
      log('player-url status', res.status);
      return null;
    }
    var data = await resJson(res);
    if (data && data.url) return data;
    return null;
  }
  return null;
}

// ── caches (per process) ─────────────────────────────────────────────────────

var CACHE = { details: {}, episodes: {}, series: {}, seriesOrder: [] };

async function seriesPage(path) {
  var key = String(path || '').replace(/\/+$/, '');
  if (CACHE.series[key]) return CACHE.series[key];
  var res = await httpGet(absUrl(key) + '/', { Accept: 'text/html,*/*', Referer: BASE + '/' }, {});
  if (res.status < 200 || res.status >= 400) throw new Error('Could not load series page (status ' + res.status + ').');
  var html = await resText(res);
  var data = { html: html, imdb: parseImdb(html) };
  CACHE.series[key] = data;
  CACHE.seriesOrder.push(key);
  while (CACHE.seriesOrder.length > 6) {
    var oldKey = CACHE.seriesOrder.shift();
    delete CACHE.series[oldKey];
  }
  return data;
}

// ── contract: search ─────────────────────────────────────────────────────────

// Empty query = home request (runtime convention): return the home rows flattened as cards.
var HOME_CACHE = { at: 0, cards: null };
async function homeCards() {
  if (HOME_CACHE.cards && now() - HOME_CACHE.at < 60000) return HOME_CACHE.cards;
  try {
    var res = await httpGet(BASE + '/', { Accept: 'text/html,*/*' }, {});
    if (res.status < 200 || res.status >= 400) return [];
    var html = await resText(res);
    var sections = parseHomeSections(html);
    var out = [];
    var seen = {};
    for (var i = 0; i < sections.length && out.length < 40; i++) {
      var its = sections[i].items || [];
      for (var j = 0; j < its.length && out.length < 40; j++) {
        var it = its[j];
        if (!it || !it.href || seen[it.href]) continue;
        seen[it.href] = true;
        out.push({ title: it.title, image: it.image, href: it.href });
      }
    }
    HOME_CACHE = { at: now(), cards: out };
    return out;
  } catch (e) {
    log('home cards err:', e && e.message);
    return [];
  }
}

async function searchResults(query) {
  var q = clean(query);
  if (!q) return await homeCards();
  var res = await httpGet(
    BASE + '/api/search/suggest?q=' + encodeURIComponent(q),
    { Accept: 'application/json', Referer: BASE + '/' },
    {}
  );
  if (res.status < 200 || res.status >= 400) throw new Error('Search failed (status ' + res.status + '). Try again.');
  var data = await resJson(res);
  if (!data || !data.length) return [];
  var out = [];
  for (var i = 0; i < data.length; i++) {
    var it = data[i] || {};
    var path = toPath(clean(it.url || ''));
    if (!path) continue;
    var type = /\/pelicula\//i.test(path) ? 'Película' : 'Serie';
    out.push({
      href: path,
      title: clean(it.title || ''),
      image: clean(it.poster || '') || null,
      description: type + (it.year ? ' · ' + it.year : ''),
      year: it.year || null
    });
    if (out.length >= 24) break;
  }
  return out;
}

// ── contract: details ────────────────────────────────────────────────────────

async function extractDetails(urlOrId) {
  var path = toPath(urlOrId);
  if (!path) throw new Error('Unrecognised title reference. Search for the title again.');
  if (CACHE.details[path]) return CACHE.details[path];

  var res = await httpGet(absUrl(path), { Accept: 'text/html,*/*', Referer: BASE + '/' }, {});
  if (res.status < 200 || res.status >= 400) throw new Error('Could not load title page (status ' + res.status + ').');
  var html = await resText(res);
  if (!html || html.length < 500) throw new Error('Empty title page.');

  var t = pageTitle(html);
  var info = {
    title: t || 'Sin título',
    description: pageDescription(html),
    image: pagePoster(html, t),
    year: pageYear(html, t),
    type: kindOfPath(path) === 'movie' ? 'movie' : 'series',
    href: path
  };
  CACHE.details[path] = info;
  return info;
}

// ── contract: episodes ───────────────────────────────────────────────────────

async function extractEpisodes(urlOrId) {
  var path = toPath(urlOrId);
  if (!path) throw new Error('Unrecognised title reference. Search for the title again.');
  if (CACHE.episodes[path]) return CACHE.episodes[path];

  var kind = kindOfPath(path);
  if (kind === 'movie') {
    var det = CACHE.details[path];
    var out = [{ season: 1, number: 1, episodeNumber: 1, title: 'Película completa', href: path }];
    if (det && det.description) out[0].description = det.description;
    CACHE.episodes[path] = out;
    return out;
  }

  var data = await seriesPage(path);
  var eps = parseEpisodesFromSeriesPage(data.html || '');
  // `number` is a monotonic global ordinal so multi-season lists stay ascending for the
  // app and the integrity checker; the real on-site episode number stays in `episodeNumber`.
  for (var i = 0; i < eps.length; i++) {
    if (eps[i].episodeNumber == null) eps[i].episodeNumber = eps[i].number;
    eps[i].number = i + 1;
  }
  CACHE.episodes[path] = eps;
  if (!eps.length) log('no episodes parsed for', path);
  return eps;
}

// ── contract: stream ─────────────────────────────────────────────────────────

function failure(message, isMovie) {
  return {
    streams: [],
    servers: [],
    subtitles: [],
    movie: !!isMovie,
    error: { message: message }
  };
}

async function decodeEmbed69Candidates(urls, referer, timedOut) {
  var hosters = [];
  var seen = {};
  for (var i = 0; i < urls.length && !timedOut(); i++) {
    try {
      var res = await httpGet(urls[i], { Referer: referer }, {});
      if (res.status < 200 || res.status >= 400) { log('embed69 status', res.status, hostOf(urls[i])); continue; }
      var html = await resText(res);
      var parsed = parseEmbed69(html);
      if (!parsed) { log('embed69 payload not parsed at', hostOf(urls[i])); continue; }
      var links = decryptHosterLinks(parsed);
      log('embed69', hostOf(urls[i]), '-> decrypted', links.length, 'hoster links');
      for (var j = 0; j < links.length; j++) {
        if (seen[links[j].url]) continue;
        seen[links[j].url] = true;
        hosters.push(links[j]);
      }
    } catch (e) {
      log('embed69 error:', e && e.message);
    }
  }
  return hosters;
}

async function resolveHosters(hosters, langLabel, timedOut) {
  var servers = [];
  var seen = {};
  for (var i = 0; i < hosters.length && !timedOut(); i++) {
    var h = hosters[i];
    var fam = hosterFamily(h.servername, h.url);
    var got = null;
    try {
      if (fam === 'vidhide') {
        got = await resolveVidhide(h.url, 'https://embed69.org/');
      } else if (fam === 'streamwish' || fam === 'voe') {
        log('hoster', fam, 'not supported yet');
        continue;
      } else if (/\.(m3u8|mp4)(\?|#|$)/i.test(h.url)) {
        var chk = await verifyHls(h.url, { Referer: 'https://embed69.org/' });
        if (chk) got = { url: h.url, streamType: 'hls', quality: chk.quality, headers: { Referer: 'https://embed69.org/' } };
      } else {
        log('hoster unknown:', hostOf(h.url));
        continue;
      }
    } catch (e) {
      log('hoster', fam, 'error:', e && e.message);
    }
    if (!got || seen[got.url]) continue;
    seen[got.url] = true;
    var audioText = (langLabel && langLabel.label) || 'Latino';
    var brand = h.servername ? h.servername.replace(/^\w/, function (c) { return c.toUpperCase(); }) : fam;
    servers.push({
      name: brand + ' — SoloLatino',
      label: audioText + ' · ' + brand + (got.quality && got.quality !== 'Auto' ? ' · ' + got.quality : ''),
      url: got.url,
      headers: got.headers || {},
      streamType: got.streamType || 'hls',
      lang: 'dub',
      audioLanguage: 'es',
      quality: got.quality || 'Auto',
      qualities: [{ label: got.quality || 'Auto', url: got.url, headers: got.headers || {} }]
    });
  }
  return servers;
}

async function buttonsFromPage(path) {
  var res = await httpGet(absUrl(path), { Accept: 'text/html,*/*', Referer: BASE + '/' }, {});
  if (res.status < 200 || res.status >= 400) return null;
  var html = await resText(res);
  var buttons = parsePlayerButtons(html);
  if (!buttons.length) return null;
  return {
    path: path,
    buttons: buttons,
    metaCsrf: (html.match(/csrf-token"\s+content="([^"]+)"/) || [])[1] || null,
    lang: parseLangLabel(html)
  };
}

async function tokenPathHosters(src, timedOut) {
  if (!src) return [];
  var urls = [];
  var seen = {};
  for (var i = 0; i < src.buttons.length && !timedOut(); i++) {
    try {
      var pr = await playerUrlFor(src.buttons[i].token, src.path, src.metaCsrf);
      if (pr && pr.url && hostOf(pr.url).indexOf('embed69') >= 0 && !seen[pr.url]) {
        seen[pr.url] = true;
        urls.push(pr.url);
      } else if (pr && pr.url) {
        log('token path -> non-embed69 player', hostOf(pr.url));
      }
    } catch (e) {
      log('token path err:', e && e.message);
    }
    if (i < src.buttons.length - 1) await sleep(200);
  }
  return decodeEmbed69Candidates(urls, absUrl(src.path), timedOut);
}

async function extractStreamUrl(urlOrId) {
  var path = toPath(urlOrId);
  if (!path) throw new Error('Unrecognised episode reference.');
  var kind = kindOfPath(path);
  var isMovie = kind === 'movie';
  var started = now();
  function timedOut() { return now() - started > DEADLINE_MS; }

  var candidateUrls = [];
  var fallbackSrc = null;
  var langLabel = null;

  if (isMovie) {
    // movie page: IMDb id + (fallback) player tokens, one fetch
    var res = await httpGet(absUrl(path), { Accept: 'text/html,*/*', Referer: BASE + '/' }, {});
    if (res.status < 200 || res.status >= 400) {
      return failure('Could not load the watch page (status ' + res.status + '). Try again.', true);
    }
    var html = await resText(res);
    var imdb = parseImdb(html);
    if (imdb) candidateUrls.push('https://embed69.org/f/' + imdb);
    var buttons = parsePlayerButtons(html);
    if (buttons.length) {
      fallbackSrc = {
        path: path,
        buttons: buttons,
        metaCsrf: (html.match(/csrf-token"\s+content="([^"]+)"/) || [])[1] || null,
        lang: parseLangLabel(html)
      };
      langLabel = fallbackSrc.lang;
    }
  } else if (kind === 'episode') {
    var em = path.match(/^(.*?)\/temporada-(\d+)\/episodio-(\d+)\/?$/i);
    if (!em) return failure('Unrecognised episode reference.', false);
    var imdbS = null;
    try {
      var seriesData = await seriesPage(em[1]);
      imdbS = seriesData.imdb;
    } catch (e) {
      log('series page err:', e && e.message);
    }
    if (imdbS) {
      candidateUrls.push('https://embed69.org/f/' + imdbS + '-' + parseInt(em[2], 10) + 'x' + parseInt(em[3], 10));
    }
  } else {
    return failure('Unrecognised episode reference.', false);
  }

  // primary: decode the derived player URL(s) -> hoster links
  var hosters = await decodeEmbed69Candidates(candidateUrls, absUrl(path), timedOut);

  // fallback: the site's token API (needs session cookies; kept graceful)
  if (!hosters.length && !timedOut()) {
    try {
      if (!fallbackSrc) fallbackSrc = await buttonsFromPage(path);
      if (fallbackSrc && fallbackSrc.lang) langLabel = langLabel || fallbackSrc.lang;
      hosters = await tokenPathHosters(fallbackSrc, timedOut);
    } catch (e) {
      log('token fallback err:', e && e.message);
    }
  }

  if (!hosters.length) {
    return failure('No playable links could be decoded from the source. Try again later.', isMovie);
  }

  var servers = await resolveHosters(hosters, langLabel, timedOut);
  if (!servers.length) {
    return failure('The servers responded but no playable stream was found. Try again later.', isMovie);
  }

  var primary = servers[0];
  return {
    url: primary.url,
    streams: [primary.url],
    headers: primary.headers,
    streamType: primary.streamType,
    lang: 'dub',
    quality: primary.quality || 'Auto',
    defaultQuality: primary.quality || 'Auto',
    qualities: primary.qualities,
    servers: servers,
    subtitles: [],
    movie: isMovie
  };
}

function slugify(s) {
  var t = String(s || '').toLowerCase();
  t = t
    .replace(/[áàäâã]/g, 'a')
    .replace(/[éèëê]/g, 'e')
    .replace(/[íìïî]/g, 'i')
    .replace(/[óòöô]/g, 'o')
    .replace(/[úùüû]/g, 'u')
    .replace(/ñ/g, 'n')
    .replace(/ç/g, 'c');
  t = t.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return t.slice(0, 64) || 'section';
}

function parseListCards(html) {
  var items = [];
  var seen = {};
  var re = /<a[^>]+href="(?:https?:\/\/sololatino\.net)?(\/(?:serie|pelicula)\/[^"'#?]+)"[^>]*>([\s\S]*?)<\/a>/gi;
  var m;
  while ((m = re.exec(html))) {
    var path = m[1];
    if (seen[path]) continue;
    var inner = m[2];
    var image = null;
    var title = '';
    var im1 = inner.match(/<img[^>]+src="([^"]+)"[^>]*alt="([^"]*)"/i);
    if (im1) { image = im1[1]; title = im1[2]; }
    if (!image) {
      var im2 = inner.match(/<img[^>]+alt="([^"]*)"[^>]*src="([^"]+)"/i);
      if (im2) { title = im2[1]; image = im2[2]; }
    }
    if (!image) {
      var im3 = inner.match(/<img[^>]+src="([^"]+)"/i);
      if (im3) image = im3[1];
    }
    if (!title) {
      var tt = inner.match(/class="card__title"[^>]*>([\s\S]*?)</i);
      title = tt ? stripTags(tt[1]) : stripTags(inner).slice(0, 80);
    }
    if (!image || !title) continue;
    seen[path] = true;
    items.push({ title: title, image: decodeEntities(image), href: path });
  }
  return items;
}

// ── contract: discovery home ─────────────────────────────────────────────────

function parseHomeSections(html) {
  var sections = [];
  var h2re = /<h2[^>]*>([\s\S]*?)<\/h2>/gi;
  var marks = [];
  var m;
  while ((m = h2re.exec(html))) {
    marks.push({ title: stripTags(m[1]), start: h2re.lastIndex });
  }
  for (var s = 0; s < marks.length; s++) {
    var title = marks[s].title;
    if (!title) continue;
    var end = s + 1 < marks.length ? html.indexOf('<h2', marks[s].start) : html.length;
    if (end < 0) end = html.length;
    var body = html.slice(marks[s].start, Math.min(end, marks[s].start + 120000));
    var items = [];
    var seen = {};
    var are = /<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    var a;
    while ((a = are.exec(body))) {
      var href = decodeEntities(a[1]);
      var pm = href.match(/(?:https?:\/\/sololatino\.net)?(\/(?:serie|pelicula)\/[^"'#?]+)/i);
      var path = pm ? pm[1] : null;
      if (!path || seen[path]) continue;
      var inner = a[2];
      var img = (inner.match(/<img[^>]+src="([^"]+)"/i) || [])[1] || null;
      if (!img) continue;
      var alt = (inner.match(/<img[^>]+alt="([^"]*)"/i) || [])[1] || '';
      var t = clean(alt) || stripTags(inner).slice(0, 80);
      if (!t) continue;
      seen[path] = true;
      items.push({ title: t, image: decodeEntities(img), href: path });
      if (items.length >= 24) break;
    }
    if (items.length >= 4) {
      var sid = slugify(title);
      var section = { id: sid, title: title, items: items };
      if (sid === 'series-recientes') section.viewAll = { mode: 'feed', feedId: 'series' };
      if (sid === 'peliculas-recientes') section.viewAll = { mode: 'feed', feedId: 'peliculas' };
      sections.push(section);
    }
  }
  return sections.slice(0, 8);
}

async function discoveryHome() {
  var res = await httpGet(BASE + '/', { Accept: 'text/html,*/*' }, {});
  if (res.status < 200 || res.status >= 400) throw new Error('Could not load home page (status ' + res.status + ').');
  var html = await resText(res);
  var sections = parseHomeSections(html);
  if (!sections.length) throw new Error('Home page empty.');
  return { sections: sections };
}

async function discoveryFeed(feedId, page) {
  var key = String(feedId || 'series').toLowerCase();
  var pageNum = Math.max(1, Number(page) || 1);
  var listPath = key === 'peliculas' ? '/peliculas' : '/series';
  var url = BASE + listPath + (pageNum > 1 ? '?page=' + pageNum : '');
  var res = await httpGet(url, { Accept: 'text/html,*/*', Referer: BASE + '/' }, {});
  if (res.status < 200 || res.status >= 400) throw new Error('Could not load feed (status ' + res.status + ').');
  var html = await resText(res);
  var items = parseListCards(html).slice(0, 24);
  var nextPat = new RegExp('page=' + (pageNum + 1) + '(?:[^0-9]|$)');
  var hasMore = nextPat.test(html);
  return { items: items, page: pageNum, hasMore: hasMore };
}
