(() => {
  'use strict';
  const ID = 'tagesschau';
  const PAGE = 'https://www.tagesschau.de/multimedia/livestreams/livestream1';
  const TITLE = 'Tagesschau Live';
  function requireChannel(id) {
    const normalized = String(id).replace(/^https:\/\/www\.tagesschau\.de\//, '').replace(/^\//, '');
    if (normalized !== ID && normalized !== 'multimedia/livestreams/livestream1') throw new Error('Unknown live channel');
  }
  async function text(url) {
    const r = await fetchv2(url, {}, 'GET', null, {timeoutMs: 6000});
    const status = Number(r.status || r.statusCode);
    if (status !== 200) throw new Error('Broadcaster HTTP ' + status + (status === 403 ? ' (access or geographic restriction)' : ''));
    const body = typeof r.body === 'string' ? r.body : typeof r.text === 'function' ? await r.text() : '';
    if (!body || body.length > 1048576) throw new Error('Invalid broadcaster response');
    return body;
  }
  function mediaUrl(value, base) {
    if (base && /^[a-zA-Z0-9_-]+\.m3u8$/.test(value)) value = base.slice(0, base.lastIndexOf('/') + 1) + value;
    if (!/^https:\/\/tagesschau\.akamaized\.net\/hls\/live\/[a-zA-Z0-9_./-]+\.m3u8$/.test(value)) throw new Error('Unrecognized broadcaster stream');
    return value;
  }
  function card() { return {id: ID, url: PAGE, title: TITLE, description: 'German-language public news channel. Geographic restrictions may apply.', subAvailable: true, dubAvailable: false}; }
  async function liveHome() { return {items: [{id: ID, title: TITLE, category: 'News', kind: 'channel', status: 'unknown', language: 'German'}]}; }
  async function searchResults(query) {
    const q = String(query || '').trim().toLowerCase();
    return !q || 'tagesschau live german news'.includes(q) ? [card()] : [];
  }
  async function extractDetails(id) { requireChannel(id); return card(); }
  async function extractEpisodes(id) {
    requireChannel(id);
    return [{id: ID, href: ID, seriesId: ID, title: TITLE, number: 1, episodeNumber: 1, subAvailable: true, dubAvailable: false}];
  }
  async function extractStreamUrl(id, lang) {
    requireChannel(id);
    if (lang === 'dub') throw new Error('This channel has no dub mode');
    const html = await text(PAGE);
    const match = html.match(/"contentUrl"\s*:\s*("(?:[^"\\]|\\.)*")/);
    if (!match) throw new Error('No public live source returned');
    const url = mediaUrl(JSON.parse(match[1]));
    const master = await text(url);
    if (!master.trimStart().startsWith('#EXTM3U')) throw new Error('Invalid HLS master');
    const lines = master.split(/\r?\n/);
    let variant;
    for (let i = 0; i < lines.length - 1; i++) {
      if (lines[i].startsWith('#EXT-X-STREAM-INF:') && /avc1|hvc1|hev1/.test(lines[i])) { variant = mediaUrl(lines[i + 1].trim(), url); break; }
    }
    if (!variant) throw new Error('No video rendition returned');
    const playlist = await text(variant);
    if (!playlist.trimStart().startsWith('#EXTM3U') || !playlist.includes('#EXTINF:') || playlist.includes('#EXT-X-ENDLIST') || /\.(?:png|jpg|jpeg|webp)(?:[?\s]|$)/i.test(playlist)) throw new Error('Not an active live video playlist');
    return {url, type: 'hls', isLive: true, subtitles: [], headers: {}};
  }
  Object.assign(globalThis, {liveHome, searchResults, extractDetails, extractEpisodes, extractStreamUrl});
})();
