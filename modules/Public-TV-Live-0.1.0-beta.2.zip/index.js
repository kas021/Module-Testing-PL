(() => {
  'use strict';
  const INDEX = 'https://iptv-org.github.io/iptv/index.m3u';
  const APPROVED = [
  {
    "id": "ACISportTV.it@SD",
    "title": "ACI Sport TV SD",
    "category": "Sports",
    "language": "Unknown",
    "url": "https://webstream.multistream.it/memfs/e2cb3629-c1a2-495b-b43a-9eb386f04ed8.m3u8",
    "hosts": [
      "webstream.multistream.it"
    ],
    "imageUrl": "https://i.imgur.com/U8cHMOt.png",
    "checkedAt": "2026-10-17T18:49:44+01:00"
  },
  {
    "id": "France24.fr@English",
    "title": "France 24 English",
    "category": "News",
    "language": "English",
    "url": "https://live.france24.com/hls/live/2037218-b/F24_EN_HI_HLS/master_5000.m3u8",
    "hosts": [
      "live.france24.com"
    ],
    "imageUrl": "https://xstreamcp-assets-msp.streamready.in/assets/LIVETV/LIVECHANNEL/LIVETV_LIVETVCHANNEL_FRANCE_24/images/LOGO_HD/image.png",
    "checkedAt": "2026-10-17T18:49:28+01:00"
  },
  {
    "id": "France24.fr@Arabic",
    "title": "France 24 Arabic",
    "category": "News",
    "language": "Arabic",
    "url": "https://live.france24.com/hls/live/2037222-b/F24_AR_HI_HLS/master_5000.m3u8",
    "hosts": [
      "live.france24.com"
    ],
    "imageUrl": "https://xstreamcp-assets-msp.streamready.in/assets/LIVETV/LIVECHANNEL/LIVETV_LIVETVCHANNEL_FRANCE_24/images/LOGO_HD/image.png",
    "checkedAt": "2026-10-17T18:49:28+01:00"
  }
];
  let cache, cachedAt = 0, pending;
  function host(url) {
    const m = String(url).match(/^https:\/\/([a-z0-9.-]+)\/[^\s]*$/i);
    return m ? m[1].toLowerCase() : '';
  }
  function resolve(ref, base) {
    if (/^https:\/\//.test(ref)) return ref;
    if (/^[a-z][a-z0-9+.-]*:/i.test(ref) || ref.startsWith('//')) throw new Error('Unsafe media route');
    return ref.startsWith('/') ? base.match(/^https:\/\/[^/]+/)[0] + ref :
      base.split('?')[0].replace(/[^/]+$/, '') + ref;
  }
  function inspectMedia(body, base, hosts) {
    if (!body.trimStart().startsWith('#EXTM3U') || !/#EXTINF:/.test(body) ||
        /#EXT-X-ENDLIST|#EXT-X-PLAYLIST-TYPE:VOD/.test(body)) return false;
    const refs = body.split(/\r?\n/).map(x => x.trim()).filter(x => x && x[0] !== '#');
    for (const m of body.matchAll(/\bURI="([^"]+)"/g)) refs.push(m[1]);
    return refs.length > 0 && refs.every(ref => {
      const url = resolve(ref, base);
      return hosts.includes(host(url)) && !/\.(?:jpg|jpeg|png|webp)(?:[?#]|$)/i.test(url);
    });
  }
  async function text(url, hosts, timeoutMs = 8000, maxBytes = 1048576) {
    if (!hosts.includes(host(url))) throw new Error('Unapproved channel destination');
    const r = await fetchv2(url, {}, 'GET', null, {timeoutMs, maxBytesHint: maxBytes});
    if (Number(r.status || r.statusCode) !== 200 || r.finalUrlKnown === false) {
      throw new Error('Channel request unavailable');
    }
    const finalUrl = r.finalUrl || r.url || url;
    if (!hosts.includes(host(finalUrl))) throw new Error('Unapproved channel redirect');
    const body = typeof r.body === 'string' ? r.body : typeof r.text === 'function' ? await r.text() : '';
    if (!body || body.length > maxBytes) throw new Error('Invalid channel response');
    return {body, url: finalUrl};
  }
  function parse(body) {
    if (!body.trimStart().startsWith('#EXTM3U') || /#EXT-X-/i.test(body)) {
      throw new Error('Expected a channel catalogue');
    }
    const found = new Set();
    let entry;
    for (const raw of body.split(/\r?\n/)) {
      const row = raw.trim();
      if (row.startsWith('#EXTINF:')) {
        const id = (row.match(/\btvg-id="([^"]+)"/) || [])[1];
        entry = APPROVED.find(c => c.id === id);
      } else if (row && row[0] !== '#') {
        // A new route under the same ID must be tested before it is activated.
        if (entry && row === entry.url) found.add(entry.id);
        entry = null;
      }
    }
    return APPROVED.filter(c => found.has(c.id));
  }
  async function channels(fresh) {
    if (pending) return pending;
    if (!fresh && cache && Date.now() - cachedAt < 300000) return cache;
    pending = text(INDEX, ['iptv-org.github.io'], 8000, 4194304).then(r => {
      if (r.url !== INDEX) throw new Error('Unexpected catalogue location');
      cache = parse(r.body); cachedAt = Date.now(); return cache;
    });
    try { return await pending; } finally { pending = null; }
  }
  async function channel(id, fresh) {
    id = String(id || '').replace(/^https:\/\/iptv-org\.github\.io\//, '');
    if (!APPROVED.some(c => c.id === id)) throw new Error('Channel is not active');
    const c = (await channels(fresh)).find(c => c.id === id);
    if (!c) throw new Error('This channel route changed or was removed; check for a source update');
    return c;
  }
  function card(c) {
    return {id: c.id, title: c.title, image: c.imageUrl, posterUrl: c.imageUrl,
      description: 'Public channel. Availability and programming depend on the broadcaster.',
      subAvailable: true, dubAvailable: false};
  }
  async function liveHome() {
    return {items: (await channels(false)).map(c => ({id: c.id, title: c.title,
      imageUrl: c.imageUrl, category: c.category, language: c.language, kind: 'channel', status: 'unknown'}))};
  }
  async function searchResults(query) {
    const q = String(query || '').trim().toLowerCase();
    return (await channels(false)).filter(c => !q || c.title.toLowerCase().includes(q)).map(card);
  }
  async function extractDetails(id) { return card(await channel(id, false)); }
  async function extractEpisodes(id) {
    const c = await channel(id, false);
    return [{id: c.id, href: c.id, seriesId: c.id, title: c.title, number: 1,
      episodeNumber: 1, subAvailable: true, dubAvailable: false}];
  }
  async function extractStreamUrl(id, lang) {
    if (lang === 'dub') throw new Error('Live channels do not expose alternate dub mode');
    const c = await channel(id, true);
    // The native bridge enforces its own request deadline; options are hints only.
    const r = await text(c.url, c.hosts, 6000);
    if (!r.body.trimStart().startsWith('#EXTM3U') || /#EXT-X-ENDLIST/.test(r.body)) {
      throw new Error('Channel did not return a live playlist');
    }
    if (/#EXT-X-STREAM-INF:/.test(r.body)) {
      const allVariants = [...r.body.matchAll(/#EXT-X-STREAM-INF:[^\r\n]*[\r\n]+([^#\s][^\r\n]*)/g)];
      const refs = allVariants.map(v => v[1].trim());
      for (const m of r.body.matchAll(/\bURI="([^"]+)"/g)) refs.push(m[1]);
      if (!refs.every(ref => c.hosts.includes(host(resolve(ref, r.url))))) throw new Error('Unapproved playlist route');
      const variants = allVariants.slice(0, 2);
      let verified = false;
      for (const variant of variants) {
        const ref = variant[1].trim();
        const url = resolve(ref, r.url);
        try {
          const media = await text(url, c.hosts, 4000);
          if (inspectMedia(media.body, media.url, c.hosts)) {
            verified = true; break;
          }
        } catch (_) { /* Check another quality from this approved channel. */ }
      }
      if (!verified) throw new Error('No verified live quality is available');
    } else if (!inspectMedia(r.body, r.url, c.hosts)) {
      throw new Error('Channel has no live media');
    }
    return {url: r.url, type: 'hls', streamType: 'hls', isLive: true, subtitles: [], headers: {}};
  }
  Object.assign(globalThis, {liveHome, searchResults, extractDetails, extractEpisodes, extractStreamUrl});
})();
