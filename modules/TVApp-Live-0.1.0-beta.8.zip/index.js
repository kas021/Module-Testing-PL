// TVApp Live (tvapp1.com) — standalone Live discovery + resolution candidate.
//
// Status: DISCOVERY + NATIVE RESOLUTION WORKING. The provider's /fetch payload
// decode was recovered (see findings/W2_decoder_oracle_findings.md) and is
// implemented below in pure JS: shifted-base64 -> ChaCha20-Poly1305 with the
// per-request key header as the raw 32-byte key. Resolution performs the real
// request, decodes fresh every play, and fails VISIBLY at a named stage if the
// provider ever changes. Native media validation remains required after resolution.
//
// Rules honoured: no fabricated schedules/scores/status, no fuzzy merging,
// catalogue-only caching, fresh resolution on every play, bounded requests,
// HTTPS-only media, per-candidate headers, no embed HTML handed to the player.
(() => {
  'use strict';

  const MATCH_API = 'https://api-backups.handleapi.win';
  const PPV_API = 'https://api.ppv.st/api/streams';
  const USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
  const MAX_ITEMS = 1000;
  const CATALOG_TTL_MS = 45000;      // bounded catalogue cache (< the 60 s guide cadence)
  // Best-effort scheduling budget. Native HTTP uses its own fixed timeout;
  // timeoutMs hints do not abort an in-flight request on all app versions.
  const CALL_BUDGET_MS = 14000;
  const CATEGORY_LABELS = {
    'american-football': 'American Football', 'motor-sports': 'Motor Sport', 'basketball': 'Basketball',
    'tennis': 'Tennis', 'rugby': 'Rugby', 'cricket': 'Cricket', 'football': 'Football',
    'hockey': 'Hockey', 'baseball': 'Baseball', 'fight': 'Fight', 'other': 'Other',
  };
  const KNOWN_SOURCE_IDS = new Set(['golf', 'delta', 'admin', 'echo']);

  const cache = { matches: { at: 0, rows: null }, ppv: { at: 0, rows: null } };

  function deadlineFrom(budget) { return Date.now() + (budget || CALL_BUDGET_MS); }
  function remaining(deadline) { return deadline - Date.now(); }

  async function getJson(url, deadline) {
    const budget = remaining(deadline);
    if (budget <= 250) throw new Error('Deadline exceeded before ' + url);
    const res = await fetchv2(url, { 'User-Agent': USER_AGENT, Accept: 'application/json,*/*' }, 'GET', null,
      { timeoutMs: Math.min(budget, 8000), maxBytesHint: 3145728 });
    const status = Number(res && (res.status || res.statusCode));
    if (status !== 200) throw new Error('Catalogue HTTP ' + status + ' for ' + url);
    let data = null;
    try { data = await res.json(); } catch (_) { data = null; }
    if (data == null && typeof res.body === 'string' && res.body) {
      try { data = JSON.parse(res.body); } catch (_) { throw new Error('Malformed JSON from ' + url); }
    }
    if (data == null) throw new Error('Empty response from ' + url);
    return data;
  }

  function httpsOrNothing(value) {
    const s = String(value || '').trim();
    return /^https:\/\/[^\s"]+$/i.test(s) && s.length <= 2048 ? s : '';
  }

  // ── normalizers ────────────────────────────────────────────────────────────

  function normalizeMatch(record) {
    const id = String(record && record.id || '').trim();
    const title = String(record && record.title || '').trim();
    if (!id || !title) return null;
    const sources = Array.isArray(record.sources) ? record.sources : [];
    const known = sources.filter(s => s && KNOWN_SOURCE_IDS.has(String(s.source || '')));
    if (!known.length) return null;
    const category = CATEGORY_LABELS[String(record.category || '').toLowerCase()] || 'Other';
    let status = 'unknown', startsAt;
    const start = parseTimestamp(record.date, 'auto');
    if (start && start > Date.now()) { status = 'upcoming'; startsAt = new Date(start).toISOString(); }
    return {
      id: 'match:' + id,
      title: title.slice(0, 300),
      kind: 'event',
      category: category.slice(0, 80),
      status,
      startsAt,
      imageUrl: httpsOrNothing(record.poster),
      // detection metadata, never returned to the app
      _sources: known.map(s => ({ source: String(s.source), id: String(s.id) })),
    };
  }

  function normalizePpvRecord(record, groupCategory) {
    const id = record && record.id;
    const name = String(record && record.name || '').trim();
    if (id == null || !name) return null;
    const alwaysLive = Number(record.always_live) === 1;
    const isChannelLike = alwaysLive || /24\/7|channel/i.test(String(record.tag || ''));
    const kind = isChannelLike ? 'channel' : 'event';
    let status = alwaysLive ? 'live' : 'unknown';
    let startsAt;
    const start = parseTimestamp(record.starts_at, 'seconds');
    const end = parseTimestamp(record.ends_at, 'seconds');
    if (start && start > Date.now()) { status = 'upcoming'; startsAt = new Date(start).toISOString(); }
    if (!alwaysLive && end && end < Date.now()) status = 'ended';
    const iframe = httpsOrNothing(record.iframe);
    if (!iframe) return null;
    return {
      id: 'ppv:' + String(id),
      title: name.slice(0, 300),
      kind,
      category: String(groupCategory || record.category_name || 'Other').slice(0, 80),
      status,
      startsAt,
      imageUrl: httpsOrNothing(record.poster),
      _iframe: iframe,
    };
  }

  // Timestamps: the match API uses milliseconds, the PPV API uses seconds.
  function parseTimestamp(value, unit) {
    const n = Number(value);
    if (!isFinite(n) || n <= 0) return null;
    if (unit === 'seconds') return n * 1000;
    if (unit === 'auto') return n < 1e12 ? n * 1000 : n;
    return n;
  }

  // ── catalogues (bounded cache) ─────────────────────────────────────────────

  async function matchRows(deadline) {
    const now = Date.now();
    if (cache.matches.rows && now - cache.matches.at < CATALOG_TTL_MS) return cache.matches.rows;
    const raw = await getJson(MATCH_API + '/matches', deadline);
    const list = Array.isArray(raw) ? raw : (Array.isArray(raw.matches) ? raw.matches : null);
    if (!list) throw new Error('Malformed match catalogue envelope');
    const rows = list.map(normalizeMatch).filter(Boolean);
    cache.matches = { at: now, rows };
    return rows;
  }

  async function ppvRows(deadline) {
    const now = Date.now();
    if (cache.ppv.rows && now - cache.ppv.at < CATALOG_TTL_MS) return cache.ppv.rows;
    const raw = await getJson(PPV_API, deadline);
    const groups = raw && Array.isArray(raw.streams) ? raw.streams : null;
    if (!groups) throw new Error('Malformed PPV catalogue envelope');
    const rows = [];
    for (const group of groups) {
      for (const record of (Array.isArray(group.streams) ? group.streams : [])) {
        const row = normalizePpvRecord(record, group.category);
        if (row) rows.push(row);
      }
    }
    cache.ppv = { at: now, rows };
    return rows;
  }

  function dedupe(items) {
    const seen = new Set();
    const out = [];
    for (const item of items) {
      if (!item || !item.id || seen.has(item.id)) continue;
      seen.add(item.id);
      out.push(item);
      if (out.length >= MAX_ITEMS) break;
    }
    return out;
  }

  function publicEntry(item) {
    const entry = { id: item.id, title: item.title, kind: item.kind, category: item.category, status: item.status };
    entry.canCheckStream = item.kind === 'event' && item.status === 'unknown' &&
      (!!item._iframe || (Array.isArray(item._sources) && item._sources.length > 0));
    if (item.startsAt) entry.startsAt = item.startsAt;
    if (item.imageUrl) entry.imageUrl = item.imageUrl;
    return entry;
  }

  // ── discovery ──────────────────────────────────────────────────────────────

  globalThis.liveHome = async function liveHome() {
    const deadline = deadlineFrom(CALL_BUDGET_MS);
    const [matches, ppv] = await Promise.all([
      matchRows(deadline).catch(() => []),
      ppvRows(deadline).catch(() => []),
    ]);
    const items = dedupe([...ppv, ...matches]);
    if (!items.length) throw new Error('No live catalogue available from either provider API');
    // A channel we just verified as off-air is reported honestly (unknown), never as live.
    const adjusted = items.map(it => (it.status === 'live' && isOffAirMarked(it.id))
      ? Object.assign({}, it, { status: 'unknown' }) : it);
    return { items: adjusted.map(publicEntry) };
  };

  globalThis.searchResults = async function searchResults(query) {
    const q = String(query || '').trim().toLowerCase();
    const deadline = deadlineFrom(CALL_BUDGET_MS);
    const rows = dedupe([...(await ppvRows(deadline).catch(() => [])), ...(await matchRows(deadline).catch(() => []))]);
    if (!q) return rows.slice(0, 120).map(card);
    return rows.filter(r => r.title.toLowerCase().includes(q) || r.category.toLowerCase().includes(q)).slice(0, 120).map(card);
  };

  function card(item) {
    return {
      id: item.id, href: item.id, title: item.title,
      image: item.imageUrl || '', posterUrl: item.imageUrl || '',
      description: item.kind === 'channel' ? (item.category + ' channel') : (item.category + ' event'),
      subAvailable: true, dubAvailable: false,
    };
  }

  function parseRef(id) {
    const s = String(id || '').trim();
    // Accept the opaque scheme id bare (`match:x` / `ppv:17270`) OR URL-wrapped —
    // the app resolves ids against the module baseUrl before some handlers
    // (e.g. `https://tvapp1.com/match:admin-tennis-channel`), so strip to the
    // last `match:`/`ppv:` segment before parsing.
    const m = s.match(/(?:^|\/)(match|ppv):(.+)$/i);
    if (!m) return null;
    return { family: m[1].toLowerCase(), key: m[2] };
  }

  async function findItem(ref, deadline) {
    const rows = ref.family === 'ppv' ? await ppvRows(deadline) : await matchRows(deadline);
    return rows.find(r => r.id === ref.family + ':' + ref.key) || null;
  }

  globalThis.extractDetails = async function extractDetails(urlOrId) {
    const ref = parseRef(urlOrId);
    if (!ref) throw new Error('Unknown TVApp live id');
    const deadline = deadlineFrom(6000);
    const item = await findItem(ref, deadline);
    if (!item) throw new Error('Live item not found in the current catalogue');
    return card(item);
  };

  globalThis.extractEpisodes = async function extractEpisodes(seriesId) {
    const ref = parseRef(seriesId);
    if (!ref) throw new Error('Unknown TVApp live id');
    return [{ id: seriesId, href: seriesId, seriesId, title: 'Live', number: 1, episodeNumber: 1, subAvailable: true, dubAvailable: false }];
  };

  // ── resolution ─────────────────────────────────────────────────────────────
  // Verified live (2026-09-16, real browser + CDP, no credentials, no bypass):
  //   descriptor -> embed page -> [intermediate frame] -> player page
  //   -> GET  strmd.b-cdn.net/js/wasm/lock.js + lock.wasm   (provider WASM decoder)
  //   -> POST https://embed.st/fetch   body = protobuf-ish [0x0a len source][0x12 len id][0x1a len streamNo]
  //   -> 200 application/octet-stream, 179 B, header `goat: <per-request key>`
  //   -> HLS on lb19.strmd.st/secure/<token>/rtmp/stream/<channel>/1/playlist.m3u8
  // The response is decoded locally using the per-request header; only reviewed
  // media hosts are accepted, then the HLS playlists are checked before handoff.

  const EMBED_HOSTS = ['embed.st', 'embedindia.st'];

  async function descriptorsFor(item, deadline) {
    if (item._iframe) {
      // PPV rows publish a ready player page. The request body's source field for this
      // family is unverified (the live capture covered the match family), so the slug is
      // used as the provider id and a rejection surfaces as a real HTTP error.
      const slug = (String(item._iframe).split('/embed/')[1] || '').replace(/\/+$/, '');
      return [{ embedUrl: item._iframe, source: 'ppv', familyTag: 'ppv', providerId: slug, streamNo: 1 }];
    }
    const out = [];
    for (const source of item._sources || []) {
      const url = MATCH_API + '/streams/' + encodeURIComponent(source.source) + '/' + encodeURIComponent(source.id);
      const raw = await getJson(url, deadline).catch(() => null);
      if (!Array.isArray(raw)) continue;
      for (const d of raw) {
        const embedUrl = httpsOrNothing(d && d.embedUrl);
        if (!embedUrl) continue;
        const host = embedUrl.replace(/^https:\/\//, '').split('/')[0];
        if (!EMBED_HOSTS.includes(host)) continue;   // reviewed destination allowlist
        out.push({ embedUrl, source: source.source, providerId: String(d.id || source.id || ''), streamNo: d.streamNo, language: d.language, hd: d.hd === true });
      }
    }
    return out;
  }

  function buildStreamRequest(descriptor) {
    // Match family ([0x0a source][0x12 id][0x1a streamNo]) and PPV family ([0x0a slug])
    // are both verified live; single-byte lengths cover every observed value.
    const parts = [];
    const push = (tag, value) => {
      const s = String(value);
      parts.push(String.fromCharCode(tag));
      parts.push(String.fromCharCode(s.length));
      parts.push(s);
    };
    if (descriptor.familyTag === 'ppv') {
      push(0x0a, descriptor.providerId);
    } else {
      push(0x0a, descriptor.source || 'admin');
      push(0x12, descriptor.providerId || '');
      push(0x1a, descriptor.streamNo || 1);
    }
    return parts.join('');
  }

  // ── off-air verification (non-blocking) ───────────────────────────────────
  // The provider keeps "24/7" channels badged live while they are off-air, where every media
  // playlist lists the SAME placeholder image instead of segments. The runtime has no timers
  // and the bridge ignores timeouts, so this check NEVER blocks a play: it is fired after the
  // stream has been returned, and its result only affects how the guide labels the item.
  const OFF_AIR_TTL_MS = 15 * 60 * 1000;   // matches the app's 15-minute off-air mark
  const OFF_AIR_REPROBE_MS = 3 * 60 * 1000;
  const offAirUntil = {};
  const lastProbeAt = {};
  // Placeholder shapes seen: sleepercdn `*.webp` stills (09-16) and TikTok-CDN `*.image`
  // byte-suffixed stills (09-21). Any image-suffixed segment stays a placeholder; shapes with
  // no telltale in the URL go through the byte sniff below.
  const PLACEHOLDER_SEGMENT_RE = /(^https?:\/\/[^\/]*(sleepercdn|tiktokcdn)[^\/]*\/)|(\.(webp|png|jpe?g|gif|avif|image)(\?|$))/i;

  const isOffAirMarked = (id) => (offAirUntil[id] || 0) > Date.now();
  const playlistLines = (text) => String(text || '').split('\n').map(l => l.trim()).filter(l => l && l.charAt(0) !== '#');

  function absoluteUrl(base, href) {
    if (/^https:\/\//i.test(href)) return href;
    if (/^\/\//.test(href)) return 'https:' + href;
    const m = String(base).match(/^(https:\/\/[^\/]+)(\/.*)?$/);
    if (!m) return href;
    if (/^\//.test(href)) return m[1] + href;
    return m[1] + (m[2] || '/').replace(/[^\/]*$/, '') + href;
  }

  async function fetchMediaText(url, referer, deadline) {
    const budget = deadline ? Math.min(4000, remaining(deadline)) : 4000;
    if (budget <= 250) throw new Error('Deadline exceeded before media check');
    const res = await fetchv2(url, { 'User-Agent': USER_AGENT, Accept: '*/*', Referer: referer }, 'GET', null,
      { timeoutMs: budget, maxBytesHint: 262144 });
    const status = Number(res && (res.status || res.statusCode));
    if (status !== 200) throw new Error('media HTTP ' + status);
    return typeof res.body === 'string' ? res.body : '';
  }

  async function checkPlaylist(stream, deadline) {
    const master = await fetchMediaText(stream.url, stream.headers.Referer, deadline);
    if (!/^\s*#EXTM3U(?:\s|$)/.test(master)) throw new Error('Provider returned no HLS playlist');
    const lines = playlistLines(master);
    const hasParts = text => /^#EXT-X-PART:.*\bURI="[^"\r\n]+"/m.test(text);
    if (!lines.length && !hasParts(master)) throw new Error('Provider returned an empty HLS playlist');
    if (master.indexOf('#EXT-X-STREAM-INF:') >= 0) {
      const variant = await fetchMediaText(absoluteUrl(stream.url, lines[0]), stream.headers.Referer, deadline);
      if (!/^\s*#EXTM3U(?:\s|$)/.test(variant) || (!playlistLines(variant).length && !hasParts(variant))) {
        throw new Error('Provider returned no media playlist');
      }
    }
    // A playlist is not playback proof. The native player still validates media bytes.
  }

  // Container magics are ASCII-visible even through the bridge's lossy utf8 decode
  // (`RIFF`/`WEBP`, `PNG`, `GIF8`, `JFIF/Exif`, `ftypavif`); a real segment matches none.
  function looksLikePlaceholderBytes(text) {
    const head = String(text || '').slice(0, 48);
    if (!head) return false;
    if (head.indexOf('RIFF') === 0 && /WEBP|AVI|WAVE/.test(head.slice(8, 16))) return true;
    if (head.indexOf('GIF8') === 0) return true;
    const png = head.indexOf('PNG');
    if (png >= 0 && png <= 4) return true;
    if (/JFIF|Exif/.test(head.slice(0, 16))) return true;
    if (head.indexOf('ftypavif') >= 0 || head.indexOf('ftypmif1') >= 0) return true;
    return false;
  }

  function scheduleOffAirProbe(fresh, itemId) {
    const now = Date.now();
    if (now - (lastProbeAt[itemId] || 0) < OFF_AIR_REPROBE_MS) return;
    lastProbeAt[itemId] = now;
    (async () => {
      const master = await fetchMediaText(fresh.url, fresh.headers.Referer);
      if (!/^#EXTM3U/.test(master)) return;
      let variantUrl = fresh.url;
      let variant = master;
      if (/#EXT-X-STREAM-INF:/.test(master)) {
        const variants = playlistLines(master);
        if (!variants.length) return;
        variantUrl = absoluteUrl(fresh.url, variants[0]);
        variant = await fetchMediaText(variantUrl, fresh.headers.Referer);
      }
      const segs = playlistLines(variant);
      if (!segs.length) return;
      if (PLACEHOLDER_SEGMENT_RE.test(segs[0])) { offAirUntil[itemId] = Date.now() + OFF_AIR_TTL_MS; return; }
      // No telltale in the URL: sniff the first segment's bytes before calling it live.
      try {
        const segUrl = absoluteUrl(variantUrl, segs[0]);
        const res = await fetchv2(segUrl, {
          'User-Agent': USER_AGENT, Accept: '*/*', Referer: fresh.headers.Referer, Range: 'bytes=0-16383',
        }, 'GET', null, { timeoutMs: 4000, maxBytesHint: 32768 });
        if (Number(res && (res.status || res.statusCode)) !== 200 &&
            Number(res && (res.status || res.statusCode)) !== 206) return;
        const head = (res && typeof res.body === 'string') ? res.body : '';
        if (head && looksLikePlaceholderBytes(head)) { offAirUntil[itemId] = Date.now() + OFF_AIR_TTL_MS; return; }
        // The text bridge is lossy for binary media: unknown bytes are not evidence
        // that the channel is back on air. Let the off-air mark expire naturally.
      } catch (_) { /* Keep the previous off-air mark when evidence is unavailable. */ }
    })().catch(() => {});
  }

  function headerOf(res, name) {
    const h = (res && res.headers) || {};
    for (const k of Object.keys(h)) if (k.toLowerCase() === name) return String(h[k] || '');
    return '';
  }

  async function resolveViaFetch(descriptor, deadline) {
    const host = String(descriptor.embedUrl).replace(/^https:\/\//, '').split('/')[0];
    const body = buildStreamRequest(descriptor);
    if (!descriptor.providerId) throw new Error('Stream descriptor carries no provider id');
    const budget = remaining(deadline);
    if (budget <= 500) throw new Error('Deadline exceeded before resolution request');
    const res = await fetchv2('https://' + host + '/fetch', {
      'User-Agent': USER_AGENT,
      'Content-Type': 'application/octet-stream',
      Origin: 'https://' + host,
      Referer: descriptor.embedUrl,
    }, 'POST', body, { timeoutMs: Math.min(budget, 8000), maxBytesHint: 65536 });
    const status = Number(res && (res.status || res.statusCode));
    if (status !== 200) throw new Error('Resolution request rejected with HTTP ' + status);
    const raw = typeof res.body === 'string' ? res.body : '';
    // Per-request decoder key header: `goat` (embed.st family) / `island` (embedindia.st family).
    const key = headerOf(res, host === 'embedindia.st' ? 'island' : 'goat') || headerOf(res, 'goat') || headerOf(res, 'island');
    if (!key) throw new Error('Resolution response carried no decoder key header');
    // Framing: [0x0a][varint payload length][payload]. The varint byte sits above ASCII
    // and is the one character the bridge cannot preserve, so the payload is located by
    // scanning to the first character of the payload alphabet instead of by offset.
    let start = 0;
    while (start < raw.length && !inPayloadAlphabet(raw.charAt(start))) start++;
    let end = start;
    while (end < raw.length && inPayloadAlphabet(raw.charAt(end))) end++;
    const payload = raw.slice(start, end);
    if (!payload.length) throw new Error('Resolution response had an empty payload');
    lastDecodeReject = '';
    const url = decodeResolutionPayload(payload, key);
    if (!url) {
      throw new Error('tvapp1 provider decode failed (stage: payload-decode, payloadChars=' + payload.length + ', keyHeader=present' + (lastDecodeReject ? ', reason=' + lastDecodeReject : '') + ')');
    }
    // The media CDN requires the embed origin as Referer (verified: with it 200, without it 403).
    // The app reads `streamType` (plus aliases) when deciding player routing; `type` is kept
    // for the shipped reference modules' shape.
    return { url, type: 'hls', streamType: 'hls', isLive: true, subtitles: [], headers: { Referer: 'https://' + host + '/' } };
  }

  // ── provider payload decoder (recovered 2026-09-16; pure JS, no typed arrays) ──
  // payload -> unshift(-23) -> standard-base64 decode -> ct:
  //   ct[0:12] = nonce, ct[12:len-16] = ChaCha20 ciphertext, ct[len-16:] = Poly1305 tag
  // key = the per-request `goat`/`island` header itself (32 raw ASCII bytes),
  // keystream = IETF ChaCha20 counter 1 (counter 0 is the AEAD MAC key).
  // Plaintext = the HLS URL. Verified against 220+ live captures.

  const STD_B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  const B64_MAP = (() => { const m = {}; for (let i = 0; i < STD_B64.length; i++) m[STD_B64.charAt(i)] = i; return m; })();
  const SHIFT = 23, PRINT_LO = 33, PRINT_RANGE = 94;
  const shiftCode = (c, delta) => ((c - PRINT_LO + delta) % PRINT_RANGE + PRINT_RANGE) % PRINT_RANGE + PRINT_LO;
  const SHIFTED_B64 = (() => { let o = ''; for (let i = 0; i < STD_B64.length; i++) o += String.fromCharCode(shiftCode(STD_B64.charCodeAt(i), SHIFT)); return o; })();
  const PAD_SENTINEL = String.fromCharCode(shiftCode(61, SHIFT)); // shifted '='

  function inPayloadAlphabet(ch) { return SHIFTED_B64.indexOf(ch) >= 0 || ch === PAD_SENTINEL; }

  function payloadToCiphertext(payload) {
    let body = payload;
    while (body.length && body.charAt(body.length - 1) === PAD_SENTINEL) body = body.slice(0, -1);
    let b64 = '';
    for (let i = 0; i < body.length; i++) {
      const c = body.charCodeAt(i);
      if (!inPayloadAlphabet(body.charAt(i))) throw new Error('E_CHAR:' + c);
      b64 += String.fromCharCode(shiftCode(c, -SHIFT));
    }
    const out = []; let acc = 0, bits = 0;
    for (let i = 0; i < b64.length; i++) {
      const ch = b64.charAt(i);
      if (ch === '=') continue;                      // padding never carries bits
      const v = B64_MAP[ch];
      if (v === undefined) throw new Error('E_B64:' + b64.charCodeAt(i));
      acc = (acc << 6) | v; bits += 6;
      if (bits >= 8) { bits -= 8; out.push((acc >>> bits) & 255); }
    }
    return out;
  }

  const U32 = 0xffffffff >>> 0;
  function rotl(v, c) { return ((v << c) | (v >>> (32 - c))) >>> 0; }
  function chachaBlock(key, nonce, counter) {
    const x = new Array(16);
    x[0] = 0x61707865; x[1] = 0x3320646e; x[2] = 0x79622d32; x[3] = 0x6b206574;
    for (let i = 0; i < 8; i++) x[4 + i] = (key[4 * i] | (key[4 * i + 1] << 8) | (key[4 * i + 2] << 16) | (key[4 * i + 3] << 24)) >>> 0;
    x[12] = counter >>> 0;
    x[13] = (nonce[0] | (nonce[1] << 8) | (nonce[2] << 16) | (nonce[3] << 24)) >>> 0;
    x[14] = (nonce[4] | (nonce[5] << 8) | (nonce[6] << 16) | (nonce[7] << 24)) >>> 0;
    x[15] = (nonce[8] | (nonce[9] << 8) | (nonce[10] << 16) | (nonce[11] << 24)) >>> 0;
    const w = x.slice();
    const qr = (a, b, c, d) => {
      w[a] = (w[a] + w[b]) >>> 0; w[d] = rotl(w[d] ^ w[a], 16);
      w[c] = (w[c] + w[d]) >>> 0; w[b] = rotl(w[b] ^ w[c], 12);
      w[a] = (w[a] + w[b]) >>> 0; w[d] = rotl(w[d] ^ w[a], 8);
      w[c] = (w[c] + w[d]) >>> 0; w[b] = rotl(w[b] ^ w[c], 7);
    };
    for (let i = 0; i < 10; i++) {
      qr(0, 4, 8, 12); qr(1, 5, 9, 13); qr(2, 6, 10, 14); qr(3, 7, 11, 15);
      qr(0, 5, 10, 15); qr(1, 6, 11, 12); qr(2, 7, 8, 13); qr(3, 4, 9, 14);
    }
    const out = new Array(64);
    for (let i = 0; i < 16; i++) {
      const v = (w[i] + x[i]) >>> 0;
      out[4 * i] = v & 255; out[4 * i + 1] = (v >>> 8) & 255; out[4 * i + 2] = (v >>> 16) & 255; out[4 * i + 3] = (v >>> 24) & 255;
    }
    return out;
  }
  function chachaXor(key, nonce, data, startCounter) {
    const out = new Array(data.length);
    for (let off = 0; off < data.length; off += 64) {
      const ks = chachaBlock(key, nonce, startCounter + (off / 64));
      for (let i = 0; i < 64 && off + i < data.length; i++) out[off + i] = data[off + i] ^ ks[i];
    }
    return out;
  }

  function asciiToBytes(s) { const b = new Array(s.length); for (let i = 0; i < s.length; i++) b[i] = s.charCodeAt(i) & 255; return b; }
  function bytesToLatin1(b) { let s = ''; for (let i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return s; }

  // Reviewed media-host allowlist for decoded destinations.
  // Reviewed media-host allowlist. Observed hosts: strmd.st + indianservers.st (both families)
  // and akamaized.net (Akamai FAST-channel feeds, e.g. Rally TV). The allowlist is the
  // safety net against a garbage decode, so only reviewed hosts are added.
  const MEDIA_HOST_RE = /^https:\/\/[a-z0-9-]+(\.[a-z0-9-]+)*\.(strmd\.st|indianservers\.st|akamaized\.net)\//i;
  let lastDecodeReject = '';

  function decodeResolutionPayload(payload, key) {
    try {
      if (typeof payload !== 'string' || typeof key !== 'string' || key.length !== 32) return null;
      const ct = payloadToCiphertext(payload);
      if (ct.length <= 12 + 16) return null;
      const nonce = ct.slice(0, 12);
      const body = ct.slice(12, ct.length - 16);
      const text = bytesToLatin1(chachaXor(asciiToBytes(key), nonce, body, 1));
      const m = text.match(/^https:\/\/[^\s"'\\\u0000-\u001f]+/);
      if (!m) { lastDecodeReject = 'url-not-parsed'; return null; }
      if (!MEDIA_HOST_RE.test(m[0])) {
        lastDecodeReject = 'host-not-allowlisted:' + (m[0].split('/')[2] || '?');
        return null;
      }
      return m[0];
    } catch (e) {
      return null;
    }
  }

  globalThis.extractStreamUrl = async function extractStreamUrl(itemId, lang) {
    if (lang === 'dub') throw new Error('Live events are single-language; no dub mode');
    const ref = parseRef(itemId);
    if (!ref) throw new Error('Unknown TVApp live id');
    const deadline = deadlineFrom(CALL_BUDGET_MS);
    const item = await findItem(ref, deadline);
    if (!item) throw new Error('Live item not found in the current catalogue; refresh the guide');
    const descriptors = await descriptorsFor(item, deadline);
    if (!descriptors.length) throw new Error('No stream descriptor is currently available for this item');
    const ordered = descriptors.filter(d => d.hd).concat(descriptors.filter(d => !d.hd));
    const seen = new Set();
    let attempted = 0;
    for (const descriptor of ordered) {
      const key = [descriptor.embedUrl, descriptor.source, descriptor.providerId, descriptor.streamNo].join('|');
      if (seen.has(key)) continue;
      if (attempted >= 3 || remaining(deadline) <= 500) break;
      seen.add(key);
      attempted++;
      // Stop scheduling further work after this budget. An in-flight request is
      // bounded by the native bridge, not by the module's advisory timeout hint.
      const candidateDeadline = Math.min(deadline, Date.now() + 6000);
      try {
        const stream = await resolveViaFetch(descriptor, candidateDeadline);
        await checkPlaylist(stream, candidateDeadline);
        scheduleOffAirProbe(stream, item.id); // reuse this ticket, never resolve twice
        return stream;
      } catch (_) { /* Try another provider-listed route within the original deadline. */ }
    }
    throw new Error('No working live playlist from ' + attempted + ' checked route(s). The provider may be off air or blocking access; try again later.');
  };
})();
