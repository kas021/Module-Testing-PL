(() => {
  'use strict';
  const PAGE = 'https://www.dw.com/en/live-tv/channel-english';
  const ID = 'en/live-tv/channel-english';
  const TITLE = 'DW English';
  const LOGO = 'https://www.dw.com/images/icons/favicon-180x180.png';
  function requireChannel(id) {
    if (String(id).replace(/^https:\/\/www\.dw\.com\//, '').replace(/^\//, '') !== ID) {
      throw new Error('Unknown live channel');
    }
  }
  async function text(url) {
    const r = await fetchv2(url, {}, 'GET', null, {timeoutMs: 6000});
    const status = Number(r.status || r.statusCode);
    if (status !== 200) throw new Error('Live source HTTP ' + status);
    const body = typeof r.body === 'string' ? r.body : typeof r.text === 'function' ? await r.text() : '';
    if (!body || body.length > 1048576) throw new Error('Invalid live response');
    return body;
  }
  function mediaUrl(value) {
    // Only the public broadcaster's observed CDN, never an arbitrary page URL.
    if (!/^https:\/\/dwamdstream\d+\.akamaized\.net\/hls\/live\/[a-zA-Z0-9_./-]+\.m3u8$/.test(value)) {
      throw new Error('Unrecognized broadcaster stream');
    }
    return value;
  }
  async function liveHome() {
    return {items: [{id: ID, title: TITLE, category: 'News', kind: 'channel',
      imageUrl: LOGO, status: 'unknown'}]};
  }
  function card() { return {id: ID, url: PAGE, title: TITLE, posterUrl: LOGO,
    description: 'English-language news channel', subAvailable: true, dubAvailable: false}; }
  async function searchResults(query) {
    const q = String(query || '').toLowerCase().trim();
    return !q || (TITLE + ' news live').toLowerCase().includes(q) ? [card()] : [];
  }
  async function extractDetails(id) {requireChannel(id); return card();}
  async function extractEpisodes(id) {
    requireChannel(id);
    return [{id: ID, href: ID, seriesId: ID, title: TITLE,
      number: 1, episodeNumber: 1, subAvailable: true, dubAvailable: false}];
  }
  async function extractStreamUrl(id, lang) {
    requireChannel(id);
    if (lang === 'dub') throw new Error('This channel does not expose a dub mode');
    // Resolve the broadcaster's current source on every play and retry.
    const html = await text(PAGE);
    const match = html.match(/"hlsVideoSrc"\s*:\s*("(?:[^"\\]|\\.)*")/);
    if (!match) throw new Error('No public HLS source returned');
    const url = mediaUrl(JSON.parse(match[1]));
    const master = await text(url);
    if (!master.trimStart().startsWith('#EXTM3U')) throw new Error('Invalid HLS manifest');
    const rows = master.split(/\r?\n/);
    const variants = [];
    for (let i = 0; i < rows.length - 1; i++) {
      if (!rows[i].startsWith('#EXT-X-STREAM-INF:') || !/avc1|hvc1|hev1/.test(rows[i])) continue;
      const height = Number((rows[i].match(/RESOLUTION=\d+x(\d+)/) || [])[1]);
      const candidate = mediaUrl(rows[i + 1].trim());
      if (!variants.some(v => v.height === height)) variants.push({url: candidate, height});
    }
    if (!variants.length) throw new Error('No video renditions returned');
    const playlist = await text(variants[0].url);
    if (!playlist.trimStart().startsWith('#EXTM3U') || !playlist.includes('#EXTINF:') ||
        playlist.includes('#EXT-X-ENDLIST') || /\.(?:jpg|jpeg|png|webp)(?:[?\s]|$)/i.test(playlist)) {
      throw new Error('Source is not an active live video playlist');
    }
    // Retain the master so the player gets adaptive quality and native HLS captions.
    return {url, type: 'hls', isLive: true, subtitles: [], headers: {}};
  }
  Object.assign(globalThis, {liveHome, searchResults, extractDetails, extractEpisodes, extractStreamUrl});
})();
