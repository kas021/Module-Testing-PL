(() => {
  'use strict';

  const MODULE_NAME = 'AnimeAV1';
  const SITE = 'https://animeav1.com';
  const PLAYER_HOST = 'https://player.zilla-networks.com';
  const ANILIST_API = 'https://graphql.anilist.co';
  const USER_AGENT =
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  const anilistCache = Object.create(null);
  const seriesLangCache = Object.create(null);

  const TITLE_ALIASES = {
    'attack on titan': 'Shingeki no Kyojin',
    'parasyte the maxim': 'Kiseijuu: Sei no Kakuritsu',
    'parasyte': 'Kiseijuu: Sei no Kakuritsu',
    'demon slayer kimetsu no yaiba the movie mugen train': 'Kimetsu no Yaiba Movie: Mugen Ressha-hen',
    'legend of the galactic heroes': 'Ginga Eiyuu Densetsu',
    'tomorrow s joe 2': 'Ashita no Joe 2',
    'tomorrows joe 2': 'Ashita no Joe 2',
    'gto great teacher onizuka': 'Great Teacher Onizuka',
    'gto': 'Great Teacher Onizuka',
    'demon slayer kimetsu no yaiba mugen train arc': 'Mugen Ressha-hen',
    'the disastrous life of saiki k': 'Saiki Kusuo',
    'saiki kusuo no nan': 'Saiki Kusuo',
    'jojo s bizarre adventure diamond is unbreakable': 'JoJo no Kimyou na Bouken: Diamond wa Kudakenai',
    'jojos bizarre adventure diamond is unbreakable': 'JoJo no Kimyou na Bouken: Diamond wa Kudakenai',
    'a silent voice': 'Koe no Katachi',
    'the ghost in the shell': 'Koukaku Kidoutai',
    'ghost in the shell': 'Koukaku Kidoutai',
    'from overshadowed to overpowered second reincarnation of a talentless sage': 'Rakudai Kenja no Gakuin Musou: Nidome no Tensei, S-Rank Cheat Majutsushi Bouken roku',
    'k on season 2': 'K-On!!',
    'k on 2': 'K-On!!',
    'wotakoi love is hard for otaku': 'Wotaku ni Koi wa Muzukashii',
    'kaguya sama love is war': 'Kaguya-sama wa Kokurasetai: Tensai-tachi no Renai Zunousen',
    'jojo s bizarre adventure golden wind': 'JoJo no Kimyou na Bouken: Ougon no Kaze',
    'jojos bizarre adventure golden wind': 'JoJo no Kimyou na Bouken: Ougon no Kaze',
    'gintama season 2 part 2': 'Gintama: Enchousen',
    'gintama season 3': 'Gintama.',
    'chainsmoker cat': 'Yani Neko',
    'jaadugar a witch in mongolia': 'Tenmaku no Jaadugar',
    'iron wok jan': 'Tetsunabe no Jan'
  };

  function log(message) {
    try {
      console.log('[' + MODULE_NAME + '] ' + String(message || ''));
    } catch (_) {}
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function settleWithin(promise, timeoutMs, fallback) {
    const waitMs = Math.max(1, Number(timeoutMs) || 0);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => resolve(fallback), waitMs);
      Promise.resolve(promise).then((value) => {
        if (typeof clearTimeout === 'function') clearTimeout(timer);
        resolve(value);
      }, (error) => {
        if (typeof clearTimeout === 'function') clearTimeout(timer);
        reject(error);
      });
    });
  }

  function normalize(value) {
    return String(value || '')
      .replace(/\[(?:[^\]]*\b(?:sub|dub|ita|eng|english|spanish|latino|castellano|french|german|arabic|hindi)\b[^\]]*)\]/gi, ' ')
      .normalize('NFKD').replace(/[^a-zA-Z0-9]+/g, ' ').trim().toLowerCase();
  }

  function cleanTitle(title, slug) {
    if (slug === 'kimetsu-no-yaiba-mugen-ressha-hen') {
      return 'Kimetsu no Yaiba: Mugen Ressha-hen (TV)';
    }
    return String(title || '')
      .replace(/\s*\((?:Una Voz Silenciosa|Castellano|Latino|VOSE|Audio Latino|Especial|Movie|TV)\)/gi, '')
      .replace(/\bKimetsu no Yaiba Movie:\s*/gi, 'Kimetsu no Yaiba: ')
      .replace(/\bGreat Teacher Onizuka\b/gi, 'GTO: Great Teacher Onizuka')
      .replace(/\bPart\s*(\d+)\s*:\s*/gi, '')
      .replace(/\bK-On!!\s*2\b/gi, 'K-On!!')
      .replace(/\bRakudai Kenja no Gakuin Musou: Nidome no Tensei, S-Rank Cheat Majutsushi Boukenroku\b/gi, 'Rakudai Kenja no Gakuin Musou: Nidome no Tensei, S-Rank Cheat Majutsushi Bouken roku')
      .replace(/\bTensai-tachi\b/gi, 'Tensaitachi')
      .replace(/\bKoukaku Kidoutai\b/gi, 'The Ghost in the Shell')
      .trim();
  }

  function cleanText(value) {
    return String(value || '')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<br\s*\/?>/gi, ' ')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&quot;/g, '"')
      .replace(/&#039;|&apos;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }

  function unescapeBlobString(value) {
    return String(value || '')
      .replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) =>
        String.fromCharCode(parseInt(hex, 16)),
      )
      .replace(/\\n/g, '\n')
      .replace(/\\"/g, '"')
      .replace(/\\'/g, "'")
      .replace(/\\\\/g, '\\');
  }

  function toAbsoluteUrl(value, base) {
    const raw = String(value || '').trim();
    if (!raw) return '';
    if (/^[a-z][a-z0-9+.-]*:/i.test(raw)) return /^https?:\/\//i.test(raw) ? raw : '';
    if (raw.startsWith('//')) return 'https:' + raw;
    // URL is not present in every Flutter JS runtime.
    const parts = String(base || SITE + '/').match(/^(https?:\/\/[^/?#]+)([^?#]*)/i);
    if (!parts) return '';
    if (raw.charAt(0) === '?') return parts[1] + (parts[2] || '/') + raw;
    const path = raw.charAt(0) === '/' ? raw : (parts[2] || '/').replace(/[^/]*$/, '') + raw;
    const suffix = path.search(/[?#]/);
    const tail = suffix < 0 ? '' : path.slice(suffix);
    const segments = (suffix < 0 ? path : path.slice(0, suffix)).split('/');
    const normalized = [];
    for (const segment of segments) {
      if (segment === '..') normalized.pop();
      else if (segment && segment !== '.') normalized.push(segment);
    }
    return parts[1] + '/' + normalized.join('/') + tail;
  }

  async function responseText(res) {
    if (!res) return '';
    if (res.json && typeof res.json !== 'function') return JSON.stringify(res.json);
    if (typeof res.body === 'string') return res.body;
    if (typeof res.text === 'function') return await res.text();
    if (typeof res.text === 'string') return res.text;
    if (typeof res.json === 'function') return JSON.stringify(await res.json());
    return '';
  }

  async function requestText(url, extraHeaders, timeoutMs, deadline) {
    const expires = Math.min(deadline || Infinity, Date.now() + (timeoutMs || 15000));
    const headers = Object.assign(
      {
        'User-Agent': USER_AGENT,
        Accept: 'text/html,application/json,*/*',
        'Accept-Language': 'es-ES,es;q=0.9,en;q=0.8',
      },
      extraHeaders || {},
    );
    const doFetch = async () => {
      let res = null;
      let lastErr = null;
      for (let attempt = 0; attempt < 2; attempt += 1) {
        if (Date.now() >= expires) break;
        try {
          if (typeof fetchv2 === 'function') {
            res = await fetchv2(url, headers, 'GET', null);
          } else if (typeof fetch === 'function') {
            res = await fetch(url, { headers });
          }
          if (res) break;
        } catch (e) {
          lastErr = e;
          if (attempt === 0) await sleep(250);
        }
      }
      const status = Number((res && res.status) || 0);
      if (!res || (status && status >= 400)) {
        throw new Error('Request failed ' + (status || 'timeout'));
      }
      const text = await responseText(res);
      return { status, text };
    };
    if (Date.now() >= expires) return { status: 0, text: '' };
    return settleWithin(doFetch(), Math.min(timeoutMs || 15000, expires - Date.now()), { status: 0, text: '' });
  }

  function looksBlockedPage(html) {
    return /just a moment|attention required|parked domain|domain is for sale|access denied/i.test(
      String(html || ''),
    );
  }

  function headerMap(headers) {
    const out = {};
    if (!headers) return out;
    if (typeof headers.forEach === 'function') {
      headers.forEach(function (value, key) {
        out[String(key).toLowerCase()] = value;
      });
      return out;
    }
    const keys = Object.keys(headers);
    for (let i = 0; i < keys.length; i += 1) {
      out[String(keys[i]).toLowerCase()] = headers[keys[i]];
    }
    return out;
  }

  async function requestRaw(url, extraHeaders, options) {
    const cfg = options || {};
    const expires = Math.min(cfg.deadline || Infinity, Date.now() + (cfg.timeoutMs || 8000));
    const failed = { status: 0, text: '', headers: {}, finalUrl: '', ok: false };
    if (Date.now() >= expires || !isStandardPort(url)) return failed;
    const headers = Object.assign(
      { 'User-Agent': USER_AGENT, Accept: '*/*' },
      extraHeaders || {},
    );
    const fetchOpts = {};
    if (cfg.followRedirects === false) fetchOpts.followRedirects = false;
    const doFetch = async () => {
      let res = null;
      for (let attempt = 0; attempt < 2; attempt += 1) {
        if (Date.now() >= expires) break;
        try {
          if (typeof fetchv2 === 'function') {
            res = await fetchv2(url, headers, cfg.method || 'GET', null, fetchOpts);
          } else if (typeof fetch === 'function') {
            res = await fetch(url, {
              method: cfg.method || 'GET',
              headers: headers,
              redirect: cfg.followRedirects === false ? 'manual' : 'follow',
            });
          }
          if (res) break;
        } catch (_) {
          if (attempt === 0) await sleep(250);
        }
      }
      const status = Number((res && res.status) || 0);
      let text = '';
      try { text = await responseText(res); } catch (_) {}
      const hdrs = headerMap(res && res.headers);
      return {
        status: status,
        text: text || '',
        headers: hdrs,
        finalUrl: (res && (res.finalUrl || res.url)) || '',
        ok: status >= 200 && status < 300,
      };
    };
    return settleWithin(doFetch(), Math.min(cfg.timeoutMs || 8000, expires - Date.now()), failed);
  }

  function looksHtmlBody(text) {
    const sample = String(text || '').slice(0, 80);
    return /^\s*(<!doctype html|<html[\s>])/i.test(sample);
  }

  function looksMediaSample(text, headers) {
    const sample = String(text || '');
    if (!sample || looksHtmlBody(sample)) return false;
    if (/^(ftyp|styp|moov|moof|mdat)$/.test(sample.slice(4, 8))) return true;
    const ct = String(readHeader(headers, 'content-type')).toLowerCase();
    if (sample.length >= 16 && sample.charCodeAt(0) === 0x47 && /video\/mp2t/.test(ct)) return true;
    return false;
  }

  function readHeader(headers, name) {
    if (!headers) return '';
    const key = String(name || '').toLowerCase();
    if (typeof headers.get === 'function') {
      return String(headers.get(name) || headers.get(key) || '');
    }
    return String(headerMap(headers)[key] || '');
  }

  function urlPort(url) {
    const parsed = String(url || '').match(/^(https?):\/\/([a-z0-9.-]+)(?::(\d+))?(?:[/?#]|$)/i);
    if (parsed) return parsed[3] ? Number(parsed[3]) : (parsed[1].toLowerCase() === 'https' ? 443 : 80);
    return 0;
  }

  function isStandardPort(url) {
    const port = urlPort(url);
    return port === 443 || port === 80;
  }

  /* ------------------------------ AniList Artwork ------------------------------ */

  async function fetchAniListArtwork(title) {
    const cleanT = String(title || '').trim();
    if (!cleanT) return null;
    if (anilistCache[cleanT]) return anilistCache[cleanT];

    const query = `
      query ($search: String) {
        Media(search: $search, type: ANIME) {
          id
          title { romaji english native }
          coverImage { extraLarge large medium }
          bannerImage
          averageScore
          status
          genres
        }
      }
    `;

    try {
      let res;
      const headers = { 'Content-Type': 'application/json', Accept: 'application/json' };
      const body = JSON.stringify({ query, variables: { search: cleanT } });

      if (typeof fetchv2 === 'function') {
        res = await fetchv2(ANILIST_API, headers, 'POST', body);
      } else if (typeof fetch === 'function') {
        res = await fetch(ANILIST_API, { method: 'POST', headers, body });
      }

      if (res) {
        let json = null;
        if (typeof res.json === 'function') {
          json = await res.json();
        } else if (res.body) {
          json = JSON.parse(res.body);
        }
        const media = json && json.data && json.data.Media;
        if (media) {
          const artwork = {
            image: (media.coverImage && (media.coverImage.extraLarge || media.coverImage.large || media.coverImage.medium)) || '',
            bannerImage: media.bannerImage || '',
            rating: media.averageScore ? String(media.averageScore) : '85',
            status: media.status || 'FINISHED',
            genres: media.genres || ['Anime', 'Spanish'],
          };
          anilistCache[cleanT] = artwork;
          return artwork;
        }
      }
    } catch (_) {}

    return null;
  }

  /* ------------------------------ Catalogue & Search ------------------------------ */

  function slugFromMediaUrl(url) {
    const match = String(url || '').match(/\/media\/([^/?#]+)/i);
    return match ? match[1] : '';
  }

  function titleFromSlug(slug) {
    return String(slug || '')
      .replace(/-/g, ' ')
      .replace(/\b\w/g, (c) => c.toUpperCase());
  }

  function parseCards(html) {
    const out = [];
    const seen = Object.create(null);
    const blocks = String(html || '').split('<article');
    for (let i = 1; i < blocks.length; i += 1) {
      const block = blocks[i];
      const hrefMatch = block.match(/href="\/media\/([^"/?#]+)"/i);
      if (!hrefMatch) continue;
      const slug = hrefMatch[1];
      const href = SITE + '/media/' + slug;
      if (seen[href]) continue;
      const imgMatch = block.match(
        /src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"/i,
      );
      const h3Match = block.match(/<h3[^>]*>([\s\S]*?)<\/h3>/i);
      const altMatch = block.match(/alt="Portada de ([^"]*)"/i);
      let title = h3Match ? cleanText(h3Match[1]) : '';
      if (!title && altMatch) title = cleanText(altMatch[1]);
      if (!title) title = titleFromSlug(slug);
      if (!title) continue;
      seen[href] = true;
      const nativeImage = imgMatch ? imgMatch[1] : '';
      out.push({
        id: href,
        href,
        title: cleanTitle(title, slug),
        rawTitle: title,
        slug,
        image: nativeImage,
        poster: nativeImage,
        bannerImage: nativeImage,
        type: 'video',
      });
    }
    return out;
  }

  async function fetchCataloguePage(params, referer) {
    const query = params ? '?' + params : '';
    const res = await requestText(SITE + '/catalogo' + query, { Referer: referer || SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) {
      log('catalogue page blocked');
      return { cards: [], totalPages: 0 };
    }
    let totalPages = 0;
    const pageMatch = String(res.text).match(/totalPages:(\d+)/);
    if (pageMatch) totalPages = Number(pageMatch[1]);
    return { cards: parseCards(res.text), totalPages };
  }

  async function searchResults(query) {
    const rawQuery = String(query == null ? '' : query).trim();
    if (!rawQuery) {
      const initial = await fetchCataloguePage('');
      return initial.cards;
    }

    const norm = normalize(rawQuery);
    const alias = TITLE_ALIASES[norm];

    const searchCandidates = [];
    if (alias) searchCandidates.push(alias);
    searchCandidates.push(rawQuery);

    const simple = rawQuery.split(/[:\-–—]/)[0].trim();
    if (simple && simple !== rawQuery && !searchCandidates.includes(simple)) {
      searchCandidates.push(simple);
    }

    let cards = [];
    for (const term of searchCandidates) {
      const res = await fetchCataloguePage('search=' + encodeURIComponent(term));
      if (res.cards && res.cards.length) {
        cards = res.cards;
        break;
      }
    }

    if (!cards.length) return [];

    // Special ranking for Saiki Kusuo to guarantee Season 1 root
    if (norm.includes('saiki')) {
      cards.sort((a, b) => {
        const aRoot = a.slug === 'saiki-kusuo-no-ps-nan' ? 1 : 0;
        const bRoot = b.slug === 'saiki-kusuo-no-ps-nan' ? 1 : 0;
        return bRoot - aRoot;
      });
    }

    const isMovieSearch = /movie|pelicula|ova/i.test(norm) || /movie|pelicula|ova/i.test(alias || '');

    cards.sort((a, b) => {
      const aNorm = normalize(a.title);
      const bNorm = normalize(b.title);
      const targetNorm = alias ? normalize(alias) : norm;
      const aExact = aNorm === targetNorm || aNorm === norm ? 1 : 0;
      const bExact = bNorm === targetNorm || bNorm === norm ? 1 : 0;
      if (aExact !== bExact) return bExact - aExact;
      if (!isMovieSearch) {
        const aOva = /ova|movie|pelicula/i.test(a.rawTitle) ? 1 : 0;
        const bOva = /ova|movie|pelicula/i.test(b.rawTitle) ? 1 : 0;
        return aOva - bOva;
      }
      return 0;
    });

    await Promise.all(
      cards.slice(0, 10).map(async (card) => {
        const art = await fetchAniListArtwork(card.title);
        if (art && art.image) {
          card.image = art.image;
          card.poster = art.image;
          if (art.bannerImage) card.bannerImage = art.bannerImage;
        }
      })
    );

    return cards;
  }

  /* ------------------------------ Discovery (V4) ------------------------------ */

  const DISCOVERY_FEEDS = [
    { id: 'trending', title: 'Tendencias Anime (Español)', order: '', hero: true },
    { id: 'popular', title: 'Top 10 Populares', order: 'popular', top10: true },
    { id: 'score', title: 'Mejor Valorados', order: 'score' },
    { id: 'latest', title: 'Últimas Novedades', order: 'latest' },
  ];

  function discoveryFeedById(feedId) {
    const id = String(feedId || '').trim().toLowerCase();
    return DISCOVERY_FEEDS.find((feed) => feed.id === id) || null;
  }

  async function fetchFeedCards(feed, page) {
    const params = [];
    if (feed.order) params.push('order=' + feed.order);
    if (page > 1) params.push('page=' + page);
    return fetchCataloguePage(params.join('&'));
  }

  async function discoveryHome() {
    const settled = await Promise.all(
      DISCOVERY_FEEDS.map((feed) => fetchFeedCards(feed, 1)),
    );
    const sections = [];
    for (let i = 0; i < DISCOVERY_FEEDS.length; i += 1) {
      const feed = DISCOVERY_FEEDS[i];
      const cards = settled[i].cards;
      if (!cards.length) continue;
      const limit = feed.hero ? 8 : feed.top10 ? 10 : 20;
      const items = cards.slice(0, limit);

      await Promise.all(
        items.slice(0, 6).map(async (card) => {
          const art = await fetchAniListArtwork(card.title);
          if (art && art.image) {
            card.image = art.image;
            card.poster = art.image;
            if (art.bannerImage) card.bannerImage = art.bannerImage;
          }
        })
      );

      sections.push({
        id: feed.id,
        title: feed.title,
        style: feed.hero ? 'hero' : feed.top10 ? 'top10' : 'poster',
        items,
        viewAll: { mode: 'feed', feedId: feed.id },
      });
    }
    return { sections };
  }

  async function discoveryFeed(feedId, page) {
    const feed = discoveryFeedById(feedId);
    const currentPage = Math.max(1, Number(page) || 1);
    if (!feed) return { items: [], page: currentPage, hasMore: false };
    const result = await fetchFeedCards(feed, currentPage);
    const items = result.cards;

    await Promise.all(
      items.slice(0, 10).map(async (card) => {
        const art = await fetchAniListArtwork(card.title);
        if (art && art.image) {
          card.image = art.image;
          card.poster = art.image;
          if (art.bannerImage) card.bannerImage = art.bannerImage;
        }
      })
    );

    const hasMore = result.totalPages > 0
      ? currentPage < result.totalPages
      : items.length > 0;
    return { items, page: currentPage, hasMore };
  }

  /* ------------------------------ Details ------------------------------ */

  async function extractDetails(urlOrId) {
    const url = toAbsoluteUrl(urlOrId);
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) throw new Error('AnimeAV1 page is blocked.');
    const html = res.text;
    const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
    const title = cleanText(
      (titleMatch && titleMatch[1]) || titleFromSlug(slugFromMediaUrl(url)),
    );
    let description = '';
    const blobMatch = html.match(/synopsis:"((?:[^"\\]|\\.)*)"/);
    if (blobMatch) description = unescapeBlobString(blobMatch[1]).trim();
    if (!description) {
      const og = html.match(/property="og:description" content="([^"]+)"/i);
      description = cleanText((og && og[1]) || '');
    }
    const imgMatch = html.match(
      /src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"[^>]*alt="[^"]*Poster"/i,
    ) || html.match(/src="(https:\/\/cdn\.animeav1\.com\/covers\/[^"]+)"/i);
    const nativeImage = (imgMatch && imgMatch[1]) || '';

    const art = await fetchAniListArtwork(title);
    const image = (art && art.image) || nativeImage;
    const bannerImage = (art && art.bannerImage) || nativeImage;

    return {
      title,
      description: description || `Anime en español en AnimeAV1: ${title}.`,
      image,
      poster: image,
      bannerImage,
      url,
      status: (art && art.status) || 'FINISHED',
      genres: (art && art.genres) || ['Anime', 'Español', 'VOSE', 'DUB'],
      rating: (art && art.rating) || '85',
      aliases: '',
    };
  }

  /* ------------------------------ Episodes & Language Detection ------------------------------ */

  function parseEmbeds(html) {
    const raw = String(html || '');
    const bodyMatch =
      raw.match(/embeds:\{([\s\S]*?)\}(?:,\s*downloads:|\s*\},uses:)/) ||
      raw.match(/embeds:\s*\{([\s\S]*?)\}(?=\s*,\s*[a-zA-Z0-9_]+:|\s*\}\s*<\/script>)/);
    if (!bodyMatch) return {};
    const body = bodyMatch[1];
    const variants = {};
    const sectionRe = /([A-Z]{2,8}):\[([\s\S]*?)\](?=,\s*[A-Z]{2,8}:\[|$)/g;
    let section;
    while ((section = sectionRe.exec(body))) {
      const variant = section[1];
      const servers = [];
      const itemRe = /\{server:["']([^"']+)["'],url:["']([^"']+)["']\}/g;
      let item;
      while ((item = itemRe.exec(section[2]))) {
        servers.push({
          server: item[1],
          url: item[2].replace(/\\u0026/g, '&').replace(/\\\//g, '/'),
        });
      }
      if (servers.length) variants[variant] = servers;
    }
    return variants;
  }

  async function detectSeriesLanguages(slug, sampleNumber) {
    if (seriesLangCache[slug]) return seriesLangCache[slug];

    try {
      const epNum = sampleNumber != null ? sampleNumber : 1;
      const epUrl = `${SITE}/media/${slug}/${epNum}`;
      const epRes = await requestText(epUrl, { Referer: `${SITE}/media/${slug}` }, 10000);
      if (epRes && epRes.text) {
        const embeds = parseEmbeds(epRes.text);
        const hasSub = Boolean(embeds.SUB && embeds.SUB.length > 0);
        const hasDub = Boolean(embeds.DUB && embeds.DUB.length > 0);

        if (hasSub || hasDub) {
          const res = { subAvailable: hasSub, dubAvailable: hasDub };
          seriesLangCache[slug] = res;
          return res;
        }
      }
    } catch (_) {}

    const fallback = { subAvailable: true, dubAvailable: false };
    seriesLangCache[slug] = fallback;
    return fallback;
  }

  async function extractEpisodes(seriesId) {
    const url = toAbsoluteUrl(seriesId);
    const slug = slugFromMediaUrl(url);
    if (!slug) return [];
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (looksBlockedPage(res.text)) return [];

    const listMatch = String(res.text).match(/episodes:\[([\s\S]*?)\]/);
    if (!listMatch) return [];
    const numbers = [];
    const seen = Object.create(null);
    const numRe = /number:(\d+(?:\.\d+)?)/g;
    let match;
    while ((match = numRe.exec(listMatch[1]))) {
      const n = Number(match[1]);
      if (isNaN(n) || seen[n]) continue;
      seen[n] = true;
      numbers.push(n);
    }
    numbers.sort((a, b) => a - b);
    if (!numbers.length) return [];

    const sampleNum = numbers[0];
    const { subAvailable, dubAvailable } = await detectSeriesLanguages(slug, sampleNum);
    const seriesTitle = titleFromSlug(slug);
    const isSingleMovie = numbers.length === 1 && numbers[0] === 0;

    return numbers.map((n) => {
      const isMovieEp = n === 0;
      const epTitle = isSingleMovie || isMovieEp ? 'Película' : `Episodio ${n}`;
      const epNumber = isSingleMovie ? 1 : n;
      return {
        number: epNumber,
        season: 1,
        href: `${SITE}/media/${slug}/${n}`,
        title: epTitle,
        description: isSingleMovie ? `Película: ${seriesTitle}` : `Episodio ${n} de ${seriesTitle}`,
        subAvailable,
        dubAvailable,
      };
    });
  }

  /* ------------------------------ Stream Extraction ------------------------------ */

  function streamHeaders(playId) {
    return {
      'User-Agent': USER_AGENT,
      Origin: PLAYER_HOST,
      Referer: `${PLAYER_HOST}/play/${playId}`,
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
    };
  }

  function mp4Headers(referer) {
    const origin = (String(referer).match(/^(https?:\/\/[^/]+)/) || [])[1] || referer;
    return {
      'User-Agent': USER_AGENT,
      Referer: referer,
      Origin: origin,
      Accept: 'video/mp4,video/*,*/*',
    };
  }

  async function probeMp4(url, headers, deadline) {
    const first = await requestRaw(
      url,
      Object.assign({}, headers, { Range: 'bytes=0-32' }),
      { followRedirects: false, timeoutMs: 8000, deadline },
    );
    const loc = readHeader(first.headers, 'location');
    if (
      (first.status === 301 ||
        first.status === 302 ||
        first.status === 303 ||
        first.status === 307 ||
        first.status === 308) &&
      loc
    ) {
      const next = toAbsoluteUrl(loc, url);
      const second = await requestRaw(
        next,
        Object.assign({}, headers, { Range: 'bytes=0-32' }),
        { followRedirects: false, timeoutMs: 8000, deadline },
      );
      if (!second.ok || looksHtmlBody(second.text) || !looksMediaSample(second.text, second.headers)) {
        return null;
      }
      return next;
    }
    if (!first.ok || looksHtmlBody(first.text) || !looksMediaSample(first.text, first.headers)) {
      return null;
    }
    if (first.finalUrl && /^https?:\/\//i.test(first.finalUrl) && first.finalUrl !== url) {
      return first.finalUrl;
    }
    return url;
  }

  async function probeZillaHls(playId, deadline) {
    const headers = streamHeaders(playId);
    const url = `${PLAYER_HOST}/m3u8/${playId}`;
    let playlist = await requestRaw(url, headers, { timeoutMs: 8000, deadline });
    if (!playlist.ok || playlist.text.indexOf('#EXTM3U') !== 0) return null;
    let playlistUrl = url;
    const variants = readHlsVariants(playlist.text, url, headers);
    if (playlist.text.includes('#EXT-X-STREAM-INF:')) {
      const child = firstHlsUri(playlist.text);
      if (!child) return null;
      playlistUrl = toAbsoluteUrl(child, url);
      playlist = await requestRaw(playlistUrl, headers, { timeoutMs: 8000, deadline });
      if (!playlist.ok || !playlist.text.startsWith('#EXTM3U')) return null;
    }
    const mediaUri = (playlist.text.match(/#EXT-X-MAP:URI="([^"]+)"/) || [])[1] || firstHlsUri(playlist.text);
    const probeUrl = toAbsoluteUrl(mediaUri, playlistUrl);
    if (!probeUrl) return null;

    const seg = await requestRaw(probeUrl, Object.assign({}, headers, { Range: 'bytes=0-32' }), {
      timeoutMs: 8000, deadline,
    });
    if (!seg.ok || looksBlockedPage(seg.text) || looksHtmlBody(seg.text) || !looksMediaSample(seg.text, seg.headers)) {
      return null;
    }
    return {
      type: 'HLS',
      url,
      streamType: 'hls',
      headers,
      qualities: [{ label: 'Auto', url, headers }].concat(variants),
      subtitles: [],
    };
  }

  function firstHlsUri(text) {
    return String(text).split(/\r?\n/).map((line) => line.trim()).find((line) => line && line.charAt(0) !== '#') || '';
  }

  function readHlsVariants(text, base, headers) {
    const lines = String(text).split(/\r?\n/);
    const result = [];
    const seen = Object.create(null);
    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];
      if (!line.startsWith('#EXT-X-STREAM-INF:')) continue;
      // A bare variant can lose its external audio group. Keep Auto in that case.
      if (/(?:[:,])AUDIO=/.test(line)) continue;
      const height = Number((line.match(/RESOLUTION=\d+x(\d+)/) || [])[1]);
      const uri = (lines[i + 1] || '').trim();
      const url = uri && uri.charAt(0) !== '#' ? toAbsoluteUrl(uri, base) : '';
      if (!height || !isStandardPort(url) || seen[url]) continue;
      seen[url] = true;
      result.push({ label: height + 'p', height, url, headers });
    }
    return result;
  }

  function readSubtitleTracks(html, base, headers) {
    const tracks = [];
    const seen = Object.create(null);
    for (const tag of String(html).match(/<track\b[^>]*>/gi) || []) {
      const attrs = Object.create(null);
      const re = /([a-z]+)\s*=\s*(["'])(.*?)\2/gi;
      let hit;
      while ((hit = re.exec(tag))) attrs[hit[1].toLowerCase()] = cleanText(hit[3]);
      if (attrs.kind && !/^(subtitles|captions)$/i.test(attrs.kind)) continue;
      const url = toAbsoluteUrl(attrs.src, base);
      if (!isStandardPort(url) || !/\.(vtt|srt)(?:[?#]|$)/i.test(url) || seen[url]) continue;
      if (!attrs.srclang && !attrs.label) continue;
      seen[url] = true;
      tracks.push({ url, language: attrs.srclang || '', label: attrs.label || attrs.srclang, headers });
    }
    return tracks;
  }

  function evalStreamTapeExpr(expr) {
    const source = String(expr || '');
    const blobMatch = source.match(/\('([^']+)'\)((?:\.substring\(\d+\))+)/);
    if (!blobMatch) return '';
    const head = source.slice(0, source.indexOf("('"));
    let prefix = '';
    const prefixRe = /['"]([^'"]*)['"]/g;
    let prefixHit = prefixRe.exec(head);
    while (prefixHit) {
      prefix += prefixHit[1];
      prefixHit = prefixRe.exec(head);
    }
    let piece = blobMatch[1];
    const cuts = blobMatch[2].match(/substring\((\d+)\)/g) || [];
    for (let i = 0; i < cuts.length; i += 1) {
      const n = Number((cuts[i].match(/\d+/) || [])[0] || 0);
      piece = piece.substring(n);
    }
    let url = prefix + piece;
    if (url.indexOf('//') === 0) url = 'https:' + url;
    if (url.charAt(0) === '/') url = 'https://streamtape.com' + url;
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url.replace(/^\/+/, '');
    return /get_video/i.test(url) ? url : '';
  }

  function parseStreamTapeGetVideo(html) {
    const source = String(html || '');
    const named = source.match(
      /getElementById\('robotlink'\)\.innerHTML\s*=\s*([^;]+)/i,
    );
    if (named) {
      const url = evalStreamTapeExpr(named[1]);
      if (url) return url;
    }
    const assignRe = /getElementById\('([^']*link[^']*)'\)\.innerHTML\s*=\s*([^;]+)/gi;
    let last = '';
    let assign = assignRe.exec(source);
    while (assign) {
      const url = evalStreamTapeExpr(assign[2]);
      if (url) last = url;
      assign = assignRe.exec(source);
    }
    return last;
  }

  async function resolveStreamTape(embedUrl, deadline) {
    if (!embedUrl || embedUrl.includes('undef')) return '';
    const res = await requestText(embedUrl, { Referer: SITE + '/', Accept: 'text/html,*/*' }, 8000, deadline);
    const getVideo = parseStreamTapeGetVideo(res.text);
    if (!getVideo) {
      log('streamtape: no get_video in embed');
      return '';
    }
    const headers = mp4Headers('https://streamtape.com/');
    const first = await requestRaw(
      getVideo,
      Object.assign({}, headers, { Range: 'bytes=0-32' }),
      { followRedirects: false, timeoutMs: 8000, deadline },
    );
    const loc = readHeader(first.headers, 'location');
    let target = loc
      ? toAbsoluteUrl(loc, getVideo)
      : (first.finalUrl && first.finalUrl !== getVideo ? first.finalUrl : '');
    if (!target && first.status >= 200 && first.status < 300 && looksMediaSample(first.text, first.headers)) {
      target = getVideo;
    }
    if (!target) {
      log('streamtape: no redirect from get_video status=' + first.status);
      return '';
    }
    const second = await requestRaw(
      target,
      Object.assign({}, headers, { Range: 'bytes=0-32' }),
      { followRedirects: false, timeoutMs: 8000, deadline },
    );
    if (!second.ok || looksHtmlBody(second.text) || !looksMediaSample(second.text, second.headers)) {
      log('streamtape: cdn probe failed status=' + second.status);
      return '';
    }
    return target;
  }

  async function resolveMp4Upload(embedUrl, deadline) {
    if (!embedUrl || embedUrl.includes('undef')) return '';
    const res = await requestText(embedUrl, { Referer: SITE + '/', Accept: 'text/html,*/*' }, 8000, deadline);
    if (!res.text) return '';
    const match = res.text.match(/src:\s*["'](https?:[^"']+\.mp4[^"']*)["']/i) ||
      res.text.match(/https?:\/\/[a-z0-9.-]*mp4upload\.com[^"']+\.mp4[^"']*/i);
    const url = match ? match[1] || match[0] : '';
    if (!url) return '';
    const headers = mp4Headers('https://www.mp4upload.com/');
    const probed = await probeMp4(url, headers, deadline);
    if (!probed) return '';
    if (!isStandardPort(probed)) {
      log('mp4upload: rejected non-standard port');
      return '';
    }
    return { url: probed, headers, subtitles: readSubtitleTracks(res.text, embedUrl, headers) };
  }

  async function resolveYourUpload(embedUrl, deadline) {
    if (!embedUrl || embedUrl.includes('undef')) return '';
    const res = await requestText(embedUrl, { Referer: SITE + '/', Accept: 'text/html,*/*' }, 8000, deadline);
    if (!res.text) return '';
    const match = res.text.match(/https?:\/\/[^"' ]*vidcache\.net[^"' ]+\.mp4[^"']*/i) ||
      res.text.match(/file\s*[:=]\s*["'](https?:[^"']+\.mp4[^"']*)["']/i);
    const url = match ? (match[1] || match[0]) : '';
    if (!url) return '';
    const headers = mp4Headers('https://www.yourupload.com/');
    const probed = await probeMp4(url, headers, deadline);
    return probed ? { url: probed, headers, subtitles: readSubtitleTracks(res.text, embedUrl, headers) } : null;
  }

  async function resolveEmbeds(servers, variant) {
    const preferred = { StreamTape: 0, YourUpload: 1, MP4Upload: 2, HLS: 3 };
    const hosts = { StreamTape: 'streamtape.com', YourUpload: 'yourupload.com', MP4Upload: 'mp4upload.com', HLS: 'player.zilla-networks.com' };
    const seenEmbeds = Object.create(null);
    const ordered = (servers || []).filter((item) => {
      const host = (String(item.url || '').match(/^https:\/\/(?:www\.)?([^/:?#]+)/i) || [])[1];
      if (!hosts[item.server] || host !== hosts[item.server] || !isStandardPort(item.url) || seenEmbeds[item.url]) return false;
      seenEmbeds[item.url] = true;
      return true;
    }).sort((a, b) => preferred[a.server] - preferred[b.server]);
    const deadline = Date.now() + 12000;
    let next = 0;
    const resolved = [];
    // Bound work to four concurrent site-provided embeds and one resolution budget.
    async function worker() {
      while (next < ordered.length && Date.now() < deadline) {
        const index = next++;
        const item = ordered[index];
        let stream = null;
        try {
          if (item.server === 'StreamTape') {
            const url = await resolveStreamTape(item.url, deadline);
            if (url) stream = { url, headers: mp4Headers('https://streamtape.com/') };
          } else if (item.server === 'YourUpload') {
            stream = await resolveYourUpload(item.url, deadline);
          } else if (item.server === 'MP4Upload') {
            stream = await resolveMp4Upload(item.url, deadline);
          } else if (item.server === 'HLS') {
            const playId = (item.url.match(/\/play\/([a-f0-9]{32})(?:[/?#]|$)/) || [])[1];
            if (playId) stream = await probeZillaHls(playId, deadline);
          }
        } catch (_) { log('resolve ' + item.server + ' unavailable'); }
        if (!stream || !isStandardPort(stream.url)) continue;
        const streamType = stream.streamType || 'mp4';
        const label = streamType === 'hls' ? 'Auto' : 'Original';
        resolved[index] = {
          name: item.server === 'HLS' ? 'AnimeAV1 HLS' : item.server,
          label,
          url: stream.url,
          streamType,
          headers: stream.headers,
          lang: variant === 'DUB' ? 'dub' : 'sub',
          subtitles: stream.subtitles || [],
          qualities: stream.qualities || [{ label, url: stream.url, headers: stream.headers }],
        };
      }
    }
    await Promise.all(Array.from({ length: Math.min(4, ordered.length) }, () => worker()));
    const seen = Object.create(null);
    return resolved.filter((stream) => {
      if (seen[stream.url]) return false;
      seen[stream.url] = true;
      return true;
    });
  }

  async function extractStreamUrl(episodeHref, lang) {
    const url = toAbsoluteUrl(episodeHref);
    if (!/^https:\/\/animeav1\.com\/media\/[^/?#]+\/\d+(?:\.\d+)?\/?(?:[?#].*)?$/.test(url)) {
      throw new Error('AnimeAV1 episode href is invalid');
    }
    const res = await requestText(url, { Referer: SITE + '/' }, 15000);
    if (!res.status || looksBlockedPage(res.text)) {
      throw new Error('AnimeAV1 episode page is unavailable');
    }

    const requestedVariant = String(lang || '').toLowerCase() === 'dub' ? 'DUB' : 'SUB';
    const embeds = parseEmbeds(res.text);
    if (!embeds[requestedVariant] || !embeds[requestedVariant].length) {
      throw new Error('AnimeAV1 ' + requestedVariant + ' is not available for this episode');
    }
    const resolved = await resolveEmbeds(embeds[requestedVariant], requestedVariant);
    if (!resolved.length) {
      throw new Error('AnimeAV1 ' + requestedVariant + ' hosts could not provide verified media');
    }

    const primary = resolved[0];
    return {
      url: primary.url,
      stream: primary.url,
      streams: [primary.label, primary.url],
      qualities: primary.qualities,
      servers: resolved,
      headers: primary.headers,
      quality: primary.label,
      lang: requestedVariant === 'DUB' ? 'dub' : 'sub',
      streamType: primary.streamType,
      subtitles: primary.subtitles,
    };
  }

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
