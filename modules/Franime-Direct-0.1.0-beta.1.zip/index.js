// FRAnime Direct — Synthetiq Player module (contractVersion 4, discovery_v1)
//
// Strategy: the franime.fr public API (api.franime.fr) supplies the whole
// catalogue — animes -> saisons -> episodes -> per-language lecteur lists — and
// a per-lecteur "watch2" URL. The watch2 URL is a signed, lightly-obfuscated
// wrapper: base64(hex(payload XOR K)) where K = XOR of the char codes of the
// m-param payload between its 4-char head and 7-char tail. We decode that
// locally in pure JS (verified against the provider's WASM decoder and 13 live
// samples), then resolve the resulting hoster embed (sibnet / vidmoly /
// sendvid / uqload / generic) into a directly playable MP4 or HLS route.
//
// No watch2 page is ever fetched: the Cloudflare challenge on it is irrelevant
// to this module. No timers are used (the app sandbox does not pump them).

(() => {
  'use strict';

  const MODULE_NAME = 'franime-direct';
  const BASE = 'https://franime.fr';
  const API = 'https://api.franime.fr/api';
  const USER_AGENT =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';

  const CATALOG_TTL_MS = 10 * 60 * 1000;
  const META_TTL_MS = 10 * 60 * 1000;
  const SEASONS_TTL_MS = 30 * 60 * 1000;
  const STREAM_TTL_MS = 5 * 60 * 1000;
  const HOST_PARK_MS = 15 * 60 * 1000;
  const MAX_EPISODES = 3000;
  const SEARCH_PAGE_SIZE = 60;
  const FEED_PAGE_SIZE = 50;

  // Lecteur names that are not streamable players.
  const NON_STREAM_LECTEURS = { 'TELECHARGEMENT': 1, 'TELECHARGEMENT UNIQUE': 1, 'INDISPONIBLE': 1, '': 1 };

  // Hosts we know how to resolve, in preference order (verified live 2026-09-14:
  // sibnet + vidmoly resolve; sendvid was returning site-wide 502s that day;
  // uqload is the classic packer and unpacks in pure JS).
  const PREFERRED_HOSTS = ['sibnet', 'vidmoly', 'sendvid', 'uqload'];

  const catalogCache = { savedAt: 0, items: null };
  const weeklyCache = { savedAt: 0, ids: null };
  const likedCache = { savedAt: 0, items: null };
  const seasonsCache = Object.create(null);
  const streamCache = Object.create(null);
  const hostParked = Object.create(null);

  function log(msg) {
    try { console.log('[' + MODULE_NAME + '] ' + String(msg || '')); } catch (_) {}
  }

  function now() { return Date.now(); }

  function cleanText(v) {
    return String(v == null ? '' : v).replace(/\s+/g, ' ').trim();
  }

  function hostOf(url) {
    const m = String(url || '').match(/^https?:\/\/([^/]+)/i);
    return m ? m[1].toLowerCase() : '';
  }

  function parkHost(host, status) {
    if (!host) return;
    hostParked[host] = { until: now() + HOST_PARK_MS, status: status || 0 };
  }

  function parkedUntil(host) {
    const p = hostParked[host];
    if (!p) return 0;
    if (p.until <= now()) { delete hostParked[host]; return 0; }
    return p.until;
  }

  function headerOf(headers, name) {
    if (!headers) return '';
    const want = String(name).toLowerCase();
    let keys = [];
    try { keys = Object.keys(headers); } catch (_) { return ''; }
    for (let i = 0; i < keys.length; i++) {
      if (String(keys[i]).toLowerCase() === want) {
        const v = headers[keys[i]];
        return Array.isArray(v) ? cleanText(v[0]) : cleanText(v);
      }
    }
    return '';
  }

  function absUrl(u, base) {
    const s = String(u || '').trim().replace(/^["']|["']$/g, '');
    if (/^https?:\/\//i.test(s)) return s;
    if (s.indexOf('//') === 0) return 'https:' + s;
    const m = String(base || '').match(/^(https?:\/\/[^/]+)(\/.*)?$/);
    const origin = m ? m[1] : BASE;
    const path = m && m[2] ? m[2] : '/';
    if (s.charAt(0) === '/') return origin + s;
    return origin + path.replace(/[^/]*$/, '') + s;
  }

  async function readResponseBody(res) {
    if (!res) return '';
    // The app bridge omits the raw body for JSON responses (it pre-parses and
    // exposes res.json() instead), so an EMPTY string from text()/body must
    // fall through — not short-circuit — or every JSON call reads as empty.
    try {
      if (typeof res.text === 'function') {
        const t = await res.text();
        if (typeof t === 'string' && t.length) return t;
      }
    } catch (_) {}
    try {
      if (typeof res.body === 'string' && res.body.length) return res.body;
    } catch (_) {}
    try {
      if (typeof res.json === 'function') {
        const j = await res.json();
        if (j != null) return typeof j === 'string' ? j : JSON.stringify(j);
      }
    } catch (_) {}
    return '';
  }

  // The API WAF passes browser-like requests: UA + Accept + Content-Type +
  // Origin/Referer. No cookies are required (verified 2026-09-14); query
  // parameters on /animes are rejected with a 403, so never add any.
  function apiHeaders(extra) {
    const h = {
      'User-Agent': USER_AGENT,
      Accept: 'application/json, text/plain, */*',
      'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
      'Content-Type': 'application/json',
      Origin: BASE,
      Referer: BASE + '/',
    };
    if (extra) Object.assign(h, extra);
    return h;
  }

  function mediaHeaders(referer) {
    const h = { 'User-Agent': USER_AGENT };
    if (referer) h.Referer = referer;
    return h;
  }

  async function request(url, cfg) {
    cfg = cfg || {};
    const headers = Object.assign(apiHeaders(), cfg.headers || {});
    const method = cfg.method || 'GET';
    const body = cfg.body == null ? null : cfg.body;
    const host = hostOf(url);
    const parked = cfg.ignorePark ? 0 : parkedUntil(host);
    if (parked) {
      return { ok: false, status: 429, rateLimited: true, host, body: '', headers: {} };
    }
    try {
      if (typeof fetchv2 === 'function') {
        const res = await fetchv2(url, headers, method, body, cfg.fetchOpts || undefined);
        const status = Number((res && res.status) || 0);
        if (status === 429) parkHost(host, status);
        const text = await readResponseBody(res);
        return {
          ok: !!(res && (res.ok === true || (status >= 200 && status < 300))),
          status,
          rateLimited: status === 429,
          host,
          body: text,
          headers: (res && res.headers) || {},
        };
      }
      if (typeof fetch === 'function') {
        const res = await fetch(url, Object.assign({ method, headers, body }, cfg.fetchOpts || {}));
        const text = await readResponseBody(res);
        return {
          ok: !!res.ok,
          status: Number(res.status || 0),
          host,
          body: text,
          headers: (res && res.headers) || {},
        };
      }
    } catch (e) {
      log('request error ' + host + ': ' + (e && e.message ? e.message : String(e)));
    }
    return { ok: false, status: 0, host, body: '', headers: {} };
  }

  // ---------- pure-JS crypto plumbing for the watch2 payload ----------

  const B64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  const B64_INDEX = (() => {
    const m = Object.create(null);
    for (let i = 0; i < B64_ALPHABET.length; i++) m[B64_ALPHABET.charAt(i)] = i;
    return m;
  })();

  function pctDecode(s) {
    try {
      return String(s).replace(/%([0-9A-Fa-f]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
    } catch (_) {
      return String(s);
    }
  }

  function b64ToBytes(s) {
    const src = String(s || '').replace(/[^A-Za-z0-9+/=]/g, '');
    const out = [];
    let buffer = 0;
    let bits = 0;
    for (let i = 0; i < src.length; i++) {
      const ch = src.charAt(i);
      if (ch === '=') break;
      const v = B64_INDEX[ch];
      if (v === undefined) continue;
      buffer = (buffer << 6) | v;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        out.push((buffer >> bits) & 0xff);
      }
    }
    return out;
  }

  function bytesToStr(bytes) {
    let out = '';
    for (let i = 0; i < bytes.length; i++) out += String.fromCharCode(bytes[i]);
    return out;
  }

  // watch2 payload decode, verified against the provider's own WASM decoder
  // and 13 live samples (2026-09-14): the m-param carries a key string whose
  // char codes (between the 4-char head and 7-char tail) XOR-fold to K; the
  // b-param is hex(XOR_K(embed URL)).
  function decodeWatch2(watch2Url) {
    const url = String(watch2Url || '');
    const q = url.indexOf('?');
    if (q < 0) return null;
    let b = null;
    let m = null;
    const parts = url.slice(q + 1).split('&');
    for (let i = 0; i < parts.length; i++) {
      const eq = parts[i].indexOf('=');
      if (eq < 0) continue;
      const k = parts[i].slice(0, eq);
      if (k !== 'b' && k !== 'm') continue;
      const v = pctDecode(parts[i].slice(eq + 1));
      if (k === 'b') b = v; else m = v;
    }
    if (!b || !m) return null;
    const M = bytesToStr(b64ToBytes(m));
    if (M.length < 12) return null;
    let K = 0;
    for (let i = 4; i < M.length - 7; i++) K ^= M.charCodeAt(i) & 0xff;
    const hexStr = bytesToStr(b64ToBytes(b));
    if (hexStr.length < 2) return null;
    let out = '';
    for (let i = 0; i + 1 < hexStr.length; i += 2) {
      const byte = parseInt(hexStr.substr(i, 2), 16);
      if (byte !== byte) return null;
      out += String.fromCharCode((byte ^ K) & 0xff);
    }
    return /^https?:\/\//i.test(out) ? out : null;
  }

  // Dean Edwards-style packer unpack (uqload). Deterministic string rewrite,
  // implemented here in full — no eval anywhere.
  function unpackPacked(source) {
    const s = String(source || '');
    const start = s.indexOf("}('");
    if (start < 0) return null;
    const body = s.slice(start + 2);
    // Split the argument list at the first "'" ... use a tolerant parser:
    const args = [];
    let i = 0;
    while (i < body.length && args.length < 4) {
      const ch = body.charAt(i);
      if (ch === "'") {
        let j = i + 1;
        let val = '';
        while (j < body.length) {
          const c = body.charAt(j);
          if (c === '\\') { val += body.charAt(j + 1); j += 2; continue; }
          if (c === "'") break;
          val += c;
          j += 1;
        }
        args.push({ str: val });
        i = j + 1;
      } else if (ch === ',') {
        i += 1;
      } else {
        // number argument (base / count)
        let j = i;
        let num = '';
        while (j < body.length && /[0-9]/.test(body.charAt(j))) { num += body.charAt(j); j += 1; }
        if (num) { args.push({ num: parseInt(num, 10) }); i = j; }
        else { i += 1; }
      }
    }
    if (args.length < 4 || !args[0].str || args[1].num == null || args[2].num == null || !args[3].str) return null;
    let payload = args[0].str;
    const base = args[1].num;
    let count = args[2].num;
    const words = args[3].str.split('|');
    const encode = (n) => n.toString(base);
    while (count--) {
      if (words[count]) {
        const token = encode(count);
        payload = payload.replace(new RegExp('\\b' + token + '\\b', 'g'), words[count]);
      }
    }
    return payload;
  }

  // ---------- catalogue ----------

  function normalizeItem(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const id = Number(raw.id);
    if (!id) return null;
    const title = cleanText(raw.title || raw.titleO || '');
    if (!title) return null;
    return {
      id,
      title,
      titleO: cleanText(raw.titleO || ''),
      titles: raw.titles && typeof raw.titles === 'object' ? raw.titles : {},
      affiche: cleanText(raw.affiche || raw.affiche_small || ''),
      afficheSmall: cleanText(raw.affiche_small || ''),
      banner: cleanText(raw.banner || raw.banner_small || ''),
      description: cleanText(String(raw.description || '').replace(/<[^>]+>/g, ' ')),
      note: cleanText(String(raw.note == null ? '' : raw.note)),
      themes: Array.isArray(raw.themes) ? raw.themes.filter(Boolean).map((t) => cleanText(String(t))) : [],
      format: cleanText(raw.format || ''),
      status: cleanText(raw.status || ''),
      startDate: cleanText(raw.startDate || ''),
      updatedDate: Number(raw.updatedDate) || 0,
      updatedDateVF: Number(raw.updatedDateVF) || 0,
      saisons: Array.isArray(raw.saisons) ? raw.saisons : [],
    };
  }

  async function getCatalog() {
    if (catalogCache.items && now() - catalogCache.savedAt < CATALOG_TTL_MS) return catalogCache.items;
    // The catalogue is ~10.5 MB of JSON. The app bridge drops JSON bodies
    // above 5 MB unless the request carries maxBytesHint (hard cap 16 MB), so
    // this one request must raise it or the body comes back empty.
    const res = await request(API + '/animes', { fetchOpts: { maxBytesHint: 15728640 } });
    if (res.ok && res.body) {
      try {
        const arr = JSON.parse(res.body);
        if (Array.isArray(arr) && arr.length) {
          const items = [];
          for (let i = 0; i < arr.length; i++) {
            const it = normalizeItem(arr[i]);
            if (it) items.push(it);
          }
          if (items.length) {
            catalogCache.savedAt = now();
            catalogCache.items = items;
            log('catalog loaded: ' + items.length + ' items (' + Math.round(res.body.length / 1024) + ' KB)');
            return items;
          }
        }
      } catch (e) {
        log('catalog parse failed: ' + (e && e.message ? e.message : e));
      }
    } else {
      log('catalog fetch failed status=' + res.status);
    }
    return catalogCache.items || [];
  }

  function findById(items, id) {
    for (let i = 0; i < items.length; i++) if (items[i].id === id) return items[i];
    return null;
  }

  async function getWeeklyIds() {
    if (weeklyCache.ids && now() - weeklyCache.savedAt < META_TTL_MS) return weeklyCache.ids;
    const res = await request(API + '/top/animes/weekly');
    if (res.ok && res.body) {
      try {
        const arr = JSON.parse(res.body);
        if (Array.isArray(arr)) {
          const ids = arr.map((x) => Number(x && x.id)).filter(Boolean);
          if (ids.length) {
            weeklyCache.savedAt = now();
            weeklyCache.ids = ids;
            return ids;
          }
        }
      } catch (_) {}
    }
    return weeklyCache.ids || [];
  }

  async function getLiked() {
    if (likedCache.items && now() - likedCache.savedAt < META_TTL_MS) return likedCache.items;
    const res = await request(API + '/discord/voted/render-top-15-of-bestanimes');
    if (res.ok && res.body) {
      try {
        const arr = JSON.parse(res.body);
        if (Array.isArray(arr)) {
          const items = [];
          for (let i = 0; i < arr.length; i++) {
            const it = normalizeItem(arr[i]);
            if (it) items.push(it);
          }
          if (items.length) {
            likedCache.savedAt = now();
            likedCache.items = items;
            return items;
          }
        }
      } catch (_) {}
    }
    return likedCache.items || [];
  }

  async function getSeasonsData(animeId) {
    const key = String(animeId);
    const c = seasonsCache[key];
    if (c && now() - c.savedAt < SEASONS_TTL_MS) return c.data;
    const res = await request(API + '/anime-seasons/' + key);
    if (res.ok && res.body) {
      try {
        const data = JSON.parse(res.body);
        if (data && Array.isArray(data.episodeDetails)) {
          seasonsCache[key] = { savedAt: now(), data };
          return data;
        }
      } catch (_) {}
    }
    return c ? c.data : null;
  }

  // ---------- refs ----------

  function encodeRef(animeId, seasonIdx, episodeIdx) {
    if (seasonIdx == null || episodeIdx == null) return 'frd:' + animeId;
    return 'frd:' + animeId + ':' + seasonIdx + ':' + episodeIdx;
  }

  function parseRef(raw) {
    const s = cleanText(raw);
    if (!s) return null;
    // Accepts bare refs ("frd:<id>[:si:ei]") AND baseUrl-joined forms
    // ("https://franime.fr/frd:<id>[:si:ei]") — the app joins the module's
    // baseUrl onto hrefs before calling extractDetails.
    let m = s.match(/(?:^|\/)frd:(\d+)(?::(\d+):(\d+))?$/i);
    if (m) {
      return {
        id: Number(m[1]),
        seasonIdx: m[2] == null ? null : Number(m[2]),
        episodeIdx: m[3] == null ? null : Number(m[3]),
      };
    }
    // accept full franime watch URLs: /anime/<slug>?...&anime_id=13051&s=1&ep=1
    m = s.match(/anime_id=(\d+)/i);
    if (m) {
      const sIdx = s.match(/[?&]s=(\d+)/i);
      const eIdx = s.match(/[?&]ep=(\d+)/i);
      return {
        id: Number(m[1]),
        seasonIdx: sIdx ? Number(sIdx[1]) - 1 : null,
        episodeIdx: eIdx ? Number(eIdx[1]) - 1 : null,
      };
    }
    m = s.match(/api\/anime\/(\d+)\/(\d+)\/(\d+)\/(vf|vo)\/(\d+)/i);
    if (m) return { id: Number(m[1]), seasonIdx: Number(m[2]), episodeIdx: Number(m[3]) };
    m = s.match(/^\d+$/);
    if (m) return { id: Number(s), seasonIdx: null, episodeIdx: null };
    return null;
  }

  function cardFromItem(item) {
    return {
      title: item.title,
      image: item.affiche || item.afficheSmall || item.banner || '',
      href: encodeRef(item.id),
    };
  }

  function heroCardFromItem(item) {
    const c = cardFromItem(item);
    if (item.banner) c.backdropUrl = item.banner;
    if (item.affiche) c.posterUrl = item.affiche;
    return c;
  }

  // ---------- search ----------

  function normText(s) {
    let t = String(s || '').toLowerCase();
    try { t = t.normalize('NFD').replace(/[\u0300-\u036f]/g, ''); } catch (_) {}
    return t.replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
  }

  function scoreItem(item, queryNorm, tokens) {
    const fields = [
      { v: normText(item.title), w: 1.0 },
      { v: normText(item.titleO), w: 0.97 },
      { v: normText(item.titles && item.titles.en_jp), w: 0.95 },
      { v: normText(item.titles && item.titles.en_us), w: 0.93 },
      { v: normText(item.titles && item.titles.ja_jp), w: 0.8 },
    ];
    let best = 0;
    for (let i = 0; i < fields.length; i++) {
      const v = fields[i].v;
      if (!v) continue;
      let s = 0;
      if (v === queryNorm) s = 1000;
      else if (v.indexOf(queryNorm) === 0) s = 800;
      else if (v.indexOf(queryNorm) >= 0) s = 600;
      else {
        let hit = 0;
        for (let t = 0; t < tokens.length; t++) if (tokens[t] && v.indexOf(tokens[t]) >= 0) hit += 1;
        if (tokens.length && hit === tokens.length) s = 420;
        else if (tokens.length > 1 && hit >= Math.ceil(tokens.length * 0.6)) s = 220 + hit * 10;
      }
      if (s) s = s * fields[i].w;
      if (s > best) best = s;
    }
    if (best && item.note) {
      const n = parseFloat(item.note);
      if (n > 0) best += Math.min(n, 10); // tiny tie-break on rating
    }
    return best;
  }

  async function searchResults(query) {
    const q = cleanText(query);
    const items = await getCatalog();
    if (!items.length) return [];
    if (!q) {
      // Home/browse row: keep the catalogue's own featured order. Fast path —
      // one (cached) request, no per-title work inside the ~30s home budget.
      return items.slice(0, 30).map(cardFromItem);
    }
    const qn = normText(q);
    const tokens = qn.split(' ').filter(Boolean);
    const scored = [];
    for (let i = 0; i < items.length; i++) {
      const s = scoreItem(items[i], qn, tokens);
      if (s > 0) scored.push({ s, it: items[i] });
    }
    scored.sort((a, b) => b.s - a.s || b.it.updatedDate - a.it.updatedDate);
    return scored.slice(0, SEARCH_PAGE_SIZE).map((x) => cardFromItem(x.it));
  }

  // ---------- details / episodes ----------

  async function extractDetails(urlOrId) {
    const ref = parseRef(urlOrId);
    if (!ref) return { title: '', description: '' };
    let item = findById(await getCatalog(), ref.id);
    if (!item) {
      const res = await request(API + '/anime-by-id/' + ref.id);
      if (res.ok && res.body) {
        try { item = normalizeItem(JSON.parse(res.body)); } catch (_) {}
      }
    }
    if (!item) return { title: '', description: '' };
    return {
      title: item.title,
      description: item.description || '',
      image: item.affiche || item.banner || '',
      genres: item.themes.slice(0, 12),
      status: item.status || '',
      format: item.format || '',
      rating: item.note || '',
      releaseDate: item.startDate || '',
      id: encodeRef(item.id),
      url: '',
    };
  }

  function lecteursOf(episode, lang) {
    const l = episode && episode.lang && episode.lang[lang];
    const arr = l && Array.isArray(l.lecteurs) ? l.lecteurs : [];
    return arr.map((n) => cleanText(n)).filter((n) => !NON_STREAM_LECTEURS[n]);
  }

  function seasonNumberFromTitle(t) {
    // Season titles vary: "Saison 1", "Saison 2.5", "East Blue Saga 1",
    // "Saison 2023 Live Action 0.5" — the grouping number is the LAST number.
    const nums = String(t || '').match(/\d+(?:\.\d+)?/g);
    return nums && nums.length ? nums[nums.length - 1] : '';
  }

  async function extractEpisodes(seriesId) {
    const ref = parseRef(seriesId);
    if (!ref) return [];
    const items = await getCatalog();
    const item = findById(items, ref.id);
    if (!item) return [];
    const seasonsData = await getSeasonsData(item.id);
    const seasonsMeta = seasonsData && Array.isArray(seasonsData.episodeDetails) ? seasonsData.episodeDetails : [];
    const out = [];
    const saisons = item.saisons || [];
    for (let si = 0; si < saisons.length; si++) {
      const season = saisons[si] || {};
      const episodes = Array.isArray(season.episodes) ? season.episodes : [];
      const meta = seasonsMeta[si] && Array.isArray(seasonsMeta[si].episodes) ? seasonsMeta[si].episodes : [];
      const sNumRaw = seasonNumberFromTitle(season.title) || String(si + 1);
      const sNum = parseInt(sNumRaw, 10);
      const seasonInt = isFinite(sNum) ? sNum : si + 1;
      for (let ei = 0; ei < episodes.length; ei++) {
        const ep = episodes[ei] || {};
        const metaEp = meta[ei] || {};
        const vf = lecteursOf(ep, 'vf');
        const vo = lecteursOf(ep, 'vo');
        if (!vf.length && !vo.length) continue; // dead episode, don't advertise it
        const number = metaEp.number != null && metaEp.number !== '' ? metaEp.number : ei + 1;
        const entry = {
          number,
          season: seasonInt,
          href: encodeRef(item.id, si, ei),
          title: cleanText(metaEp.title || ep.title || '') || 'Épisode ' + number,
          subAvailable: vo.length > 0,
          dubAvailable: vf.length > 0,
        };
        if (metaEp.thumbnail) entry.image = cleanText(metaEp.thumbnail);
        if (metaEp.airDate) entry.airDate = cleanText(metaEp.airDate);
        out.push(entry);
        if (out.length >= MAX_EPISODES) {
          log('episode list capped at ' + MAX_EPISODES + ' for ' + item.title);
          return out;
        }
      }
    }
    log('extractEpisodes ' + item.id + ' -> ' + out.length + ' eps (' + saisons.length + ' seasons)');
    return out;
  }

  // ---------- stream resolution ----------

  function noRoute(message, code) {
    return {
      streams: [],
      subtitles: [],
      error: { code: code || 'NO_ROUTE', message: message || 'No usable route for this episode.' },
    };
  }

  async function fetchLecteurUrl(animeId, si, ei, lang, li) {
    const url = API + '/anime/' + animeId + '/' + si + '/' + ei + '/' + lang + '/' + li;
    const res = await request(url, { headers: { Accept: '*/*' } });
    if (!res.ok || !res.body) return null;
    const t = cleanText(res.body);
    if (!/^https?:\/\//.test(t)) return null; // stub responses like "https://franime.fr" are not players
    return t;
  }

  function mediaPlaylistSegments(text, baseUrl) {
    const lines = String(text || '').split('\n');
    const segs = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i].trim();
      if (!l || l.charAt(0) === '#') continue;
      segs.push(absUrl(l, baseUrl));
    }
    return segs;
  }

  function parseMasterVariants(text, baseUrl) {
    const lines = String(text || '').split('\n');
    const variants = [];
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i].trim();
      if (l.indexOf('#EXT-X-STREAM-INF') !== 0) continue;
      const attrs = l.slice(l.indexOf(':') + 1);
      let height = null;
      let bandwidth = null;
      const rm = attrs.match(/RESOLUTION=\d+x(\d+)/i);
      if (rm) height = parseInt(rm[1], 10);
      const bm = attrs.match(/BANDWIDTH=(\d+)/i);
      if (bm) bandwidth = parseInt(bm[1], 10);
      for (let j = i + 1; j < lines.length; j++) {
        const n = lines[j].trim();
        if (!n) continue;
        if (n.charAt(0) === '#') continue;
        variants.push({ url: absUrl(n, baseUrl), height, bandwidth });
        i = j;
        break;
      }
    }
    variants.sort((a, b) => (b.height || 0) - (a.height || 0) || (b.bandwidth || 0) - (a.bandwidth || 0));
    return variants;
  }

  async function probeRange(url, headers) {
    const res = await request(url, {
      headers: Object.assign({ Range: 'bytes=0-1023' }, headers || {}),
      ignorePark: true,
    });
    if (!res) return { ok: false, status: 0 };
    const okStatus = res.status === 200 || res.status === 206;
    const bodyHead = String(res.body || '').slice(0, 64);
    const ct = headerOf(res.headers, 'content-type');
    const sig = bodyHead.indexOf('ftyp') >= 0;
    return { ok: okStatus && (sig || /video\/|octet-stream|mpegurl/i.test(ct)), status: res.status, sig, ct };
  }

  // Build HLS routes from a master (or media) playlist URL that has already
  // been confirmed fetchable. Validates the top variant's playlist + first
  // segment before accepting.
  async function buildHlsRoutes(src, headers, providerName, langLabel, routeLang, providerKey) {
    const pl = await request(src, { headers });
    const body = pl && pl.ok ? String(pl.body || '') : '';
    if (!/^\s*#EXTM3U/.test(body)) {
      log(providerName + ': playlist unavailable (status ' + (pl ? pl.status : '?') + ')');
      return null;
    }
    const variants = parseMasterVariants(body, src);
    const routes = [];
    if (variants.length) {
      const cap = Math.min(variants.length, 3);
      for (let i = 0; i < cap; i++) {
        const v = variants[i];
        routes.push({
          label: providerName + ' · ' + langLabel + (v.height ? ' · ' + v.height + 'p' : ''),
          url: v.url,
          streamType: 'hls',
          kind: 'hls',
          provider: providerKey,
          lang: routeLang,
          headers,
          height: v.height || undefined,
        });
      }
    } else {
      routes.push({
        label: providerName + ' · ' + langLabel,
        url: src,
        streamType: 'hls',
        kind: 'hls',
        provider: providerKey,
        lang: routeLang,
        headers,
      });
    }
    // Validate the top variant: playlist + first segment byte probe.
    const probeRes = await request(routes[0].url, { headers });
    const probeBody = probeRes && probeRes.ok ? String(probeRes.body || '') : '';
    let segs = [];
    if (/^\s*#EXTM3U/.test(probeBody) && !/#EXT-X-STREAM-INF/.test(probeBody)) {
      segs = mediaPlaylistSegments(probeBody, routes[0].url);
    } else if (/^\s*#EXTM3U/.test(probeBody)) {
      const inner = parseMasterVariants(probeBody, routes[0].url);
      if (inner.length) {
        const innerRes = await request(inner[0].url, { headers });
        if (innerRes && innerRes.ok && /^\s*#EXTM3U/.test(String(innerRes.body || ''))) {
          segs = mediaPlaylistSegments(String(innerRes.body || ''), inner[0].url);
        }
      }
    }
    if (!segs.length) {
      log(providerName + ': variant playlist has no segments');
      return null;
    }
    const seg = await probeRange(segs[0], headers);
    if (!seg.ok) log(providerName + ': segment probe inconclusive (status ' + seg.status + ')');
    return routes;
  }

  async function resolveSibnet(embedUrl, langLabel, routeLang) {
    // shell page holds the physical file path "/v/<hash>/<id>.mp4"
    const page = await request(embedUrl, { headers: mediaHeaders(BASE + '/') });
    if (!page.ok || !page.body) return null;
    const m = String(page.body).match(/["'(\s](\/v\/[0-9a-f]{32}\/\d+\.mp4)/i);
    if (!m) return null;
    const filePath = m[1];
    const fileUrl = 'https://video.sibnet.ru' + filePath;
    const headers = mediaHeaders('https://video.sibnet.ru/');
    // Pre-resolve the 302 to the signed CDN URL (Range on the redirect request
    // so nothing large is pulled; followRedirects off to read Location).
    const head = await request(fileUrl, {
      headers: Object.assign({ Range: 'bytes=0-1023' }, headers),
      fetchOpts: { followRedirects: false },
      ignorePark: true,
    });
    let finalUrl = fileUrl;
    if (head && [301, 302, 303, 307, 308].indexOf(head.status) >= 0) {
      const loc = headerOf(head.headers, 'location');
      if (loc) finalUrl = absUrl(loc, fileUrl);
    }
    if (finalUrl === fileUrl) {
      // no redirect captured — fall back to a plain range probe on the direct URL
      const probe = await probeRange(fileUrl, headers);
      if (!probe.ok) return null;
    } else {
      const probe = await probeRange(finalUrl, headers);
      if (!probe.ok) {
        log('sibnet: resolved CDN url failed probe (status ' + probe.status + ')');
        return null;
      }
    }
    return [{
      label: 'Sibnet · ' + langLabel,
      url: finalUrl,
      streamType: 'mp4',
      kind: 'mp4',
      provider: 'sibnet',
      lang: routeLang,
      headers,
    }];
  }

  async function resolveVidmoly(embedUrl, langLabel, routeLang) {
    const page = await request(embedUrl, { headers: mediaHeaders(BASE + '/') });
    if (!page.ok || !page.body) return null;
    const body = String(page.body);
    let m = body.match(/sources:\s*\[\s*\{\s*file:\s*['"]([^'"]+)['"]/i);
    let src = m ? m[1] : '';
    if (!src) {
      m = body.match(/(https?:\/\/[^"'\s\\]+\.m3u8[^"'\s\\]*)/i);
      if (m) src = m[1];
    }
    if (!src) {
      m = body.match(/(https?:\/\/[^"'\s\\]+\.mp4[^"'\s\\]*)/i);
      if (m) {
        const mp4 = m[1];
        const headers = mediaHeaders(embedUrl);
        const probe = await probeRange(mp4, headers);
        if (!probe.ok) return null;
        return [{ label: 'Vidmoly · ' + langLabel, url: mp4, streamType: 'mp4', kind: 'mp4', provider: 'vidmoly', lang: routeLang, headers }];
      }
      return null;
    }
    const headers = mediaHeaders(embedUrl);
    return buildHlsRoutes(src, headers, 'Vidmoly', langLabel, routeLang, 'vidmoly');
  }

  async function resolveSendvid(embedUrl, langLabel, routeLang) {
    const page = await request(embedUrl, { headers: mediaHeaders('https://sendvid.com/') });
    if (!page.ok || !page.body) return null;
    const body = String(page.body);
    const m = body.match(/(https?:\/\/[^"'\s<>]+\.mp4[^"'\s<>]*)/i) || body.match(/(\/\/[^"'\s<>]+\.mp4[^"'\s<>]*)/i);
    if (!m) return null;
    const mp4 = absUrl(m[1], embedUrl);
    const headers = mediaHeaders('https://sendvid.com/');
    const probe = await probeRange(mp4, headers);
    if (!probe.ok) {
      log('sendvid: mp4 probe failed (status ' + probe.status + ')');
      return null;
    }
    return [{ label: 'SendVid · ' + langLabel, url: mp4, streamType: 'mp4', kind: 'mp4', provider: 'sendvid', lang: routeLang, headers }];
  }

  async function resolveUqload(embedUrl, langLabel, routeLang) {
    const page = await request(embedUrl, { headers: mediaHeaders('https://uqload.vc/') });
    if (!page.ok || !page.body) return null;
    const body = String(page.body);
    let src = '';
    let m = body.match(/sources:\s*\[\s*\{\s*file:\s*['"]([^'"]+)['"]/i);
    if (m) src = m[1];
    if (!src) {
      const unpacked = unpackPacked(body);
      if (unpacked) {
        m = unpacked.match(/sources:\s*\[\s*\{\s*file:\s*['"]([^'"]+)['"]/i) ||
            unpacked.match(/file:\s*['"]([^'"]+)['"]/i) ||
            unpacked.match(/(https?:\/\/[^"'\s\\]+\.m3u8[^"'\s\\]*)/i) ||
            unpacked.match(/(https?:\/\/[^"'\s\\]+\.mp4[^"'\s\\]*)/i);
        if (m) src = m[1];
      }
    }
    if (!src) return null;
    const headers = mediaHeaders('https://uqload.vc/');
    if (/\.m3u8/i.test(src)) {
      return buildHlsRoutes(src, headers, 'Uqload', langLabel, routeLang, 'uqload');
    }
    const probe = await probeRange(src, headers);
    if (!probe.ok) return null;
    return [{ label: 'Uqload · ' + langLabel, url: src, streamType: 'mp4', kind: 'mp4', provider: 'uqload', lang: routeLang, headers }];
  }

  async function resolveGeneric(embedUrl, langLabel, routeLang) {
    const page = await request(embedUrl, { headers: mediaHeaders(BASE + '/') });
    if (!page.ok || !page.body) return null;
    const body = String(page.body);
    let m = body.match(/(https?:\/\/[^"'\s\\]+\.m3u8[^"'\s\\]*)/i) || body.match(/(https?:\/\/[^"'\s\\]+\.mp4[^"'\s\\]*)/i);
    if (!m) {
      const unpacked = unpackPacked(body);
      if (unpacked) m = unpacked.match(/(https?:\/\/[^"'\s\\]+\.(?:m3u8|mp4)[^"'\s\\]*)/i);
    }
    if (!m) return null;
    const src = m[1];
    const headers = mediaHeaders(embedUrl);
    if (/\.m3u8/i.test(src)) return buildHlsRoutes(src, headers, 'Direct', langLabel, routeLang, 'direct');
    const probe = await probeRange(src, headers);
    if (!probe.ok) return null;
    return [{ label: 'Direct · ' + langLabel, url: src, streamType: 'mp4', kind: 'mp4', provider: 'direct', lang: routeLang, headers }];
  }

  function hostKindOf(embedUrl) {
    const h = hostOf(embedUrl);
    if (h.indexOf('sibnet') >= 0) return 'sibnet';
    if (h.indexOf('vidmoly') >= 0) return 'vidmoly';
    if (h.indexOf('sendvid') >= 0) return 'sendvid';
    if (h.indexOf('uqload') >= 0) return 'uqload';
    return 'generic';
  }

  async function resolveEmbed(embedUrl, langLabel, routeLang) {
    const kind = hostKindOf(embedUrl);
    try {
      if (kind === 'sibnet') return await resolveSibnet(embedUrl, langLabel, routeLang);
      if (kind === 'vidmoly') return await resolveVidmoly(embedUrl, langLabel, routeLang);
      if (kind === 'sendvid') return await resolveSendvid(embedUrl, langLabel, routeLang);
      if (kind === 'uqload') return await resolveUqload(embedUrl, langLabel, routeLang);
      return await resolveGeneric(embedUrl, langLabel, routeLang);
    } catch (e) {
      log(kind + ' resolve error: ' + (e && e.message ? e.message : String(e)));
      return null;
    }
  }

  // Build the ordered lecteur candidate list for one audio: known-good hosts
  // first (site order kept as tiebreak), skip non-streamable entries.
  function candidateLecteurs(episode, lang) {
    const arr = episode && episode.lang && episode.lang[lang] && Array.isArray(episode.lang[lang].lecteurs)
      ? episode.lang[lang].lecteurs : [];
    const out = [];
    for (let i = 0; i < arr.length; i++) {
      const name = cleanText(arr[i]);
      if (NON_STREAM_LECTEURS[name]) continue;
      const n = name.toLowerCase();
      let score = 50;
      for (let p = 0; p < PREFERRED_HOSTS.length; p++) {
        if (n.indexOf(PREFERRED_HOSTS[p]) >= 0) { score = p; break; }
      }
      // host-name aliases seen in the catalogue that resolve through generic
      out.push({ li: i, name: name, score: score, order: i });
    }
    out.sort((a, b) => a.score - b.score || a.order - b.order);
    return out;
  }

  function langLabelFor(langCode) {
    return langCode === 'vf' ? 'VF' : 'VOSTFR';
  }

  function routeLangFor(langCode) {
    return langCode === 'vf' ? 'dub' : 'sub';
  }

  async function extractStreamUrl(episodeHref, lang) {
    const t0 = now();
    const ref = parseRef(episodeHref);
    if (!ref || ref.seasonIdx == null || ref.episodeIdx == null) {
      return noRoute('Unrecognised episode reference.', 'BAD_REF');
    }
    const want = String(lang || '').toLowerCase();
    const cacheKey = encodeRef(ref.id, ref.seasonIdx, ref.episodeIdx) + '|' + (want || 'auto');
    const cached = streamCache[cacheKey];
    if (cached && now() - cached.savedAt < STREAM_TTL_MS) {
      log('extractStreamUrl cache hit: ' + cacheKey);
      return cached.result;
    }
    const items = await getCatalog();
    const item = findById(items, ref.id);
    if (!item) return noRoute('Unknown anime id.', 'UNKNOWN_SERIES');
    const season = (item.saisons || [])[ref.seasonIdx];
    const episode = season && (season.episodes || [])[ref.episodeIdx];
    if (!episode) return noRoute('Unknown episode.', 'BAD_REF');

    const langOrder = want === 'dub' ? ['vf', 'vo'] : want === 'sub' ? ['vo', 'vf'] : ['vo', 'vf'];

    const routes = [];
    const attempts = [];
    const MAX_TOTAL_GET = 6;
    const MAX_RESOLVE = 4;
    let getLecteurCount = 0;
    let resolveCount = 0;

    // One candidate list across the preferred audio order: preferred language
    // first, known hosts first within each language (site order ties).
    const candidates = [];
    for (let li = 0; li < langOrder.length; li++) {
      const langCode = langOrder[li];
      const label = langLabelFor(langCode);
      const routeLang = routeLangFor(langCode);
      const list = candidateLecteurs(episode, langCode);
      for (let c = 0; c < list.length; c++) {
        candidates.push({
          li: list[c].li,
          name: list[c].name,
          score: list[c].score,
          order: list[c].order,
          langCode,
          label,
          routeLang,
          langRank: li,
        });
      }
    }
    candidates.sort((a, b) => a.langRank - b.langRank || a.score - b.score || a.order - b.order);

    // Waves of 3, parallel inside a wave; first wave that yields validated
    // routes wins. Bounded so one slow host cannot stall playback.
    for (let w = 0; w < candidates.length && getLecteurCount < MAX_TOTAL_GET && resolveCount < MAX_RESOLVE; w += 3) {
      const wave = candidates.slice(w, w + 3);
      const waveResolved = await Promise.all(wave.map(async (cand) => {
        if (getLecteurCount >= MAX_TOTAL_GET || resolveCount >= MAX_RESOLVE) return null;
        getLecteurCount += 1;
        const watch2 = await fetchLecteurUrl(ref.id, ref.seasonIdx, ref.episodeIdx, cand.langCode, cand.li);
        if (!watch2 || watch2.indexOf('/watch2/') < 0) {
          attempts.push(cand.langCode + '/' + cand.name + ': no watch2 url');
          return null;
        }
        const embed = decodeWatch2(watch2);
        if (!embed || !/^https?:\/\//.test(embed)) {
          attempts.push(cand.langCode + '/' + cand.name + ': decode failed');
          return null;
        }
        attempts.push(cand.langCode + '/' + cand.name + ' -> ' + hostOf(embed));
        resolveCount += 1;
        const rc = await resolveEmbed(embed, cand.label, cand.routeLang);
        if (!rc || !rc.length) {
          attempts.push(cand.langCode + '/' + cand.name + ': unresolved (' + hostOf(embed) + ')');
          return null;
        }
        return rc;
      }));
      for (let i = 0; i < waveResolved.length; i++) {
        if (waveResolved[i] && waveResolved[i].length) {
          for (let r = 0; r < waveResolved[i].length; r++) {
            if (routes.length < MAX_RESOLVE) routes.push(waveResolved[i][r]);
          }
        }
      }
      if (routes.length) break;
    }

    log('resolve attempts: ' + attempts.join(' | '));
    if (!routes.length) {
      return noRoute('No playable source could be resolved for this episode (hosts: ' + (attempts.join('; ') || 'none') + ').', 'SOURCE_UNAVAILABLE');
    }

    const top = routes[0];
    const qualities = [];
    for (let i = 0; i < routes.length; i++) {
      const r = routes[i];
      if (!r.height) continue;
      qualities.push({ label: r.height + 'p · ' + r.provider, url: r.url, headers: r.headers, height: r.height });
    }
    const streams = routes.map((r) => ({
      label: r.label,
      url: r.url,
      streamType: r.streamType,
      kind: r.kind,
      provider: r.provider,
      lang: r.lang,
      headers: r.headers,
      height: r.height,
    }));
    const result = {
      streams,
      qualities,
      servers: streams.map((s) => ({ name: s.label, server: s.label, url: s.url, headers: s.headers, lang: s.lang, streamType: s.streamType })),
      url: top.url,
      stream: top.url,
      headers: top.headers,
      streamType: top.streamType,
      subtitles: [],
      lang: top.lang,
    };
    if (top.height) result.quality = top.height;
    streamCache[cacheKey] = { savedAt: now(), result };
    log('streams ok: routes=' + routes.length + ' in ' + (now() - t0) + ' ms');
    return result;
  }

  // ---------- discovery ----------

  function likesByIndex(list, id) {
    for (let i = 0; i < list.length; i++) if (list[i].id === id) return i;
    return -1;
  }

  async function latestEpisodeCard(item) {
    const data = await getSeasonsData(item.id);
    if (!data || !Array.isArray(data.episodeDetails) || !data.episodeDetails.length) return null;
    // find the season/episode indexes inside the catalogue arrays (authoritative
    // for lecteur resolution) using the display season number.
    const catalogSeasons = item.saisons || [];
    const meta = data.episodeDetails;
    const lastMeta = meta[meta.length - 1];
    if (!lastMeta || !Array.isArray(lastMeta.episodes) || !lastMeta.episodes.length) return null;
    const lastEp = lastMeta.episodes[lastMeta.episodes.length - 1];
    // locate matching season index: prefer positional, verify by length
    let si = -1;
    const metaIdx = meta.length - 1;
    if (catalogSeasons[metaIdx] && Array.isArray(catalogSeasons[metaIdx].episodes)) {
      si = metaIdx;
    } else {
      for (let i = catalogSeasons.length - 1; i >= 0; i--) {
        if (Array.isArray(catalogSeasons[i].episodes) && catalogSeasons[i].episodes.length) { si = i; break; }
      }
    }
    if (si < 0) return null;
    const eps = catalogSeasons[si].episodes || [];
    const ei = eps.length - 1;
    if (ei < 0) return null;
    const card = {
      title: item.title + ' · Épisode ' + (lastEp.number != null ? lastEp.number : eps.length),
      image: cleanText(lastEp.thumbnail || item.affiche || ''),
      href: encodeRef(item.id, si, ei),
    };
    return card;
  }

  async function discoveryHome() {
    const t0 = now();
    const sections = [];
    try {
      const [items, weeklyIds, liked] = await Promise.all([getCatalog(), getWeeklyIds(), getLiked()]);

      // 1) hero — 'À la une' from the weekly top, catalogue-resolved
      const heroItems = [];
      for (let i = 0; i < weeklyIds.length && heroItems.length < 7; i++) {
        const it = findById(items, weeklyIds[i]);
        if (it) heroItems.push(heroCardFromItem(it));
      }
      if (heroItems.length) {
        sections.push({ id: 'featured', title: 'À la une', style: 'hero', items: heroItems });
      }

      // 2) top10 — 'Top de la semaine'
      const top10 = [];
      for (let i = 0; i < weeklyIds.length && top10.length < 10; i++) {
        const it = findById(items, weeklyIds[i]);
        if (it) top10.push(cardFromItem(it));
      }
      if (top10.length) sections.push({ id: 'weekly-top', title: 'Top de la semaine', style: 'top10', items: top10 });

      // 3) 'Les plus aimés' — community likes endpoint
      if (liked.length) {
        sections.push({ id: 'most-liked', title: 'Les plus aimés', style: 'poster', items: liked.slice(0, 30).map(cardFromItem) });
      }

      // 4) 'Derniers ajouts' — newest catalogue entries are appended at the end
      if (items.length) {
        const newest = items.slice(-30).reverse();
        sections.push({ id: 'newest', title: 'Derniers ajouts', style: 'poster', items: newest.map(cardFromItem) });
      }

      // 5) 'Cette saison' — currently airing (status EN COURS), newest starts first
      const airing = items
        .filter((x) => /en cours/i.test(x.status))
        .sort((a, b) => String(b.startDate).localeCompare(String(a.startDate)) || b.updatedDate - a.updatedDate)
        .slice(0, 30);
      if (airing.length) {
        sections.push({ id: 'airing', title: 'Cette saison', style: 'poster', items: airing.map(cardFromItem) });
      }

      // 6) 'Derniers épisodes' — latest episodes of the most recently updated
      // titles. Bounded parallel work: 10 titles, each = 1 seasons call.
      const recent = items
        .filter((x) => x.updatedDate > 0)
        .sort((a, b) => b.updatedDate - a.updatedDate)
        .slice(0, 10);
      const epCards = await Promise.all(recent.map((it) => latestEpisodeCard(it).catch(() => null)));
      const epItems = epCards.filter(Boolean);
      if (epItems.length >= 4) {
        sections.push({ id: 'recent-eps', title: 'Derniers épisodes', style: 'landscape', items: epItems });
      }
    } catch (e) {
      log('discoveryHome error: ' + (e && e.message ? e.message : String(e)));
    }
    log('discoveryHome: ' + sections.length + ' sections in ' + (now() - t0) + ' ms');
    return { sections };
  }

  async function discoveryFeed(feedId, page) {
    const id = cleanText(feedId || '');
    const p = Math.max(1, Number(page) || 1);
    try {
      const items = await getCatalog();
      if (!items.length) return { items: [], page: p, hasMore: false };
      let list = [];
      let total = 0;
      if (id === 'newest') {
        list = items.slice().reverse();
        total = list.length;
      } else if (id === 'airing') {
        list = items.filter((x) => /en cours/i.test(x.status))
          .sort((a, b) => String(b.startDate).localeCompare(String(a.startDate)) || b.updatedDate - a.updatedDate);
        total = list.length;
      } else if (id === 'most-liked') {
        list = await getLiked();
        total = list.length;
      } else if (id === 'recent-eps') {
        const recent = items.filter((x) => x.updatedDate > 0).sort((a, b) => b.updatedDate - a.updatedDate);
        const CAP = 100;
        const pool = recent.slice(0, CAP);
        const start = (p - 1) * 20;
        const slice = pool.slice(start, start + 20);
        const cards = await Promise.all(slice.map((it) => latestEpisodeCard(it).catch(() => null)));
        const epItems = cards.filter(Boolean);
        return {
          items: epItems,
          page: p,
          hasMore: start + 20 < pool.length && epItems.length > 0,
        };
      } else {
        return { items: [], page: p, hasMore: false };
      }
      const slice = list.slice((p - 1) * FEED_PAGE_SIZE, p * FEED_PAGE_SIZE);
      return {
        items: slice.map(cardFromItem),
        page: p,
        hasMore: p * FEED_PAGE_SIZE < total && slice.length > 0,
      };
    } catch (e) {
      log('discoveryFeed error: ' + (e && e.message ? e.message : String(e)));
      return { items: [], page: p, hasMore: false };
    }
  }

  // ---------- exports ----------

  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;

  Object.assign(globalThis, {
    searchResults,
    extractDetails,
    extractEpisodes,
    extractStreamUrl,
    discoveryHome,
    discoveryFeed,
  });
})();
