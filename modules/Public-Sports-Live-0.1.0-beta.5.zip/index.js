(() => {
  'use strict';
  const INDEX = 'https://iptv-org.github.io/iptv/categories/sports.m3u';
  const CHANNELS = [
    {id: 'FIFAPlusWomen.uk@English', title: 'FIFA+ Women'},
    {id: 'FUELTV.pt@EMEA', title: 'FUEL TV'},
    {id: 'RedBullTV.at@UK', title: 'Red Bull TV UK'},
    {id: 'WorldofFreesports.de@SD', title: 'World of Freesports'},
    {id: 'SportsGrid.us@SD', title: 'SportsGrid'},
  ];
  let cache = null;
  let cachedAt = 0;
  let pending = null;
  function safeUrl(value) {
    // Public broadcast CDNs only. No account links, redirect services or LAN URLs.
    return /^https:\/\/[a-z0-9-]+(?:\.[a-z0-9-]+)*\.(?:amagi\.tv|wurl\.com|mediatailor\.[a-z0-9-]+\.amazonaws\.com)\/[^\s]*$/i.test(value);
  }
  async function text(url) {
    // Native no-redirect mode is a headers-only probe. Use the existing body
    // transport and validate its reported destination before accepting media.
    const r = await fetchv2(url, {}, 'GET', null, {timeoutMs: 8000, maxBytesHint: 1048576});
    if (Number(r.status || r.statusCode) !== 200) throw new Error('Public sports source is unavailable');
    if (r.finalUrlKnown === false) throw new Error('Public sports destination could not be verified');
    const finalUrl = r.finalUrl || r.url || url;
    if (url === INDEX ? finalUrl !== INDEX : !safeUrl(finalUrl)) throw new Error('Unexpected public sports destination');
    const body = typeof r.body === 'string' ? r.body : typeof r.text === 'function' ? await r.text() : '';
    if (!body || body.length > 1048576) throw new Error('Invalid public sports response');
    return {body, url: finalUrl};
  }
  function parse(body) {
    if (!body.trimStart().startsWith('#EXTM3U') || /#EXT-X-/i.test(body)) throw new Error('Expected a channel playlist');
    const found = {};
    let entry = null;
    for (const raw of body.split(/\r?\n/)) {
      const row = raw.trim();
      if (row.startsWith('#EXTINF:')) {
        const id = (row.match(/\btvg-id="([^"]+)"/) || [])[1];
        entry = CHANNELS.find(c => c.id === id) || null;
        if (entry) {
          const image = (row.match(/\btvg-logo="([^"]+)"/) || [])[1] || '';
          entry = Object.assign({}, entry, {imageUrl: /^https:\/\/[^\s]+$/.test(image) ? image : ''});
        }
      } else if (row && row[0] !== '#') {
        if (entry && !found[entry.id] && safeUrl(row)) found[entry.id] = Object.assign({}, entry, {url: row});
        entry = null;
      }
    }
    const result = CHANNELS.map(c => found[c.id]).filter(Boolean);
    if (!result.length) throw new Error('No supported public sports channels available');
    return result;
  }
  async function channels(fresh) {
    if (pending) return pending;
    if (!fresh && cache && Date.now() - cachedAt < 300000) return cache;
    pending = text(INDEX).then(result => parse(result.body)).then(items => {
      cache = items;
      cachedAt = Date.now();
      return items;
    });
    try { return await pending; } finally { pending = null; }
  }
  async function channel(id, fresh) {
    // The generic details route resolves relative channel IDs against baseUrl.
    id = String(id || '').replace(/^https:\/\/iptv-org\.github\.io\//, '');
    if (!CHANNELS.some(c => c.id === id)) throw new Error('Unknown public sports channel');
    const result = (await channels(fresh)).find(c => c.id === id);
    if (!result) throw new Error('This public sports channel is currently unavailable');
    return result;
  }
  function card(c) {
    return {id: c.id, title: c.title, image: c.imageUrl, posterUrl: c.imageUrl,
      description: 'Public sports channel. Broadcasts may include replays and studio coverage.',
      subAvailable: true, dubAvailable: false};
  }
  async function liveHome() {
    return {items: (await channels(false)).map(c => ({id: c.id, title: c.title,
      category: 'Sports', kind: 'channel', imageUrl: c.imageUrl, language: 'English', status: 'unknown'}))};
  }
  async function searchResults(query) {
    const q = String(query || '').trim().toLowerCase();
    return (await channels(false)).filter(c => !q || c.title.toLowerCase().includes(q)).map(card);
  }
  async function extractDetails(id) { return card(await channel(id, false)); }
  async function extractEpisodes(id) {
    const c = await channel(id, false);
    return [{id: c.id, href: c.id, seriesId: c.id, title: c.title,
      number: 1, episodeNumber: 1, subAvailable: true, dubAvailable: false}];
  }
  async function extractStreamUrl(id, lang) {
    if (lang === 'dub') throw new Error('Live channels do not expose an alternate dub mode');
    const c = await channel(id, true);
    const result = await text(c.url);
    const playlist = result.body;
    if (!playlist.trimStart().startsWith('#EXTM3U') || playlist.includes('#EXT-X-ENDLIST') ||
        !/#EXT-X-STREAM-INF:|#EXTINF:|#EXT-X-PART:/.test(playlist)) {
      throw new Error('Public sports channel did not return an active HLS playlist');
    }
    // Preserve the master: native adaptive playback chooses a sustainable rendition.
    return {url: result.url, type: 'hls', streamType: 'hls', isLive: true, subtitles: [], headers: {}};
  }
  Object.assign(globalThis, {liveHome, searchResults, extractDetails, extractEpisodes, extractStreamUrl});
})();
